import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {readFileSync,writeFileSync,mkdtempSync,mkdirSync,unlinkSync,symlinkSync,chmodSync,rmSync} from 'node:fs';
import {join,dirname} from 'node:path';import {tmpdir} from 'node:os';import {execFileSync,spawnSync} from 'node:child_process';import {createHash} from 'node:crypto';
const state=JSON.parse(readFileSync(new URL('./test-state.json',import.meta.url))),root=state.root,out=state.output;
const {assertHistoricalHash,c12Transition:t}=await import(root+'/tests/support/h5-006-dependency-preservation.ts');
const temp=mkdtempSync(join(tmpdir(),'c12-preserve-')),rows=[],digest=b=>createHash('sha256').update(b).digest('hex');
const put=(path,b)=>{mkdirSync(dirname(join(temp,path)),{recursive:true});writeFileSync(join(temp,path),b,{mode:0o644});};
const probe=(name,fn,pass)=>{let error=null;try{fn();}catch(e){error=e.message;}const verified=pass?!error:!!error;rows.push({name,expected:pass?'PASS':'FAIL',observed:error?'FAIL':'PASS',verified,error});assert.ok(verified,name);console.log(name+' '+(pass?'PASS':'FAIL expected'));};
const original=execFileSync('git',['show','eda8b0becb3daa2dff1baa02be53cec914750f13:'+t.path],{cwd:root}),current=readFileSync(join(root,t.path));
const expectedPath='specs/001-core-crm/expected-TSK-H5-009-010.md',record='tests/fixtures/h5-009/f09/c12-20261013/c12-transition.json';
const expected=readFileSync(join(root,expectedPath));symlinkSync(join(root,'.git'),join(temp,'.git'));
const verify=()=>assertHistoricalHash(t.path,readFileSync(join(temp,t.path)),t.historicalSha256,temp);
try{
 put(t.path,original);probe('historical baseline without posterior context',verify,true);
 put(expectedPath,expected);put(record,readFileSync(join(root,record)));put(t.path,current);probe('exact corrected fixture with authorized context',verify,true);
 put(t.path,Buffer.concat([current,Buffer.from(' ')]));probe('third fixture version',verify,false);put(t.path,current);
 chmodSync(join(temp,t.path),0o600);probe('changed fixture mode',verify,false);chmodSync(join(temp,t.path),0o644);
 unlinkSync(join(temp,t.path));probe('deleted fixture',verify,false);symlinkSync(join(root,t.path),join(temp,t.path));probe('fixture symlink',verify,false);unlinkSync(join(temp,t.path));put(t.path,current);
 put(expectedPath,Buffer.concat([expected,Buffer.from(' ')]));probe('changed expected',verify,false);put(expectedPath,expected);
 unlinkSync(join(temp,record));probe('missing transition',verify,false);put(record,readFileSync(join(root,record)));
 probe('hash exchanged with another path',()=>assertHistoricalHash('tests/support/h4-confirmation-fixtures.ts',current,'0'.repeat(64),temp),false);
 // Execute an independent verifier copy without importing either changed guard.
 const trustRoot='tests/fixtures/h5-009/f09/c12-20261013/';const trust=JSON.parse(readFileSync(join(root,trustRoot+'trust.json')));
 for(const e of trust.entries)put(e.path,e.path==='scripts/verify-h5-008-evidence.mjs'?gunzipSync(readFileSync(join(root,'tests/fixtures/h5-009/f09/f16-20261013/auditor-before.mjs.gz'))):readFileSync(join(root,e.path)));
 put(trustRoot+'trust.json',readFileSync(join(root,trustRoot+'trust.json')));put(trustRoot+'verify-trust.mjs',readFileSync(join(root,trustRoot+'verify-trust.mjs')));
 const seal=readFileSync(join(out,'trust-seal.txt'),'utf8').trim();
 const external=(s=seal)=>{const p=spawnSync(process.execPath,[trustRoot+'verify-trust.mjs'],{cwd:temp,env:{...process.env,C12_TRUST_SHA256:s},encoding:'utf8'});assert.equal(p.status,0,p.stderr);};
 probe('independent guard trust exact',()=>external(),true);probe('missing external authorization seal',()=>external(''),false);probe('incorrect external authorization seal',()=>external('0'.repeat(64)),false);
 for(const e of trust.entries){const b=readFileSync(join(temp,e.path));put(e.path,Buffer.concat([b,Buffer.from(' ')]));probe('independent rejection '+e.path,()=>external(),false);put(e.path,b);}
}finally{writeFileSync(join(out,'c12-preservation.json'),JSON.stringify({status:rows.every(x=>x.verified)?'PASS':'STOP',scope:t.scope,rows},null,2)+'\n',{flag:'wx'});rmSync(temp,{recursive:true,force:true});}
