from pathlib import Path
import json,hashlib,subprocess,stat,gzip,tarfile,datetime
out=Path(__file__).resolve().parent;c=json.loads((out/'candidate.json').read_bytes());root=Path(c['root']);primary=out.parents[2];sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,data):
 with (out/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
def git(p,*args):return subprocess.check_output(['git',*args],cwd=p)
def stable(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode) and not p.is_symlink();b=p.read_bytes();z=p.lstat();assert (a.st_mode,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(z.st_mode,z.st_size,z.st_mtime_ns,z.st_ctime_ns),str(p);return b,z
for base in [primary,root]:
 assert git(base,'rev-parse','HEAD').decode().strip()==c['sha'];assert not git(base,'status','--porcelain')
assert not (root/'.git/objects/info/alternates').exists()
previous=json.loads((out/'reconstruction-before-tests.json').read_bytes());entries=[]
for e in previous['entries']:
 a,sa=stable(primary/e['path']);b,sb=stable(root/e['path']);assert a==b and len(b)==e['bytes'] and sha(b)==e['sha256'],e['path'];assert oct(stat.S_IMODE(sa.st_mode))==e['primaryMode'] and oct(stat.S_IMODE(sb.st_mode))==e['cloneMode'];entries.append(e)
assert len(entries)==35910
put('reconstruction-after-tests.json',dict(status='PASS',sha=c['sha'],files=len(entries),entries=entries))
protected=json.loads((primary/'.git/closure-protocol/20261013T014035Z/postflight.json').read_bytes())['protectedEntries']
for e in protected:
 for base in [primary,root]:
  b,s=stable(base/e['representation']);assert sha(b)==e['sha256'];assert stat.S_IMODE(s.st_mode)==int(e['mode'],8)
assert len(protected)==223
assert sha(json.dumps(c['inputs'],separators=(',',':'),ensure_ascii=False).encode())==c['candidateInputSha256']
for e in c['inputs']:
 for base in [primary,root]:
  b,s=stable(base/e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'];assert stat.S_IMODE(s.st_mode)==0o644
for prefix,seal in [('closure-protocol-20261013/',c['protocolSeal']),('f16-20261013/',c['f16Seal'])]:
 folder=root/'tests/fixtures/h5-009/f09'/prefix;raw=(folder/'trust.json').read_bytes();assert sha(raw)==seal;proof=json.loads(raw)
 for e in proof['entries']:
  b,s=stable(root/e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'] and stat.S_IMODE(s.st_mode)==0o644
 e=proof['auditor'];b=git(root,'show','a39c6062f9738441f8627f4ae88005846ac9ab9a:'+e['path']) if prefix=='f16-20261013/' else (root/e['path']).read_bytes();assert sha(b)==e['sha256'] and len(b)==e['bytes']
with tarfile.open(root/'tests/fixtures/h5-009/f09/f16-20261013/verification-evidence.tar.gz','r:gz') as archive:
 m=[m for m in archive if Path(m.name).name=='compare_f16.py'];assert len(m)==1;assert sha(archive.extractfile(m[0]).read())=='fd85642e0df6fd387781d813d0b0e2469efc5adb6ac95881b87430a82f80baf0'
put('preservation-final.json',dict(status='PASS',sha=c['sha'],protectedEntries=protected,acceptedProtocolSeal=c['protocolSeal'],originalF16Seal=c['f16Seal'],inputCount=len(c['inputs']),candidateInputSha256=c['candidateInputSha256']))
receipts=[]
required={'frozen','historical','protocol-negative','historical-negative','f05','prior-transitions','c12-preservation','f01','wrapper-counterproofs','c12-temporal','focal','typecheck','lint','unit','build','audit','health','postgres','advisors','diff','final'}
files=list((out/'gates').glob('*/status.json'));assert {f.parent.name for f in files}==required
for f in sorted(files):
 d=json.loads(f.read_bytes());assert d['sha']==c['sha'] and d['tree']==c['tree'] and d['candidateInputSha256']==c['candidateInputSha256'] and d['exit']==0
 raw=(f.parent/'output.log').read_bytes();packed=(f.parent/'output.log.gz').read_bytes();assert len(raw)==d['bytes'] and sha(raw)==d['sha256'] and gzip.decompress(packed)==raw and sha(packed)==d['compressedSha256']
 if d.get('preservation'):
  p=f.parent/'preservation';s=json.loads((p/'status.json').read_bytes());assert s==d['preservation'] and s['testedHead']==c['sha'] and s['restorationComplete'] and s['result']['exitCode']==0 and not s['unexpectedTrackedChanges'] and not s['remainingTrackedDifferences'];assert all(a['restoredExact'] for a in s['artifacts'])
  for name,e in s['outputHashes'].items():
   b=(p/name).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
  for a in s['artifacts']:
   e=a.get('generated')
   if e and e.get('evidencePath'):
    b=(p/e['evidencePath']).read_bytes();assert sha(b)==e['gzipSha256'];u=gzip.decompress(b);assert len(u)==e['bytes'] and sha(u)==e['sha256']
  assert (f.parent/'process.log').read_bytes()+(p/'postgres.stdout.log').read_bytes()+(p/'postgres.stderr.log').read_bytes()==raw
 elif d['name']=='f05':
  assert d['derivedReceipt'] and not d['newExecution'];data=json.loads(raw);assert data['testedHead']==c['sha'] and len(data['runs'])==18
  for label in ['stdout','stderr']:
   e=d[label];b=Path(e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256']
  for e in data['runs']:
   b=gzip.decompress((out/'f05-index-isolated'/(e['name']+'.log.gz')).read_bytes());assert len(b)==e['bytes'] and sha(b)==e['sha256'] and e['exit']==e['expectedExit']
 else:assert (f.parent/'process.log').read_bytes()==raw
 receipts.append(dict(name=d['name'],sha=d['sha'],exit=d['exit'],command=d['command'],outputSha256=d['sha256'],derivedReceipt=d.get('derivedReceipt',False)))
put('receipts-certification.json',dict(status='PASS',sha=c['sha'],count=len(receipts),rows=receipts))
# Serial second pass, after all mutating tests have ended.
for e in entries:
 for base,key in [(primary,'primaryMode'),(root,'cloneMode')]:
  b,s=stable(base/e['path']);assert sha(b)==e['sha256'] and len(b)==e['bytes'] and oct(stat.S_IMODE(s.st_mode))==e[key]
for base in [primary,root]:assert not git(base,'status','--porcelain')
assert git(primary,'rev-parse','origin/main').decode().strip()=='fdbd08bafdc6651d1ad6867242cd71791a25deb6';assert git(primary,'rev-list','--left-right','--count','HEAD...origin/main').decode().split()==['10','0']
put('certification.json',dict(status='PASS',candidateSha=c['sha'],tree=c['tree'],candidateInputSha256=c['candidateInputSha256'],gateReceipts=21,protectedEntries=223,trackedFiles=35910,serialPostTestPasses=2,externalProtocolSeal=c['protocolSeal'],externalF16Seal=c['f16Seal'],F09='OPEN',H5009H5010='IN PROGRESS',indexEmpty=True,worktreeClean=True,divergence='10/0',published=False,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
print('CERTIFICATION PASS',c['sha'])
