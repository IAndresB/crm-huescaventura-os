from pathlib import Path
import subprocess,json,gzip,hashlib,datetime,sys
out=Path(__file__).resolve().parent;c=json.loads((out/'candidate.json').read_bytes());root=Path(c['root'])
def run(name,cmd):
 p=subprocess.run(['python3','-B',str(out/'run-gate.py'),name,*cmd])
 if p.returncode:raise SystemExit(p.returncode)
run('historical',['python3','-B','tests/fixtures/h5-009/f09/closure-protocol-20261013/verify.py','--seal',c['protocolSeal'],'--historical-f16'])
run('protocol-negative',['python3','-B','tests/fixtures/h5-009/f09/closure-protocol-20261013/counterproofs.py','--root',str(root),'--out',str(out/'protocol-counterproofs'),'--seal',c['protocolSeal']])
run('historical-negative',['python3','-B',str(out/'run-counterproofs.py')])
# This gate is an explicitly derived receipt for the real nested F05 execution.
# Keep its stdout/stderr and all 18 individual streams separately, unmodified.
p=out/'f05-index-isolated/result.json';raw=p.read_bytes();data=json.loads(raw);assert data['status']=='PASS' and len(data['runs'])==18
nested=next(e for e in json.loads((out/'classification-counterproofs.json').read_bytes())['rows'] if e['case']=='28-F05-retest');assert nested['verified'] and nested['exit']==0
parent=json.loads((out/'gates/historical-negative/status.json').read_bytes());d=out/'gates/f05';d.mkdir();packed=gzip.compress(raw,mtime=0);(d/'output.log').write_bytes(raw);(d/'output.log.gz').write_bytes(packed)
record={**parent,'name':'f05','command':nested['command'],'startedAtUtc':nested['startedAtUtc'],'endedAtUtc':nested['endedAtUtc'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'compressedSha256':hashlib.sha256(packed).hexdigest(),'derivedReceipt':True,'newExecution':False,'sourceGate':'historical-negative','sourceResult':str(p),'stdout':nested['stdout'],'stderr':nested['stderr'],'representation':'Derived JSON result summary; original nested execution streams remain separate'}
(d/'status.json').write_text(json.dumps(record,indent=2)+'\n');print('f05 PASS (18 nested cases; receipt explicitly derived)',flush=True)
p=subprocess.run(['python3','-B',str(out/'validate.py')]);sys.exit(p.returncode)
