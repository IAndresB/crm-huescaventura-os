# Candidato con protocolo de cierre separado — validación local

## Dictamen

**PASS — candidato apto técnicamente para preparar el cierre documental.**
Esta validación no cierra F09/F06–F08 ni marca H5-009/010 COMPLETED.
No se ha publicado ni avanzado a H5-011/012, H6 o conectores reales.

HEAD inicial: `a39c6062f9738441f8627f4ae88005846ac9ab9a`.
SHA fijado y probado: `0d969541e119374561a6cd7d38e97faaed25add4`.
Árbol Git: `6b139d4e7cffe8f01371292047d86af82cfa86cb`.
Huella de 438 entradas: `584a276c5e0e261fe2118403c78a4a46d20c20c931613a919f5805d3ecae940a`.
Main, divergencia 10/0, índice vacío y árbol limpio al terminar.
Origin/main permanece `fdbd08bafdc6651d1ad6867242cd71791a25deb6` sin fetch ni push.

## Commit autorizado

Un commit local, exactamente seis rutas previamente revisadas. Se verificaron el
sello aceptado, los tamaños y hashes de la propuesta antes de preparar rutas
explícitas. git diff --cached --check pasó sobre ese conjunto completo.

- `scripts/verify-h5-008-evidence.mjs`
- `tests/fixtures/h5-009/f09/closure-protocol-20261013/README.md`
- `tests/fixtures/h5-009/f09/closure-protocol-20261013/authorization.json`
- `tests/fixtures/h5-009/f09/closure-protocol-20261013/counterproofs.py`
- `tests/fixtures/h5-009/f09/closure-protocol-20261013/trust.json`
- `tests/fixtures/h5-009/f09/closure-protocol-20261013/verify.py`

No hay archivos pendientes del checkout. Los recibos nuevos están separados en
este directorio de evidencia; su incorporación documental sigue pendiente.

## Resultados sobre el SHA exacto

| Gate | Resultado |
|---|---|
| PostgreSQL completa | 2473/2473 PASS |
| Focales H4/H5, R52 y consumidores C12 | 332/332 PASS |
| Temporal C12 y H4-014 | 110/110 PASS |
| Unitarias | 171/171 PASS |
| Health independiente | 1/1 PASS |
| Protocolo de cierre | 36/36 resultados esperados |
| Preservación histórica | 29/29 resultados esperados |
| F05 anidado | 18/18 resultados esperados |
| Transiciones F07/F09 | 40/40 resultados esperados |
| Preservación C12 | 15/15 resultados esperados |
| F01 | 12/12 resultados esperados |
| Wrapper | 14/14 resultados esperados |
| Frozen install, typecheck, lint, build | PASS |
| Auditoría de dependencias | PASS, cero vulnerabilidades conocidas |
| V-MIG, F10/F12, preservación H5-008 | PASS |
| Advisors loopback | PASS |
| Diff completo y auditor final | PASS |

21 recibos certificados. Una sola suite PostgreSQL completa en este candidato.
Los resultados de commits anteriores no se reutilizan como prueba de este SHA.
F05 conserva explícitamente su recibo derivado de la ejecución anidada: el resumen
JSON no se presenta como stdout. Se conservan las dos capturas originales y las
18 salidas individuales. El campo baseCommit de las pruebas del protocolo designa
el predecesor de confianza a39c606; el SHA ejecutado es el del recibo de este gate.

Las 43 contrapruebas archivadas F16 se repiten mediante el verificador original en
su contexto de Git y se distinguen de la comparación de las nuevas salidas focal
y completa F16. Estas últimas también pasan con el comparador original intacto.

## Integridad y confianza

- Reconstrucción independiente desde el commit: 35.910 archivos exactos antes
  de los tests. Dos recorridos completos posteriores confirman su integridad.
- 223 entradas preservadas conforme a las transiciones autorizadas; expected,
  F01, F02, F16 y manifiestos intactos. El único cambio respecto al candidato
  anterior en ese inventario es la transición autorizada del auditor.
- Los cuatro artefactos que puede regenerar la suite fueron capturados aparte
  y restaurados exactamente; ningún cambio histórico inesperado quedó pendiente.
- Inventario C12 original intacto. Ningún registro histórico se actualizó.
- Sello externo F16: `de7f4b38f061dccac0f6a290f0a555f1454e815cf16bf4941fdb0be0bf110e82`.
- Sello del protocolo aceptado por el usuario: `52f278503dc5fc49b964c596742221c249657f63040a1a767e67004ba2c648d0`.
- Comparador F16: `fd85642e0df6fd387781d813d0b0e2469efc5adb6ac95881b87430a82f80baf0`.
- Auditor probado: `76cc03c62286a9cb9c2659dad8d3475e847f63fa861b98d0e2aabc0256ff0ec2`.

El verificador independiente comprueba el auditor antes de ejecutarlo y conserva
el predecesor Git. El bootstrap requiere el sello externo aceptado; no obtiene la
confianza calculando un valor esperado del propio expediente.
Las dos diferencias POSIX conocidas (0600 en el checkout principal frente a 0644
al reconstruir dos logs antiguos) mantienen sus bytes y modos preexistentes; no
se han cambiado permisos ni introducido nuevas excepciones.

## Antecedentes que permanecen

build.log original (545 bytes) y health-independent.log original (202 bytes)
siguen ORIGINAL NO RECUPERADO. Sus hashes están en gate-summary.json y se conserva
la sustitución documental autorizada, sin convertir salidas posteriores en originales.
Las 69 diferencias históricas de hashes de tablas siguen separadas. La comparación
F16 valida el inventario conocido y las garantías C16 dentro de cada ejecución;
no acredita igualdad fila a fila entre bases históricas independientes.
R67/R030 permanece como antecedente independiente de causa no demostrada; no ha
reaparecido en esta regresión y no se atribuye su resolución a R52.

## Pendiente para el cierre documental

1. Conservar los siete originales documentales en closure-originals.tar.gz,
   incorporando el expediente de validación y sus scripts/recibos sin pérdida.
2. Preparar closure.json ligado a este SHA y su huella, los 14 pares de recibo/log
   en las rutas literales exigidas y closure-inventory.json separado. El inventario
   C12 final-inventory.json y el expediente F16 deben seguir intactos.
3. Registrar las siete transiciones documentales exactas: Tasks, estado, siguientes
   pasos, evidencia, matriz, defectos y verification.json. Actualizar F09 y los
   cierres globales F06–F08 solo en esa fase autorizada y verificada.
4. Sellar externamente el inventario de cierre, ejecutar el auditor sobre ese delta
   documental y comprobar el conjunto preparado mediante git diff --cached --check.
5. Revisar y autorizar el cierre definitivo y cualquier publicación por separado.

No se crean todavía closure.json, closure-originals.tar.gz ni el inventario de
cierre. No se modifica el estado de las incidencias ni de las tareas.
