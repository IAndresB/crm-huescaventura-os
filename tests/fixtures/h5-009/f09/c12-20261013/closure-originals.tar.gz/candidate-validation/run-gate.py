import pathlib,subprocess,json,os,sys,datetime,gzip,hashlib,shutil
out=pathlib.Path(__file__).resolve().parent;candidate=json.loads((out/'candidate.json').read_bytes());root=pathlib.Path(candidate['root']);name=sys.argv[1];command=sys.argv[2:];d=out/'gates'/name;d.mkdir(parents=True,exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
def check():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip()==candidate['sha']
 for e in candidate['inputs']:
  p=root/e['path'];assert p.is_file() and not p.is_symlink() and p.stat().st_mode&0o777==0o644,e['path'];b=p.read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
check();env={**os.environ,'POSTGRES_H0_BIN':'/Users/andres/Applications/Postgres.app/Contents/Versions/17/bin','NEXT_TELEMETRY_DISABLED':'1','F09_PROTOCOL_SHA256':candidate['protocolSeal'],'F16_TRUST_SHA256':candidate['f16Seal'],'C12_TRUST_SHA256':'eff6a0afc814707138913bdd3a2270e7458f5029d9569ce42d2b46bbe45f80f0','F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/final-inventory.json','F09_INVENTORY_SHA256':'847ef52f945eb5eedf66f3ee58a07ccaf43967a40267b1d0097d58532e3c2ce9'}
for k in ['STORAGE_H1_ENDPOINT','DATABASE_URL','SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY']:env.pop(k,None)
store=root/'tests/fixtures/h5-009/f09/postgres-preservation';before=set(store.iterdir());start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'START',candidate['sha'],flush=True)
with (d/'process.log').open('xb') as f:p=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
exitcode=p.returncode;raw=(d/'process.log').read_bytes();new=set(store.iterdir())-before;preservation=None
if new:
 assert len(new)==1;shutil.move(str(next(iter(new))),str(d/'preservation'));preservation=json.loads((d/'preservation/status.json').read_bytes());assert preservation['testedHead']==candidate['sha']
 raw+=(d/'preservation/postgres.stdout.log').read_bytes()+(d/'preservation/postgres.stderr.log').read_bytes()
 if not preservation['restorationComplete'] or preservation['unexpectedTrackedChanges'] or preservation['result']['exitCode']!=0:exitcode=exitcode or 1
try:check()
except Exception as e:exitcode=exitcode or 1;raw+=('\nCANDIDATE INTEGRITY FAIL: '+repr(e)).encode()
packed=gzip.compress(raw,mtime=0);(d/'output.log').write_bytes(raw);(d/'output.log.gz').write_bytes(packed)
row=dict(sha=candidate['sha'],tree=candidate['tree'],name=name,command=command,cwd=str(root),candidateInputSha256=candidate['candidateInputSha256'],startedAtUtc=start,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=exitcode,childExit=p.returncode,bytes=len(raw),sha256=sha(raw),compressedSha256=sha(packed),scope='local/isolated',preservation=preservation)
(d/'status.json').write_text(json.dumps(row,indent=2)+'\n');print(name,'PASS' if exitcode==0 else 'FAIL',flush=True)
if exitcode:print(raw.decode(errors='replace')[-6000:])
sys.exit(exitcode)
