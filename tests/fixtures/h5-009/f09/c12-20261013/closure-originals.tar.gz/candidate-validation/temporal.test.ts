import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {isolatedCancellation} from '../support/h4-cancellation-isolated.ts';
import {cancellationFixture} from '../support/h4-cancellation-fixtures.ts';
let h:Awaited<ReturnType<typeof isolatedCancellation>>;
before(async()=>{h=await isolatedCancellation('c12_time',59129);});
after(async()=>{await h?.close();});
for(const [label,delta,accepted] of [['before',-1,true],['simultaneous',0,true],['after',1,false]] as const){
 test('C12 evidence '+label+' respects unchanged E3 chronological contract',async()=>{
  const f=await cancellationFixture(h,{amount:'200.00'}),base=await f.command();
  const at='2026-10-13T00:01:00+02:00',evidenceAt=new Date(Date.parse(at)+delta).toISOString();
  const q=await f.command({at,facts:{...base.facts!,at}},evidenceAt);
  const rows=await h.observer`select occurred_at from crm_private.b07_records where record_id=${q.evidenceId}::uuid`;
  assert.equal(new Date(rows[0]!.occurred_at).toISOString(),evidenceAt);
  if(accepted){const r=await f.run(q);assert.equal(r.result.computed.right,'200.00');}
  else {await assert.rejects(f.run(q),/CANCELLATION_EVIDENCE_REQUIRED:E3/);assert.equal(await f.see(),null);}
 });
}
for(const [at,day,right] of [
 ['2026-10-17T23:59:59+02:00','2026-10-17','100.00'],
 ['2026-10-18T00:00:00+02:00','2026-10-18','0.00'],
 ['2026-10-17T22:00:00Z','2026-10-18','0.00'],
 ['2026-10-13T00:01:00+02:00','2026-10-13','200.00']]){
 test('C12 fixed instant and Madrid midnight '+at,async()=>{
  const f=await cancellationFixture(h,{amount:'200.00'}),base=await f.command();
  const q=await f.command({at,facts:{...base.facts!,at}});
  const rows=await h.observer`select occurred_at from crm_private.b07_records where record_id=${q.evidenceId}::uuid`;
  assert.equal(new Date(rows[0]!.occurred_at).getTime(),Date.parse(at!));
  const r=await f.run(q);assert.equal(r.result.computed.temporal.actDate,day);assert.equal(r.result.computed.right,right);
 });
}
test('C12 default proof remains original consumer path; explicit dates never use that clock',async()=>{
 const f=await cancellationFixture(h);const original=f.conf.proof;let calls=0;
 f.conf.proof=async(...args:Parameters<typeof original>)=>{calls++;return original(...args);};
 await f.command();assert.equal(calls,1);
 for(const at of ['2020-01-01T00:00:00Z','2030-01-01T00:00:00Z']){
  const q=await f.command({at});const rows=await h.observer`select occurred_at from crm_private.b07_records where record_id=${q.evidenceId}::uuid`;
  assert.equal(new Date(rows[0]!.occurred_at).getTime(),Date.parse(at));
 }
 assert.equal(calls,1);
});
