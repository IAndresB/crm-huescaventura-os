import pathlib,subprocess,json,sys,shutil,hashlib
out=pathlib.Path(__file__).resolve().parent;c=json.loads((out/'candidate.json').read_bytes());root=pathlib.Path(c['root']);wrapper='tests/fixtures/h5-009/f09/run-postgres-preserving-artifacts.mjs'
def run(name,cmd):
 p=subprocess.run(['python3','-B',str(out/'run-gate.py'),name,*cmd]);
 if p.returncode:raise SystemExit(p.returncode)
for name,script in [('prior-transitions','F08-F09-direct.mjs'),('c12-preservation','c12-preservation.mjs'),('f01','f01-regular-fixture-retest.mjs')]:run(name,['node','--experimental-strip-types',str(out/script)])
run('wrapper-counterproofs',['python3','-B',str(out/'wrapper-tests.py')])
probe=root/'tests/integration/postgres-c12-temporal.test.ts';assert not probe.exists();shutil.copy2(out/'temporal.test.ts',probe)
try:run('c12-temporal',['node',wrapper,'--','node','scripts/test-postgres.mjs',probe.name,'postgres-h4-014.test.ts'])
finally:probe.unlink()
consumers=subprocess.check_output(['rg','-l','h4-cancellation-fixtures','tests/integration'],cwd=root).decode().splitlines()
files=sorted(set([pathlib.Path(p).name for p in consumers]+['postgres-h3-006.test.ts','postgres-h4-006.test.ts','postgres-h4-021.test.ts','postgres-h4-012-f16.test.ts','postgres-h5-008-migration.test.ts','postgres-h5-009-migration.test.ts','postgres-h5-009.test.ts'])-{'postgres-h4-014.test.ts'})
run('focal',['node',wrapper,'--','node','scripts/test-postgres.mjs',*files])
from compare_f16 import compare_run
result=compare_run(root,out/'gates/focal/preservation');(out/'f16-focal-comparison.json').write_text(json.dumps(dict(sha=c['sha'],comparatorSha256=hashlib.sha256((out/'compare_f16.py').read_bytes()).hexdigest(),result=result),indent=2)+'\n')
print('F16 FOCAL COMPARISON PASS',flush=True)
for name,cmd in [('typecheck',['pnpm','run','typecheck']),('lint',['pnpm','run','lint']),('unit',['pnpm','test']),('build',['pnpm','run','build']),('audit',['pnpm','audit','--prod','--json']),('health',['node','--test','--experimental-strip-types','tests/operations/supabase-health.test.mjs'])]:run(name,cmd)
run('postgres',['node',wrapper,'--','pnpm','test:postgres'])
result=compare_run(root,out/'gates/postgres/preservation');(out/'f16-full-comparison.json').write_text(json.dumps(dict(sha=c['sha'],comparatorSha256=hashlib.sha256((out/'compare_f16.py').read_bytes()).hexdigest(),result=result),indent=2)+'\n');print('F16 FULL COMPARISON PASS',flush=True)
probe=root/'tests/integration/postgres-h5-009-advisors-probe.test.ts';assert not probe.exists();shutil.copy2(out/probe.name,probe)
try:run('advisors',['node','scripts/test-postgres.mjs',probe.name])
finally:probe.unlink()
run('diff',['python3','-B',str(out/'verify-prepared-diff.py')])
run('final',['python3','-B','tests/fixtures/h5-009/f09/closure-protocol-20261013/verify.py','--seal',c['protocolSeal'],'--historical-f16'])
