import os,tempfile,pathlib,subprocess,json
out=pathlib.Path(__file__).resolve().parent;c=json.loads((out/'candidate.json').read_bytes());root=pathlib.Path(c['root']);d=pathlib.Path(tempfile.mkdtemp(prefix='crm-candidate-index-'));env={**os.environ,'GIT_INDEX_FILE':str(d/'index')}
try:
 subprocess.run(['git','read-tree',c['sha']],cwd=root,env=env,check=True)
 staged=subprocess.check_output(['git','diff','--cached','--name-only',c['initialHead']],cwd=root,env=env).decode().splitlines();assert set(staged)==set(c['files'])
 subprocess.run(['git','diff','--cached','--check',c['initialHead']],cwd=root,env=env,check=True)
 print(json.dumps(dict(status='PASS',sha=c['sha'],comparison=c['initialHead'],preparedPaths=staged,index='isolated index created from exact candidate commit',mainIndexUnchanged=True),indent=2))
finally:
 for f in d.iterdir():f.unlink()
 d.rmdir()
