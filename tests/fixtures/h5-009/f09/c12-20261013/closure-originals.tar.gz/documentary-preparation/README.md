# Documentary closure archive

Seven original documents retain literal paths and exact bytes. candidate-validation/ contains the 353 certified evidence files plus their independent inventory. Relative artifact names are portable; absolute cwd/command paths inside original receipts describe past executions and are not rewritten. Use the committed closure-protocol verifier with independently supplied seals to audit the checkout; no former private .git run directory is required. New gate executions require a fresh evidence destination and new receipts. No prior output is reattributed.
