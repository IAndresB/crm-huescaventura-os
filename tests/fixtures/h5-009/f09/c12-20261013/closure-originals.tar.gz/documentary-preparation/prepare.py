from pathlib import Path
import json,hashlib,tarfile,io,gzip,subprocess
out=Path(__file__).resolve().parent;ctx=json.loads((out/'context.json').read_bytes());root=Path(ctx['copy']);source=Path(ctx['root']);validation=Path(ctx['validation']);sha=lambda b:hashlib.sha256(b).hexdigest();tested=ctx['testedSha'];fingerprint=ctx['candidateInputSha256'];prefix='tests/fixtures/h5-009/f09/c12-20261013/';folder=root/prefix
paths=['docs/NEXT-STEPS.md','docs/PROJECT-STATUS.md','specs/001-core-crm/tasks.md','specs/001-core-crm/evidence-TSK-H5-009-010.md','specs/001-core-crm/matrix-TSK-H5-009-010.md','specs/001-core-crm/defects-TSK-H5-009.md','tests/fixtures/h5-009/verification.json']
original={p:(root/p).read_bytes() for p in paths};snapshot=json.loads((root/'tests/fixtures/h5-009/f09/recovery-20261012T202326Z/preflight-inventory.json').read_bytes())
for p,b in original.items():
 row=next(e for e in snapshot['pendingEntries'] if e['path']==p);assert len(b)==row['bytes'] and sha(b)==row['sha256']
gates=['frozen','typecheck','lint','unit','build','audit','focal','postgres','health','historical','historical-negative','f01','f05','diff']
(folder/'gates').mkdir(exist_ok=False)
for name in gates:
 d=validation/'gates'/name;s=json.loads((d/'status.json').read_bytes());assert s['sha']==tested and s['candidateInputSha256']==fingerprint and s['exit']==0;assert sha(gzip.decompress((d/'output.log.gz').read_bytes()))==s['sha256']
 for src,dest in [('status.json',name+'.status.json'),('output.log.gz',name+'.log.gz')]:
  with (folder/'gates'/dest).open('xb') as f:f.write((d/src).read_bytes())
  (folder/'gates'/dest).chmod(0o644)
archive_path=folder/'closure-originals.tar.gz'
with archive_path.open('xb') as dest:
 with gzip.GzipFile(filename='',mode='wb',fileobj=dest,mtime=0) as packed:
  with tarfile.open(fileobj=packed,mode='w') as tar:
   def add(name,b):
    entry=tarfile.TarInfo(name);entry.mode=0o644;entry.size=len(b);entry.mtime=0;tar.addfile(entry,io.BytesIO(b))
   for p,b in original.items():add(p,b)
   inv=json.loads((validation/'evidence-inventory.json').read_bytes())
   for e in inv['entries']:
    b=(validation/e['path']).read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'];add('candidate-validation/'+e['path'],b)
   add('candidate-validation/evidence-inventory.json',(validation/'evidence-inventory.json').read_bytes())
   add('documentary-preparation/authorization.json',json.dumps(ctx,indent=2).encode()+b'\n')
   add('documentary-preparation/prepare.py',Path(__file__).read_bytes())
   add('documentary-preparation/README.md',b'# Documentary closure archive\n\nSeven original documents retain literal paths and exact bytes. candidate-validation/ contains the 353 certified evidence files plus their independent inventory. Relative artifact names are portable; absolute cwd/command paths inside original receipts describe past executions and are not rewritten. Use the committed closure-protocol verifier with independently supplied seals to audit the checkout; no former private .git run directory is required. New gate executions require a fresh evidence destination and new receipts. No prior output is reattributed.\n')
archive_path.chmod(0o644)
summary=f'''**TSK-H5-009/010 COMPLETED exclusivamente local/aislado — cierre documental local, 2026-10-13.** SHA realmente probado `{tested}`. PostgreSQL 2473/2473, focal ampliada 332/332, temporal C12/H4-014 110/110, unitarias 171/171 y health 1/1 PASS. F01–F09 CLOSED local/aislado, incluidos los cierres globales pendientes F06–F08. Expected intacto: 24.417 bytes, 26 casos y 51 filas normativas. Sin publicación. Hosted/Production no acreditados.

H5 global continúa IN PROGRESS. STOP tras H5-009/010. H5-011/012 y H6 permanecen NOT STARTED; no se preparan conectores reales.

Los dos logs originales siguen ORIGINAL NO RECUPERADO, con sustitución documental autorizada; las 69 diferencias históricas de hashes de tablas y R67/R030 permanecen como antecedentes independientes. Los resultados anteriores conservan su SHA y sus FAIL.
'''
links='[Evidencia](../specs/001-core-crm/evidence-TSK-H5-009-010.md), [matriz](../specs/001-core-crm/matrix-TSK-H5-009-010.md) y [defectos](../specs/001-core-crm/defects-TSK-H5-009.md). El cierre local está pendiente de revisión del sello del inventario, commit documental y autorización separada de publicación.'
for p in paths[:2]:
 title,rest=original[p].decode().split('\n',1);(root/p).write_text(title+'\n\n'+summary+'\n'+links+'\n\n## Antecedentes conservados — estados y resultados de sus respectivas fechas\n'+rest)
# Only the two status and two evidence lines may change in Tasks.
p='specs/001-core-crm/tasks.md';text=original[p].decode()
for task in ['009','010']:
 anchor='<a id="tsk-h5-'+task+'"></a>';start=text.index(anchor);end=text.index('<a id=',start+len(anchor));block=text[start:end];lines=block.split('\n')
 for i,line in enumerate(lines):
  if line.startswith('- [ ] **Ejecución:'):lines[i]='- [x] **Ejecución: COMPLETED exclusivamente local/aislado — cierre documental local 2026-10-13; sin publicación.**'
  elif line.startswith('- **Evidencia necesaria:'):lines[i]=f'- **Evidencia necesaria:** Expected intacto: 26 casos/51 filas. SHA probado `{tested}`; PostgreSQL 2473/2473, focal ampliada 332/332, temporal C12/H4-014 110/110, unitarias 171/171 y health 1/1 PASS; V-MIG, advisors, preservación y auditor final PASS. F01–F09 CLOSED local/aislado; F06–F08 cierre global acreditado. [Evidencia](evidence-TSK-H5-009-010.md), [matriz](matrix-TSK-H5-009-010.md), [defectos](defects-TSK-H5-009.md). Los FAIL y las limitaciones documentales históricas siguen conservados. Sin publicación ni integraciones reales.'
 new='\n'.join(lines);assert len(new.splitlines())==len(block.splitlines());text=text[:start]+new+text[end:]
(root/p).write_text(text)
base_ref='../../tests/fixtures/h5-009/f09/c12-20261013/'
current=f'''## Cierre local vigente y atribución

{summary}

Huella de las 438 entradas del candidato: `{fingerprint}`. Los 21 recibos se verificaron contra ese SHA. Una sola regresión PostgreSQL completa; no se trasladan resultados de otros commits. El archivo [closure-originals.tar.gz]({base_ref}closure-originals.tar.gz) conserva los siete documentos previos byte a byte y el expediente `candidate-validation/` completo, con su inventario independiente SHA-256 `{ctx['sourceInventorySha256']}`. El [certificado]({base_ref}closure.json) vincula las siete transiciones exactas; el [inventario separado]({base_ref}closure-inventory.json) sella las nuevas rutas sin modificar el inventario C12 congelado.

| Control sobre el candidato probado | Resultado | Evidencia |
|---|---|---|
| PostgreSQL completa | 2473/2473 PASS | [Recibo]({base_ref}gates/postgres.status.json), [log]({base_ref}gates/postgres.log.gz) |
| Focales H4/H5, H3-006/R52 y consumidores C12 | 332/332 PASS | [Recibo]({base_ref}gates/focal.status.json) |
| Temporal C12 y H4-014 | 110/110 PASS | Archivo: candidate-validation/gates/c12-temporal/ |
| Unitarias / health | 171/171 y 1/1 PASS | [Unit]({base_ref}gates/unit.status.json), [health]({base_ref}gates/health.status.json) |
| Protocolo / preservación / F05 | 36/29/18 resultados esperados | Archivo: protocol-counterproofs/, classification-counterproofs.json, f05-index-isolated/ |
| Transiciones F07/F09 / C12 / F01 / wrapper | 40/15/12/14 resultados esperados | Archivo: recibos y contrapruebas de candidate-validation/ |
| Frozen, typecheck, lint, build, auditoría de dependencias | PASS; cero vulnerabilidades conocidas | [Gates]({base_ref}closure-inventory.json) |
| V-MIG fresh, upgrade poblado, rollback/retry; advisors loopback | PASS | Focal y archivo: candidate-validation/gates/advisors/ |
| F10/F12, preservación H5-008 y auditor final | PASS | Archivo: candidate-validation/gates/final/ |

Las 26 filas de casos y 51 referencias normativas conservan el expected original. Las matrices y observaciones previas que siguen más abajo son antecedentes; esta sección aporta la ejecución vigente de la implementación y de todas sus verificaciones aplicables.

## Preservación y límites que permanecen

- Expected: 24.417 bytes, SHA-256 `b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639`, intacto.
- F01, F02, F16, los manifiestos y los snapshots originales permanecen intactos. Los cuatro artefactos regenerados fueron capturados y restaurados; cero diferencias residuales.
- El inventario C12 conserva `847ef52f945eb5eedf66f3ee58a07ccaf43967a40267b1d0097d58532e3c2ce9`. El expediente F16 y sus sellos no cambian.
- Comparador F16 intacto: `fd85642e0df6fd387781d813d0b0e2469efc5adb6ac95881b87430a82f80baf0`. Focal y regresión nueva pasan; solo los dos OID autorizados pueden variar. Las 69 diferencias de tablas permanecen identificadas separadamente, con C16 de preservación dentro de cada ejecución; no se afirma igualdad fila a fila entre bases históricas independientes.
- `build.log`: ORIGINAL NO RECUPERADO, 545 bytes, SHA-256 histórico `063f7ffad5445d9b2a45a17aceb16a01a6dfbbe70032787c0fdd02ea690fd0fa`.
- `health-independent.log`: ORIGINAL NO RECUPERADO, 202 bytes, SHA-256 histórico `2794076bee6b763f2a15c62a692735addf3e6b08e4fa296266b92953489f6f30`.
- Se mantiene la sustitución documental autorizada y las salidas sobrescritas conservadas. Los nuevos PASS no recuperan los originales.
- R67/R030 permanece como anomalía histórica independiente, de causa no demostrada, sin reaparición en esta regresión. No se atribuye su resolución al correctivo R52.
- F05 conserva stdout/stderr y 18 salidas individuales en el archivo; su recibo de cierre identifica el resumen JSON como derivado de la ejecución anidada, sin presentarlo como stdout nuevo.
- Este cierre es local y está pendiente de revisión del sello, commit documental y autorización separada de publicación.
'''
for p in ['specs/001-core-crm/evidence-TSK-H5-009-010.md','specs/001-core-crm/matrix-TSK-H5-009-010.md']:
 title,rest=original[p].decode().split('\n',1);(root/p).write_text(title+'\n\n'+current+'\n## Antecedentes íntegros — resultados atribuidos a sus SHAs originales\n'+rest)
p='specs/001-core-crm/defects-TSK-H5-009.md';title,rest=original[p].decode().split('\n',1)
closure=f'''## Estado vigente — cierre local 2026-10-13

F01–F09 CLOSED exclusivamente local/aislado sobre `{tested}`. Los encabezados OPEN/STOP posteriores pertenecen a los antecedentes conservados y no se reescriben. La pérdida documental permanece explícita; cerrar el defecto técnico no recupera los dos logs originales.

| Incidencia | Cierre acreditado |
|---|---|
| F01–F05 | Cierres históricos conservados y contrapruebas revalidadas; F01 12 casos y F05 18 casos esperados. |
| F06 | Compresión sin pérdida y diff completo PASS; cierre global confirmado tras la regresión del candidato. |
| F07 | Tres transiciones exactas autorizadas conservadas; focales y regresión completa PASS. |
| F08 | Guardas de integridad, tipo y permisos y transiciones históricas revalidadas; cierre global confirmado. |
| F09 | R52 retiene ambas raíces antes de lanzar workers, acredita dos sesiones y solapamiento y conserva un éxito/un rechazo, cobertura 300 e integridad transaccional; ambos órdenes, llegada simultánea, orden invertido y limpieza inducida pasan. H3-006 y PostgreSQL 2473/2473 PASS. |
| Correctivo C12 | Preparación temporal explícita, anterior/simultánea aceptada y posterior rechazada, día civil y consumidores conservados. |
| Comparación suplementaria F16 | Dos OID de funciones nuevas por identidad estable, demás atributos y objetos exactos; sin cambio del original F16. |

{current}
'''
(root/p).write_text(title+'\n\n'+closure+'\n## Registro histórico íntegro — FAIL y STOP originales\n'+rest)
old=json.loads(original['tests/fixtures/h5-009/verification.json']);record={k:old[k] for k in ['scope','base','expectedPublication','originalProductSha','firstCorrectionSha','expectedBytes','expectedSha256','cases','normativeRows','normativeSources']}
record.update(status='PASS',testedSha=tested,candidateInputSha256=fingerprint,gateDirectory='f09/c12-20261013/gates',results={'postgres':2473,'focal':332,'c12Temporal':110,'unit':171,'health':1,'failures':0},F01F09='CLOSED local/isolated',F06F08Global='CLOSED local/isolated',documentaryState='Local closure prepared and verified; separate inventory seal review and documentary commit pending',published=False,originals=prefix+'closure-originals.tar.gz',candidateEvidenceMember='candidate-validation/',candidateEvidenceInventorySha256=ctx['sourceInventorySha256'],originalLogs='ORIGINAL NO RECUPERADO (2); authorized documentary substitution retained',R67R030='Independent historical anomaly; cause not demonstrated; did not recur',historicalTableHashDifferences=69,gates={name:json.loads((validation/'gates'/name/'status.json').read_bytes()) for name in gates})
(root/'tests/fixtures/h5-009/verification.json').write_text(json.dumps(record,indent=2)+'\n')
transitions=[]
for p in paths:
 b=(root/p).read_bytes();(root/p).chmod(0o644);transitions.append(dict(path=p,beforeSha256=sha(original[p]),type='regular',mode='0644',bytes=len(b),sha256=sha(b)))
proof=dict(status='PASS',scope='H5-009/010 local/isolated',testedSha=tested,candidateInputSha256=fingerprint,transitions=transitions,authorization='Human OK SIGUE following exact candidate certification; local documentary preparation and verification, no push',originalsArchive=prefix+'closure-originals.tar.gz',originalsArchiveSha256=sha(archive_path.read_bytes()),sourceEvidenceInventorySha256=ctx['sourceInventorySha256'],protocolSeal=ctx['protocolSeal'],originalF16Seal=ctx['F16Seal'],historicalOriginalLogs='ORIGINAL NO RECUPERADO (2)',published=False)
(folder/'closure.json').write_text(json.dumps(proof,indent=2)+'\n')
newpaths=[prefix+'closure.json',prefix+'closure-originals.tar.gz']+[prefix+'gates/'+name+suffix for name in gates for suffix in ['.status.json','.log.gz']];entries=[]
for p in newpaths:
 file=root/p;file.chmod(0o644);b=file.read_bytes();entries.append(dict(path=p,type='regular',mode='0644',bytes=len(b),sha256=sha(b),provenance='Certified candidate '+tested+' and human-authorized seven documentary transitions',purpose='Exact closure certificate, preserved originals and actual candidate gate evidence'))
(folder/'closure-inventory.json').write_text(json.dumps(dict(scope='H5-009/010 local/isolated',testedSha=tested,entries=entries),indent=2)+'\n');(folder/'closure-inventory.json').chmod(0o644)
(out/'prepared.json').write_text(json.dumps(dict(testedSha=tested,closureInventorySha256=sha((folder/'closure-inventory.json').read_bytes()),paths=paths+newpaths+[prefix+'closure-inventory.json'],transitions=transitions,archiveSha256=sha(archive_path.read_bytes())),indent=2)+'\n')
print('PREPARED',len(paths)+len(newpaths)+1,'paths; separate inventory seal',sha((folder/'closure-inventory.json').read_bytes()))
