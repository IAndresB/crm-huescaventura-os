import pathlib,json
out=pathlib.Path(__file__).parent;s=json.loads((out/'test-state.json').read_bytes());t=s['candidateCopy']
p=out/'f05-index-isolated-retest.mjs';v=p.read_text().replace('/var/folders/yl/gkcr80ts3q78l9tnv5943flc0000gn/T/crm-f09-verified-cynot1wk',t);p.write_text(v)
p=out/'run-counterproofs.py';v=p.read_text();a=v.index(' # The existing F05 assertions');b=v.index(" run('29-final",a);v=v[:a]+" run('28-F05-retest',script=str(out/'f05-index-isolated-retest.mjs'))\n"+v[b:];p.write_text(v)
p=out/'f01-regular-fixture-retest.mjs';v=p.read_text().replace("'tests/integration/postgres-h3-006.test.ts'","'tests/integration/postgres-h3-006.test.ts','tests/support/h4-cancellation-fixtures.ts'");p.write_text(v)
