import pathlib,json,hashlib
r=pathlib.Path.cwd();o=pathlib.Path(__file__).parent;prefix='tests/fixtures/h5-009/f09/c12-20261013/';d=r/prefix;d.mkdir();h=lambda b:hashlib.sha256(b).hexdigest();jb=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode();fixture='tests/support/h4-cancellation-fixtures.ts';guard='tests/support/h5-006-dependency-preservation.ts';auditor='scripts/verify-h5-008-evidence.mjs';oldfixture='1c3e91375632a520893f4a92d2ffd969ff17a2012776a9e7a1abdc3e51c6ec03';newfixture=h((r/fixture).read_bytes());assert newfixture=='dd2b851e5d2888f60f249af0bc3f9000edc160d88da58ffcd200bc2deb6ee15a'
transition=dict(path=fixture,historicalSha256=oldfixture,correctedSha256=newfixture,reason='H4-014 C12 explicit synthetic evidence chronology',scope='H5-009/010 local/isolated');(d/'c12-transition.json').write_bytes(jb(transition))
s=(r/guard).read_text();insert='''// C12: one authorized fixture transition; the shared guard itself is verified
// independently by the auditor against an externally supplied trust-record seal.
export const c12Transition=Object.freeze(TRANSITION);
function assertC12Transition(path:string,current:Uint8Array,historicalHash:string,root:string):boolean {
 if(path!==c12Transition.path)return false;
 assert.equal(historicalHash,c12Transition.historicalSha256,path+': frozen C12 historical hash');
 const metadata=lstatSync(resolve(root,path));assert.ok(metadata.isFile()&&!metadata.isSymbolicLink(),path+': C12 regular file');
 assert.equal(metadata.mode&0o777,0o644,path+': C12 exact permissions');
 assert.equal(digest(execFileSync('git',['show','eda8b0becb3daa2dff1baa02be53cec914750f13:'+path],{cwd:root})),c12Transition.historicalSha256,path+': Git C12 baseline');
 const hash=digest(current);assert.equal(digest(readFileSync(resolve(root,path))),hash,path+': C12 on-disk bytes');
 assert.ok(hash===c12Transition.historicalSha256||hash===c12Transition.correctedSha256,path+': unauthorized C12 third version');
 if(hash===c12Transition.correctedSha256){
  const expected=readFileSync(resolve(root,'specs/001-core-crm/expected-TSK-H5-009-010.md'));
  assert.equal(expected.length,24417);assert.equal(digest(expected),'b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639',path+': C12 isolated context');
  const record=resolve(root,'tests/fixtures/h5-009/f09/c12-20261013/c12-transition.json'),stat=lstatSync(record);
  assert.ok(stat.isFile()&&!stat.isSymbolicLink());assert.equal(stat.mode&0o777,0o644);
  assert.deepEqual(JSON.parse(readFileSync(record,'utf8')),c12Transition,path+': exact C12 authorization record');
 }
 return true;
}
'''.replace('TRANSITION',json.dumps(transition,separators=(',',':')))
s=s.replace('// F09: one exact R52 verifier transition,',insert+'// F09: one exact R52 verifier transition,');s=s.replace(" if(assertF09R52Transition(path,current,digest(historical),'.'))return;"," if(assertC12Transition(path,current,digest(historical),'.'))return;\n if(assertF09R52Transition(path,current,digest(historical),'.'))return;");s=s.replace(' if(assertF09R52Transition(path,current,historicalHash,root))return;',' if(assertC12Transition(path,current,historicalHash,root))return;\n if(assertF09R52Transition(path,current,historicalHash,root))return;');(r/guard).write_text(s)
a=(r/auditor).read_text();line="assert.ok(preservationHashes.includes(createHash('sha256').update(readFileSync(preservationPath)).digest('hex')),'exact authorized F08 guard bytes');";assert line in a
trust='''// Independently checked before importing the changed shared guard. The seal is
// supplied by the reviewing invocation, not read from the guard or its record.
const c12Path='tests/support/h4-cancellation-fixtures.ts',c12Root='tests/fixtures/h5-009/f09/c12-20261013/';
const c12Before={"tests/support/h4-cancellation-fixtures.ts":"1c3e91375632a520893f4a92d2ffd969ff17a2012776a9e7a1abdc3e51c6ec03","tests/support/h5-006-dependency-preservation.ts":"d8f1fdacb3508dfe40a924e14ecda98cc01345de5bb3540fc9a24277704a292c","scripts/verify-h5-008-evidence.mjs":"7a39b57837db8cbfecafc0cac825ac887548e36d6d26deeb0af4aedf3b628d3b"};
const sha256=b=>createHash('sha256').update(b).digest('hex');
let c12Trust=null;
const guardDigest=sha256(readFileSync(preservationPath));
if(!preservationHashes.includes(guardDigest)){
 const path=c12Root+'trust.json',metadata=lstatSync(path);assert.ok(metadata.isFile()&&!metadata.isSymbolicLink());assert.equal(metadata.mode&0o777,0o644);
 const raw=readFileSync(path);assert.match(process.env.C12_TRUST_SHA256??'',/^[a-f0-9]{64}$/,'C12 independent trust seal required');assert.equal(sha256(raw),process.env.C12_TRUST_SHA256,'C12 independent trust seal');
 const trust=JSON.parse(raw);assert.equal(trust.scope,'H5-009/010 local/isolated');assert.equal(trust.authorization,'Human-authorized C12 fixture and two guard corrections');assert.equal(trust.baseCommit,'eda8b0becb3daa2dff1baa02be53cec914750f13');
 assert.deepEqual(trust.entries.map(x=>x.path).sort(),Object.keys(c12Before).sort(),'only three authorized C12 paths');
 for(const entry of trust.entries){
  assert.equal(entry.beforeSha256,c12Before[entry.path]);assert.equal(sha256(execFileSync('git',['show',trust.baseCommit+':'+entry.path])),entry.beforeSha256,'independent Git predecessor');
  const stat=lstatSync(entry.path);assert.ok(stat.isFile()&&!stat.isSymbolicLink(),'C12 trusted file type: '+entry.path);assert.equal(stat.mode&0o777,0o644,'C12 trusted permissions: '+entry.path);
  const bytes=readFileSync(entry.path);assert.equal(bytes.length,entry.bytes);assert.equal(sha256(bytes),entry.sha256,'C12 externally sealed bytes: '+entry.path);
 }
 assert.equal(trust.entries.find(x=>x.path===c12Path).sha256,'dd2b851e5d2888f60f249af0bc3f9000edc160d88da58ffcd200bc2deb6ee15a','exact reviewed C12 fixture');c12Trust=trust;
}
assert.ok(preservationHashes.includes(guardDigest)||c12Trust,'exact independently authorized guard');'''
a=a.replace(line,trust)
a=a.replace("if(entry.path==='scripts/verify-h5-008-evidence.mjs')continue;","if(entry.path==='scripts/verify-h5-008-evidence.mjs')continue;\n  if(entry.path===preservationPath&&c12Trust){assert.equal(entry.sha256,c12Before[preservationPath]);assert.equal(sha256(readFileSync(entry.path)),c12Trust.entries.find(x=>x.path===entry.path).sha256);continue;}")
a=a.replace('exactlyPreserved:checkedClosure?211:218,','exactlyPreserved:(checkedClosure?211:218)-(c12Trust?1:0),independentlyAuthorizedGuardTransition:Boolean(c12Trust),')
a=a.replace('const recoveryRoot="tests/fixtures/h5-009/f09/completion-20261013/";','const recoveryRoot="tests/fixtures/h5-009/f09/c12-20261013/";')
# Keep old paths literally admitted as immutable prior evidence; add the new literal equivalents.
import re
oldroot='tests/fixtures/h5-009/f09/completion-20261013/'
oldpaths=sorted(set(re.findall(r'"('+re.escape(oldroot)+'[^"\n]+)"',a)))
newpaths=[p.replace(oldroot,prefix) for p in oldpaths]+[prefix+n for n in ['trust.json','c12-transition.json','preflight.json','before.tar.gz','verify-trust.mjs']]
newpaths=sorted(set(newpaths));needle='let recoveryStatus=null;';a=a.replace(needle,'for(const path of '+json.dumps(newpaths)+')recoveryPaths.add(path);\n'+needle)
needle=" const load=name=>{const path=recoveryRoot+name;";assert needle in a
bridge=""" const c12Prior='tests/fixtures/h5-009/f09/completion-20261013/final-inventory.json';
 assert.ok(admitted.has(c12Prior),'pre-C12 STOP preserved');const c12PriorRaw=check(c12Prior);assert.equal(sha256(c12PriorRaw),'8a0feda291dcc69cf07c133cfe9f5fd7f353bad346807294a169794f392b0606','immutable pre-C12 STOP inventory');
 for(const entry of JSON.parse(c12PriorRaw).entries){check(entry.path,entry);assert.ok(admitted.has(physicalPath(entry.path)),'pre-C12 evidence remains registered: '+entry.path);}
 assert.ok(c12Trust,'C12 independent trust required in current context');assert.ok(admitted.has(c12Root+'trust.json')&&admitted.has(c12Root+'c12-transition.json'),'C12 records registered');
"""
a=a.replace(needle,bridge+needle)
a=a.replace("assert.equal(candidate.baseCommit,'8c1109426a8e85effeda6c2bb59c08ac0693c032');","assert.equal(candidate.baseCommit,'eda8b0becb3daa2dff1baa02be53cec914750f13');")
a=a.replace('...productPaths,...f07Paths,preservationPath,r52Path,r52Evidence,','...productPaths,...f07Paths,preservationPath,r52Path,r52Evidence,c12Path,')
needle=' const posterior=existsSync(expectedPath)';a=a.replace(needle," assertHistoricalHash(c12Path,readFileSync(c12Path),sha256(bytes(closure,c12Path)));\n"+needle)
a=a.replace('if(f07Paths.includes(file)||file===r52Path){','if(f07Paths.includes(file)||file===r52Path||file===c12Path){')
a=a.replace("'f09/completion-20261013/gates'].includes(gateDirectory)","'f09/completion-20261013/gates','f09/c12-20261013/gates'].includes(gateDirectory)")
(r/auditor).write_text(a)
pre=json.loads((o/'preflight.json').read_bytes());rows=[dict(path=e['path'],beforeSha256=e['sha256'],bytes=(r/e['path']).stat().st_size,sha256=h((r/e['path']).read_bytes()),type='regular',mode='0644') for e in pre['protectedPaths']];record=dict(authorization='Human-authorized C12 fixture and two guard corrections',baseCommit=pre['baseHead'],scope='H5-009/010 local/isolated',entries=rows,trustBoundary='External SHA256 provided by the reviewing invocation; Git pins predecessors. The shared guard does not authorize its own bytes.');raw=jb(record);(d/'trust.json').write_bytes(raw);(o/'trust-seal.txt').write_text(h(raw)+'\n');(d/'preflight.json').write_bytes((o/'preflight.json').read_bytes());print('trust',h(raw));print(json.dumps(rows,indent=2))
