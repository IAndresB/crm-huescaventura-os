import json,pathlib,gzip,hashlib,datetime
out=pathlib.Path(__file__).parent;hist=pathlib.Path('tests/fixtures/h4-012-f16/preservation.json');gen=out/'gates/postgres-full/preservation/generated/tests/fixtures/h4-012-f16/preservation.json.gz';a=json.loads(hist.read_bytes());raw=gzip.decompress(gen.read_bytes());b=json.loads(raw);diffs=[]
def walk(a,b,p=''):
 if type(a)!=type(b):diffs.append(dict(path=p,old=a,new=b));return
 if isinstance(a,dict):
  if a.keys()!=b.keys():diffs.append(dict(path=p,oldKeys=list(a),newKeys=list(b)))
  for k in a.keys()&b.keys():walk(a[k],b[k],p+'/'+str(k))
 elif isinstance(a,list):
  if len(a)!=len(b):diffs.append(dict(path=p,oldLength=len(a),newLength=len(b)))
  for i,(x,y) in enumerate(zip(a,b)):walk(x,y,p+'/'+str(i))
 elif a!=b:diffs.append(dict(path=p,old=a,new=b))
walk(a,b);non=[x for x in diffs if not x['path'].startswith('/tables/')];report=dict(observedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),historicalSha256=hashlib.sha256(hist.read_bytes()).hexdigest(),generatedSha256=hashlib.sha256(raw).hexdigest(),historicalBytes=hist.stat().st_size,generatedBytes=len(raw),differences=len(diffs),nonTableDifferences=non,tableNamesIdentical=[x['table'] for x in a['tables']]==[x['table'] for x in b['tables']],beforeIdentical=a['before']==b['before'],changedBodiesIdentical=a['changedBodies']==b['changedBodies'])
with (out/'f16-new-difference-diagnosis.json').open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False);f.write('\n')
print(json.dumps(report,indent=2,ensure_ascii=False))
