import pathlib,json,hashlib,subprocess,datetime,gzip,os,stat
r=pathlib.Path.cwd();out=pathlib.Path('/Users/andres/Developer/crm-huescaventura-os/.git/c12-authorized/20261012T233543Z');rel='tests/fixtures/h5-009/f09/c12-20261013/';d=r/rel
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):
 with p.open('xb') as f:f.write(v if isinstance(v,bytes) else (json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode())
def meta(p):
 s=(r/p).lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode&0o777==0o644,p;b=(r/p).read_bytes();return dict(path=p,type='regular',mode='0644',bytes=len(b),sha256=sha(b))
prior='tests/fixtures/h5-009/f09/documentary-exception-20261012T204228Z-e1f88cb4/';old=json.loads((r/prior/'loss-record.json').read_bytes());refs=[dict(path=e['path'],bytes=e['originalBytes'],sha256=e['originalSha256']) for e in old['losses']]
write(d/'authorization.json',dict(decision='AUTHORIZED DOCUMENTARY SUBSTITUTION',scope='H5-009/010 local/isolated',historicalReferences=refs,originalRecoveryClaimed=False,source=prior+'authorization.json',continuation='Direct human instruction: Ok, hazlo entonces y seguimos hasta el cierre de H5. Haz pruebas de todo lo que consideres.',boundary='H5-009/010 local/isolated; later tasks and external real operations remain excluded'))
write(d/'substitution.json',dict(originalState='ORIGINAL NO RECUPERADO',historicalReferences=refs,authorization=rel+'authorization.json',originalRecoveryClaimed=False,observedHashesAcceptedAsHistorical=False,substitutes=[rel+'build.log.gz',rel+'health-independent.log.gz'],priorLossRecord=prior+'loss-record.json',cause='Later tee executions overwrote untracked historical log paths; exact original bytes not recovered from accessible sources.',recoverySearch='tests/fixtures/h5-009/f09/recovery-20261012T202326Z/search-report.json',limitations=['New runs do not recover the original streams.','Original execution traces establish exit codes but not lost bytes.','External backup access was limited.']))
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0');inputs=[]
for p in sorted(set(files)-{''}):
 if (p.startswith(('src/','scripts/','supabase/migrations/')) or pathlib.Path(p).suffix in ['.ts','.mjs','.sql'] or '/' not in p) and (r/p).is_file():inputs.append(meta(p))
fingerprint=sha(json.dumps(inputs,separators=(',',':'),ensure_ascii=False).encode())
env={**os.environ,'POSTGRES_H0_BIN':'/Users/andres/Applications/Postgres.app/Contents/Versions/17/bin','NEXT_TELEMETRY_DISABLED':'1'}
for k in ['STORAGE_H1_ENDPOINT','DATABASE_URL','SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY','F09_INVENTORY_PATH','F09_INVENTORY_SHA256']:env.pop(k,None)
versions={cmd:' '.join(subprocess.check_output(args,env=env).decode().split()) for cmd,args in [('node',['node','--version']),('pnpm',['pnpm','--version']),('postgres',[env['POSTGRES_H0_BIN']+'/postgres','--version'])]}
write(d/'candidate.json',dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),scope='H5-009/010 local/isolated',inputSha256=fingerprint,inputs=inputs,environment={'versions':versions,'POSTGRES_H0_BIN':env['POSTGRES_H0_BIN'],'NEXT_TELEMETRY_DISABLED':'1'},identity='Base commit plus exact executable/input file inventory; documentary output excluded to avoid self-reference.'))
runs=[]
try:
 for name,cmd in [('build',['pnpm','run','build']),('health-independent',['node','--test','--experimental-strip-types','tests/operations/supabase-health.test.mjs'])]:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();log=out/(name+'.raw.log');print(name,'START',fingerprint,flush=True)
  with log.open('xb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  raw=log.read_bytes();packed=gzip.compress(raw,mtime=0);write(d/(name+'.log.gz'),packed)
  row=dict(name=name,command=cmd,candidateInputSha256=fingerprint,startedAtUtc=start,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=p.returncode,result='PASS' if p.returncode==0 else 'FAIL',environment={'versions':versions,'POSTGRES_H0_BIN':env['POSTGRES_H0_BIN'],'NEXT_TELEMETRY_DISABLED':'1'},output=dict(path=rel+name+'.log.gz',rawBytes=len(raw),rawSha256=sha(raw),compressedBytes=len(packed),compressedSha256=sha(packed)));runs.append(row);print(name,row['result'],flush=True)
  assert p.returncode==0,raw.decode(errors='replace')[-3000:]
 for e in inputs:assert meta(e['path'])==e,e['path']
finally:write(d/'executions.json',runs)
