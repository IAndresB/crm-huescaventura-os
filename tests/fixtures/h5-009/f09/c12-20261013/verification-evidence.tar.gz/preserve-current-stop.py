import pathlib,json,hashlib,gzip,tarfile,io,subprocess,datetime,os,stat
r=pathlib.Path.cwd();o=pathlib.Path(__file__).parent.resolve();prefix='tests/fixtures/h5-009/f09/c12-20261013/';d=r/prefix;sha=lambda b:hashlib.sha256(b).hexdigest();jb=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode();base=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip();candidate=json.loads((d/'candidate.json').read_bytes());pg=o/'gates/postgres-full/preservation';wr=json.loads((pg/'status.json').read_bytes());assert wr['result']['exitCode']==0 and wr['restorationComplete'] and not wr['unexpectedTrackedChanges'];diag=json.loads((o/'f16-new-difference-diagnosis.json').read_bytes());old=json.loads((r/'tests/fixtures/h4-012-f16/preservation.json').read_bytes());new=json.loads(gzip.decompress((pg/'generated/tests/fixtures/h4-012-f16/preservation.json.gz').read_bytes()));details=[]
for index in [153,154]:
 a=old['after']['functions'][index];b=new['after']['functions'][index];assert {k:v for k,v in a.items() if k!='oid'}=={k:v for k,v in b.items() if k!='oid'};assert not any(x['proname']==a['proname'] for x in old['before']['functions']);details.append(dict(name=a['proname'],historicalOid=a['oid'],generatedOid=b['oid'],bodySha256=sha(a['body'].encode()),allOtherFunctionFieldsIdentical=True,absentFromBeforeCatalogue=True))
assert len(old['tables'])==len(new['tables'])==131;assert diag['tableNamesIdentical'] and diag['beforeIdentical'] and diag['changedBodiesIdentical'];assert len(diag['nonTableDifferences'])==2
stop=dict(status='STOP',scope='H5-009/010 local/isolated',baseCommit=base,candidateInputSha256=candidate['inputSha256'],workingChanges='Three authorized code paths; this is not a test of the unmodified base commit',newBlocker='F16 comparison outside previously approved 69 table-digest differences: two additional after.functions OIDs',functionDifferences=details,exactAllocationCause='Not demonstrated: ephemeral database closed after suite; no trace of which allocation consumed the additional OID',semanticConclusion='No difference in function bodies, signatures, owners, ACL, search_path, security mode or return types. Before catalogue and changedBodies are identical. No new functional defect or data corruption demonstrated.',comparisonExit=1,postgresExit=0,postgresTests=2473,postgresPass=2473,postgresFail=0,restorationComplete=True,unexpectedTrackedChanges=[],F09='OPEN',C12='Corrected and focal PASS; global closure pending',F06_F07_F08='Global closure pending',originalLogs='ORIGINAL NO RECUPERADO',R67_R030='Independent historical anomaly, cause not demonstrated; no recurrence in this suite',notExecutedAfterStop=['Advisors57','new candidate commit and exact-SHA revalidation','documentary closure','full staged diff-check','final commit','push'],recommendation='Request a specific review of F16 comparison semantics for the two new function OIDs, preserving the raw generated output and the frozen historical JSON. Do not modify product, historical snapshot or manifests, and do not accept the generated hash as historical.')
with (o/'stop-diagnosis.json').open('xb') as f:f.write(jb(stop))
# Independently verify exact historical restoration and all original pending files.
p=json.loads((o/'preflight.json').read_bytes());allowed={e['path']:e for e in json.loads((d/'trust.json').read_bytes())['entries']};check=[]
for e in p['snapshot223']:
 path=r/e['representation'];s=path.lstat();assert stat.S_ISREG(s.st_mode) and not path.is_symlink() and s.st_mode&0o777==int(e['mode'],8);raw=path.read_bytes();b=gzip.decompress(raw) if e['representation']!=e['path'] else raw;expected=allowed[e['path']]['sha256'] if e['path'] in allowed else e['sha256'];assert sha(b)==expected,e['path'];check.append(dict(path=e['path'],sha256=expected,mode=e['mode'],type='regular',representation=e['representation'],authorizedTransition=e['path'] in allowed))
for e in p['pending']:
 f=r/e['path'];assert sha(f.read_bytes())==e['sha256'] and f.stat().st_mode&0o777==int(e['mode'],8)
assert subprocess.check_output(['git','diff','--cached','--name-only'])==b''
assert sorted(subprocess.check_output(['git','diff','--name-only']).decode().splitlines())==sorted(allowed)
for e in candidate['inputs']:assert sha((r/e['path']).read_bytes())==e['sha256'],e['path']
with (o/'post-stop-integrity.json').open('xb') as f:f.write(jb(dict(status='PASS',snapshot223=check,previousThreePendingPreserved=True,indexEmpty=True,candidateInputsPreserved=True)))
files=[]
for p in sorted(o.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(o)
 if 'frozen-install' in rel.parts or p.name.endswith('.index'):continue
 files.append((str(rel),p.read_bytes(),p.stat().st_mode&0o777))
manifest=dict(status='STOP',baseCommit=base,candidateInputSha256=candidate['inputSha256'],entries=[dict(path=p,bytes=len(b),sha256=sha(b),mode=oct(m)[2:].zfill(4)) for p,b,m in files]);buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for p,b,m in files+[('archive-inventory.json',jb(manifest),0o644)]:
  info=tarfile.TarInfo(p);info.size=len(b);info.mode=m;tar.addfile(info,io.BytesIO(b))
packed=gzip.compress(buf.getvalue(),mtime=0)
with (d/'verification-evidence.tar.gz').open('xb') as f:f.write(packed)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
 for e in manifest['entries']:assert sha(tar.extractfile(e['path']).read())==e['sha256']
report=f'''# C12 — correctivo focal validado; STOP de preservación F16

**Estado: STOP. No hay PASS global ni cierre de C12, F09 o H5-009/010.** F06–F08 mantienen el cierre global pendiente. No se ha creado ningún commit ni efectuado push en esta actuación.

## Candidato y alcance

Rama main; base HEAD `{base}`; origin/main `fdbd08bafdc6651d1ad6867242cd71791a25deb6`; divergencia8/0. El candidato probado es esa base **más las tres modificaciones autorizadas**, identificadas por la huella de433 entradas `{candidate['inputSha256']}`. Estos resultados no se atribuyen al commit base sin cambios. Índice vacío.

Se aplicó el patch preparado: `evidenceAt` explícito, valor por defecto `change.at`, misma ruta previa de evidencia cuando no se proporciona un instante. C12 conserva su archivo y aserciones originales. El producto, reglas de cancelación, F2, migraciones, dependencias y contratos no se modificaron.

| Archivo modificado | SHA256 anterior | SHA256 corregido |
|---|---|---|
'''+ '\n'.join(f"| `{e['path']}` | `{e['beforeSha256']}` | `{e['sha256']}` |" for e in allowed.values())+f'''

Todos son archivos regulares0644. Sus originales Git están en [before.tar.gz](before.tar.gz). La transición literal del fixture está en [c12-transition.json](c12-transition.json). La guarda compartida no aprueba sus propios bytes: [trust.json](trust.json) se verifica contra Git y el sello externo `{(o/'trust-seal.txt').read_text().strip()}`, mediante [verify-trust.mjs](verify-trust.mjs) sin importar las guardas modificadas y mediante el auditor antes de importar la guarda compartida. La autorización se limita a las tres rutas y al contexto H5-009/010 local/aislado. Las transiciones F07/F09 se conservan.

## Resultados de esta ejecución

| Control | Resultado |
|---|---|
| H4-014 completo y contrapruebas temporales C12 | 110/110 PASS:102 históricas y8 nuevas |
| Consumidores del fixture y H3-006/R52 | 338/338 PASS; H3-006 contiene75 casos |
| Focales H4/H5, incluidas migraciones fresh/upgrade/rollback/retry | 70/70 PASS |
| PostgreSQL completa, wrapper protegido | **2473/2473 PASS**,0 cancelados,0 omitidos |
| Comparación posterior F16 | **FAIL / STOP**, dos OID adicionales distintos |
| Unitarias completas | 171/171 PASS |
| Build y health independiente | PASS; health1/1; salidas nuevas exclusivas |
| Frozen install, typecheck, lint/import boundaries | PASS |
| Auditoría de dependencias de producción | PASS, sin vulnerabilidades informadas |
| Preservación directa C12 y confianza independiente | 15 controles esperados PASS |
| Clasificación del auditor | 29 controles esperados PASS |
| F01 / F05 | 12 /18 controles esperados PASS |
| Transiciones F07/F09 | 40 controles esperados PASS |
| Recuperación documental / gzip | 13 /26 controles esperados PASS |
| Wrapper | 14 controles esperados PASS |
| F10/F12 y preservación H5-008 | PASS antes de la regresión |
| Advisors, cierre, diff staged completo y publicación | No ejecutados tras STOP |

Los FAIL inducidos son rechazos esperados y se conservan íntegros. No se ajustaron aserciones originales. Las contrapruebas C12 comprueban evidencia anterior/simultánea aceptada, posterior rechazada por `CANCELLATION_EVIDENCE_REQUIRED:E3`, efecto transaccional nulo del rechazo, medianoche Madrid, equivalencia UTC y construcción con fechas2020/2030 sin utilizar el reloj de la prueba. El camino por defecto sigue llamando a `conf.proof`.

## Nuevo bloqueo F16, localizado

Histórico:1.858.702bytes, SHA256 `8b6c0298b17b7ede0fabb58a264953f0ccfa5e880e89a8d472b3644e870003d7`.

Regenerado:1.858.702bytes, SHA256 `{diag['generatedSha256']}`. Se conserva comprimido dentro del paquete, separado del histórico restaurado.

Se observan71 diferencias escalares: las mismas69 diferencias de hashes de tablas ya documentadas y dos diferencias nuevas:

| Función | Campo | Histórico | Regenerado |
|---|---|---:|---:|
| modification_source_material | after.functions[153].oid | 20452 | 20453 |
| modification_counterparty | after.functions[154].oid | 20453 | 20454 |

Ambas funciones están ausentes del catálogo `before` y presentes en `after`. Todos sus restantes atributos coinciden, incluidos cuerpo, firma, propietario, ACL, search_path, seguridad y tipo de retorno. `before` y `changedBodies` son idénticos; los nombres y el número de tablas131 también. La prueba C16 existente compara los datos antes/después dentro de la ejecución y conserva por OID todas las funciones preexistentes; esa prueba pasó.

**No se ha demostrado un cambio funcional ni corrupción de datos.** Tampoco se ha demostrado qué asignación interna consumió el OID adicional: el entorno efímero ya había terminado. No se atribuye la diferencia al correctivo C12. La comparación suplementaria vigente exige que no existan diferencias fuera de las69 tablas y por ello devolvió error después del PASS de PostgreSQL. Se conserva ese FAIL sin relajar el comparador ni autorizar el hash nuevo.

Intervención mínima propuesta, pendiente de decisión específica: revisar la semántica de comparación de estos dos identificadores de funciones nuevas entre entornos efímeros, manteniendo identidad por nombre/firma, cuerpo y permisos exactos, el catálogo previo intacto y todas las pruebas de datos dentro de cada ejecución. No se propone cambiar el producto, snapshots, manifiestos o hashes históricos, ni reconstruir evidencia. Antes de reanudar, exigir contrapruebas que rechacen alteraciones de cuerpo, firma, ACL, propietario, funciones preexistentes, datos y rutas no autorizadas. No se aplica esa propuesta en esta actuación.

## Preservación

El wrapper finalizó con `restorationComplete=true`, cero cambios históricos inesperados y código real0 de PostgreSQL. Restauró F01, F02, preservation.log y F16 a sus bytes, permisos y tipos originales. Expected independiente24417bytes conserva SHA256 `b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639`. Manifiestos y snapshots originales intactos.

Las223 entradas del inventario mantienen el estado autorizado:217 directamente iguales, cuatro representaciones gzip autorizadas, el auditor autorizado y la guarda compartida con su transición independiente. Las221 entradas distintas de esas dos guardas conservan sus bytes lógicos. Las tres evidencias pendientes previas se mantienen exactas. El fixture C12 es una ruta histórica adicional protegida y dispone de su transición literal autorizada; no forma parte de esas223 entradas.

Las rutas suplementarias actuales se justifican e inventarían individualmente. Solo las rutas literales admitidas se aceptan con sus tipos, permisos, tamaños y hashes sellados. El paquete incluye el diff exacto `authorized-changes.patch`, preflight, recibos, comandos, tiempos, stdout/stderr, FAIL originales y resultados. Los programas de continuación no ejecutados quedan como código de trazabilidad, sin que su presencia acredite ejecución o cierre.

## Pérdidas y anomalía separadas

- build.log: **ORIGINAL NO RECUPERADO**,545bytes, SHA256 `063f7ffad5445d9b2a45a17aceb16a01a6dfbbe70032787c0fdd02ea690fd0fa`.
- health-independent.log: **ORIGINAL NO RECUPERADO**,202bytes, SHA256 `2794076bee6b763f2a15c62a692735addf3e6b08e4fa296266b92953489f6f30`.

Las salidas nuevas no recuperan esos originales ni sustituyen sus hashes históricos. R67/R030 permanece como anomalía histórica independiente de causa no demostrada; no reapareció en esta suite. Hosted/Production no acreditados.

## Evidencias y STOP

[Paquete de verificaciones](verification-evidence.tar.gz): {len(packed)}bytes, SHA256 `{sha(packed)}`, {len(files)} entradas comprobadas mediante inventario interno. `stop-diagnosis.json` y `f16-new-difference-diagnosis.json` contienen la discrepancia precisa; `gates/postgres-full/preservation/` contiene stdout/stderr, restauración y F16 regenerado. [Inventario final](final-inventory.json) conserva también los inventarios anteriores y el FAIL C12 original de la ejecución previa.

Se detiene la actuación sin nuevas regresiones, ampliación de excepciones, cierre, commit o push. H5-011/012, H6 y conectores reales no se inician. La siguiente decisión corresponde a la revisión humana del bloqueo F16.
'''
with (d/'report.md').open('x') as f:f.write(report)
v=json.loads((d/'supplemental-inventory.json').read_bytes())
for name,purpose in [('supplemental-inventory.json','Immutable initial C12 inventory seal'),('verification-evidence.tar.gz','Full C12 execution including expected failures and new F16 comparison STOP'),('report.md','Accountable C12 results and exact F16 block; no closure claim')]:
 b=(d/name).read_bytes();v['entries'].append(dict(path=prefix+name,type='regular',mode='0644',bytes=len(b),sha256=sha(b),purpose=purpose,provenance='Current C12 authorized execution on base '+base+' plus fingerprint '+candidate['inputSha256']))
with (d/'final-inventory.json').open('xb') as f:f.write(jb(v))
seal=sha(jb(v));(o/'stop-final-seal.txt').write_text(seal+'\n');print(json.dumps(dict(status='STOP',archiveSha256=sha(packed),archiveBytes=len(packed),archiveEntries=len(files),inventorySha256=seal,functions=details),indent=2))
