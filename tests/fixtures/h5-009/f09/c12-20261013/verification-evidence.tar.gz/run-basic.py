import pathlib,subprocess,os,shutil
out=pathlib.Path(__file__).parent
for name,args in [('typecheck',['pnpm','typecheck']),('lint',['pnpm','lint']),('unit',['pnpm','test']),('audit',['pnpm','audit','--prod','--json'])]:
 p=subprocess.run(['python3',str(out/'run-gate.py'),name,*args]);
 if p.returncode:raise SystemExit(p.returncode)
d=out/'frozen-install';d.mkdir();
for name in ['package.json','pnpm-lock.yaml']:shutil.copy2(name,d/name)
p=subprocess.run(['python3',str(out/'run-gate.py'),'frozen','pnpm','install','--frozen-lockfile'],env={**os.environ,'CI':'1','F09_GATE_CWD':str(d)})
raise SystemExit(p.returncode)
