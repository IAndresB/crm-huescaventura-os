import pathlib,os,subprocess,json
out=pathlib.Path(__file__).parent;env={**os.environ,'C12_TRUST_SHA256':(out/'trust-seal.txt').read_text().strip(),'F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/supplemental-inventory.json','F09_INVENTORY_SHA256':(out/'inventory-anchor.txt').read_text().strip()}
for name,cmd in [('classification',['python3',str(out/'run-counterproofs.py')]),('prior-transitions',['node','--experimental-strip-types',str(out/'F08-F09-direct.mjs')])]:
 with (out/(name+'-runner.log')).open('xb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 if p.returncode:print((out/(name+'-runner.log')).read_text()[-5000:]);raise SystemExit(p.returncode)
