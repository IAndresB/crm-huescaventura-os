import pathlib,subprocess,os,json
out=pathlib.Path(__file__).parent;env={**os.environ,'C12_TRUST_SHA256':(out/'trust-seal.txt').read_text().strip(),'F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/supplemental-inventory.json','F09_INVENTORY_SHA256':(out/'inventory-anchor.txt').read_text().strip()}
for name in ['recovery-counterproofs','gzip-counterproofs','run-consumers','run-protected-gates','run-advisors-runner']:
 with (out/(name+'-execution.log')).open('xb') as f:p=subprocess.run(['python3',str(out/(name+'.py'))],env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 if p.returncode:print((out/(name+'-execution.log')).read_text()[-7000:]);raise SystemExit(p.returncode)
