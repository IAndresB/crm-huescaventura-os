import pathlib,json,shutil,subprocess,os
out=pathlib.Path(__file__).parent;s=json.loads((out/'test-state.json').read_bytes());t=pathlib.Path(s['candidateCopy']);r=pathlib.Path(s['root']);probe=t/'tests/integration/postgres-c12-temporal.test.ts';shutil.copy2(out/'temporal.test.ts',probe)
shutil.copy2(r/'tests/fixtures/h5-009/f09/c12-20261013/supplemental-inventory.json',t/'tests/fixtures/h5-009/f09/c12-20261013/supplemental-inventory.json')
try:
 p=subprocess.run(['python3',str(out/'run-gate.py'),'temporal-and-h4-014','node','scripts/test-postgres.mjs','postgres-c12-temporal.test.ts','postgres-h4-014.test.ts'],env={**os.environ,'F09_GATE_CWD':str(t)})
finally:probe.unlink()
raise SystemExit(p.returncode)
