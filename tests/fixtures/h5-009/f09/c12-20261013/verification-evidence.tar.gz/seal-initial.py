import pathlib,json,hashlib,stat,subprocess
r=pathlib.Path.cwd();o=r/'.git/c12-authorized/20261012T233543Z';d=r/'tests/fixtures/h5-009/f09/c12-20261013';prior=r/'tests/fixtures/h5-009/f09/completion-20261013/final-inventory.json';data=json.loads(prior.read_bytes());seen={e['path'] for e in data['entries']}
for p in [prior,*sorted(d.iterdir())]:
 rel=str(p.relative_to(r));assert rel not in seen
 s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode&0o777==0o644
 b=p.read_bytes();data['entries'].append(dict(path=rel,type='regular',mode='0644',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),provenance='Current human-authorized C12 run; Git eda8b0b plus exact current inputs',purpose='Independent trust and temporal correction evidence' if p.parent==d else 'Immutable pre-C12 STOP inventory'))
b=(json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode();(d/'supplemental-inventory.json').write_bytes(b);(o/'inventory-anchor.txt').write_text(hashlib.sha256(b).hexdigest()+'\n');(o/'tested-sha.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD']))
print(len(data['entries']),hashlib.sha256(b).hexdigest())
