import pathlib,json,hashlib,stat,gzip,subprocess
r=pathlib.Path.cwd();o=pathlib.Path(__file__).parent;p=json.loads((o/'preflight.json').read_bytes());trust=json.loads((r/'tests/fixtures/h5-009/f09/c12-20261013/trust.json').read_bytes());allowed={e['path']:e for e in trust['entries']};rows=[]
for e in p['snapshot223']:
 f=r/e['representation'];s=f.lstat();assert stat.S_ISREG(s.st_mode) and not f.is_symlink() and s.st_mode&0o777==int(e['mode'],8),e['path'];b=f.read_bytes()
 if e['representation']!=e['path']:b=gzip.decompress(b)
 expected=allowed[e['path']]['sha256'] if e['path'] in allowed else e['sha256'];assert hashlib.sha256(b).hexdigest()==expected,e['path'];rows.append(dict(path=e['path'],sha256=expected,representation=e['representation'],mode=e['mode'],authorizedTransition=e['path'] in allowed))
for e in p['pending']:
 f=r/e['path'];s=f.lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode&0o777==int(e['mode'],8);assert hashlib.sha256(f.read_bytes()).hexdigest()==e['sha256'],e['path']
for path,expected in [('specs/001-core-crm/expected-TSK-H5-009-010.md','b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639'),('tests/fixtures/h2-011/reproducer-F01-corrected.log','3d123ac41cf6a9da845dd89518fff92c4012db3ede9da6b90f44e69839821ccc'),('tests/fixtures/h2-011/reproducer-F02-corrected.log','e5edcf607bde904fc25e5f9665dc45922a96443f7762f97ce6bac4484d54b8ae'),('tests/fixtures/h4-012-f16/preservation.json','8b6c0298b17b7ede0fabb58a264953f0ccfa5e880e89a8d472b3644e870003d7')]:
 f=r/path;assert f.is_file() and not f.is_symlink() and f.stat().st_mode&0o777==0o644;assert hashlib.sha256(f.read_bytes()).hexdigest()==expected,path
modified=subprocess.check_output(['git','diff','--name-only']).decode().splitlines();assert sorted(modified)==sorted(allowed),modified
result=dict(status='PASS',snapshot223=rows,previousThreePendingPreserved=True,authorizedCodeChanges=modified,head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip())
with (o/'working-integrity.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('PASS: 223 authorized snapshot entries, original three pending evidence files, expected, F01/F02/F16; only three authorized code paths changed')
