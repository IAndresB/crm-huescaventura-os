import pathlib,json,hashlib,tarfile,subprocess,gzip,stat
r=pathlib.Path.cwd();o=pathlib.Path(__file__).parent;rel='tests/fixtures/h5-009/f09/completion-20261012/';d=r/rel;sha=lambda b:hashlib.sha256(b).hexdigest();rep=json.loads((d/'representation.json').read_bytes())['items'];mapped={x['path']:x for x in rep};pre=json.loads((o/'preflight.json').read_bytes());changes=[]
for e in pre['entries']:
 p=e['path']
 if p=='scripts/verify-h5-008-evidence.mjs':continue
 actual=r/(mapped[p]['compressedPath'] if p in mapped else p);s=actual.lstat();raw=gzip.decompress(actual.read_bytes()) if p in mapped else actual.read_bytes();assert stat.S_ISREG(s.st_mode) and format(s.st_mode&0o777,'04o')==e['mode'],p;assert len(raw)==e['bytes'] and sha(raw)==e['sha256'],p
 if p in mapped:changes.append(p)
assert len(changes)==5
candidate=json.loads((d/'candidate.json').read_bytes());counts={n:json.loads((o/f'{n}.json').read_bytes()) for n in ['classification-counterproofs','recovery-counterproofs','gzip-counterproofs','F08-F09-direct','wrapper-counterproofs']};assert all(x['status']=='PASS' for x in counts.values())
summary=dict(status='LOCAL VALIDATION PASS; documentary closure pending',scope='H5-009/010 local/isolated',baseCommit=candidate['baseCommit'],candidateInputSha256=candidate['inputSha256'],auditorSha256=sha((r/'scripts/verify-h5-008-evidence.mjs').read_bytes()),counts={'R52':1,'H3':75,'focalH4H5':70,'postgres':2473,'unit':171,'health':1,'F05':18,'F01':12,'F08F09':40,'classification':29,'documentaryRecovery':13,'gzip':26,'wrapper':14},F16=json.loads((o/'f16-current-comparison.json').read_bytes()),R67_R030='Not reproduced in this run; historical cause remains undemonstrated',preservedOriginalsExceptAuditor=True,losslessPaths=changes,indexEmpty=not subprocess.check_output(['git','diff','--cached','--name-only']))
with (o/'validation-summary.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
text=f'''# H5-009/010 — validación local tras las cinco conversiones autorizadas

Estado: controles locales PASS; cierre documental pendiente. Base `{candidate['baseCommit']}`, fingerprint `{candidate['inputSha256']}`, auditor SHA256 `{summary['auditorSha256']}`. Resultados sobre el estado de trabajo identificado; todavía no son pruebas de un nuevo commit.

Las cinco representaciones de representation.json conservan exactamente los bytes descomprimidos y sus hashes. Los manifiestos e inventarios anteriores permanecen intactos. El auditor reconoce solo las cinco parejas literales y rechaza ausencia, alteración, symlink, permisos o coexistencia raw no autorizada. Las demás rutas anteriores conservan sus bytes, tipos y permisos, salvo el correctivo autorizado del auditor.

R52 PASS en cuatro órdenes y fallo inducido; grupo H3 75/75; focal H4/H5 70/70; PostgreSQL completa2473/2473 sin FAIL/skipped/cancelled; unitarias171/171; health1/1; build, frozen install, typecheck, lint, auditoría producción y V-MIG PASS. Advisors oficiales sobre57 migraciones por loopback PASS, ambas tablas B09 comprobadas. F01 12, F05 18, F08/F09 40, clasificación29, recuperación13, gzip26 y wrapper14 contrapruebas esperadas. F10/F12 y H5-008 preservados. Staging íntegro en índice separado PASS; índice real vacío.

F16:131 tablas,69 hashes distintos entre ejecuciones, exactamente las mismas tablas de la comparación previa; sin diferencias en el resto del documento. C16 acredita preservación dentro de la ejecución, rollback y retry. El wrapper restauró los cuatro artefactos y no detectó cambios tracked ajenos. R67/R030 no reaparece; su causa histórica continúa sin atribuirse.

Se conservan tres FAIL de preparación y sus retests. F01 montaba R52 como symlink; solo en el arnés desechable se añadió R52 a la lista copyFile, sin cambiar aserciones ni el archivo protegido. Advisors: primer nombre temporal excedía103 bytes del socket macOS; segundo intento directo carecía del Storage local requerido. El retest utiliza el runner aislado existente, un nombre corto y la misma CLI oficial. Estos FAIL no se borran ni se presentan como ejecuciones exitosas.

build.log y health-independent.log históricos: ORIGINAL NO RECUPERADO. Sus referencias originales siguen inmutables. La salida observada de build empaquetada no adquiere el hash del original perdido. La sustitución documental autorizada queda verificada mediante nuevas ejecuciones y su sello independiente.

Este paquete conserva logs, scripts de montaje, estados, comparaciones y el FAIL de cada intento. No cierra aún F09 ni H5-009/010. Antes de cerrar: candidato commit exacto, comprobaciones atribuibles a ese SHA y cierre de los documentos permitidos por el contrato histórico. Sin tareas posteriores ni conectores reales.
'''
with (d/'report.md').open('x') as f:f.write(text)
entries=[];members=[]
for p in sorted(o.rglob('*')):
 if not p.is_file() or p.name.endswith('.index') or 'frozen-install' in p.relative_to(o).parts:continue
 b=p.read_bytes();name=str(p.relative_to(o));entries.append(dict(path=name,bytes=len(b),sha256=sha(b)));members.append((p,name))
(o/'archive-members.json').write_text(json.dumps(entries,indent=2)+'\n')
with tarfile.open(d/'verification-evidence.tar.gz','x:gz') as tf:
 for p,name in members:tf.add(p,arcname=name,recursive=False)
 tf.add(o/'archive-members.json',arcname='archive-members.json',recursive=False)
inv=json.loads((d/'supplemental-inventory.json').read_bytes())
for name in ['supplemental-inventory.json','verification-evidence.tar.gz','report.md']:
 p=d/name;b=p.read_bytes();inv['entries'].append(dict(path=rel+name,type='regular',mode='0644',bytes=len(b),sha256=sha(b),provenance='Current authorized gzip continuation and protected regression',purpose='Sealed phase validation: '+name))
raw=(json.dumps(inv,indent=2,ensure_ascii=False)+'\n').encode()
with (d/'final-inventory.json').open('xb') as f:f.write(raw)
(o/'final-anchor.txt').write_text(sha(raw)+'\n');print('ANCHOR',sha(raw));print('ARCHIVE',sha((d/'verification-evidence.tar.gz').read_bytes()))
