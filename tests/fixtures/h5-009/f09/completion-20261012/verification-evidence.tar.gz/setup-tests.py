import pathlib,subprocess,tempfile,shutil,json,os,hashlib
r=pathlib.Path.cwd();o=pathlib.Path('/Users/andres/Developer/crm-huescaventura-os/.git/f09-gzip-completion/20261012T214819Z');prior=r/'.git/f09-auditor-limited/20261012T205221Z-93895cee';t=pathlib.Path(tempfile.mkdtemp(prefix='crm-f09-verified-'));a=subprocess.check_output(['git','archive','HEAD']);subprocess.run(['tar','-x','-C',str(t)],input=a,check=True)
files=subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z']).decode().split('\0')
for p in filter(None,files):(t/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,t/p)
os.symlink(r/'.git',t/'.git');(t/'node_modules').mkdir(exist_ok=True)
for p in (r/'node_modules').iterdir():os.symlink(p,t/'node_modules'/p.name)
state={'root':str(r),'output':str(o),'candidateCopy':str(t),'baseHead':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'auditorSha256':hashlib.sha256((r/'scripts/verify-h5-008-evidence.mjs').read_bytes()).hexdigest(),'baselineControl':'tests/fixtures/h5-009/f09/recovery-20261012T202326Z/preflight-inventory.json'}
(o/'test-state.json').write_text(json.dumps(state,indent=2)+'\n')
s=(prior/'run-counterproofs.py').read_text().replace("Original223 snapshot plus immutable snapshot control in a disposable copy; other post-snapshot recovery documents excluded from this fixture only, not admitted or removed from the real workspace","Complete current checkout including all recovery documents and sealed supplemental evidence; no evidence omitted")
(o/'run-counterproofs.py').write_text(s);shutil.copy2(prior/'F08-F09-direct.mjs',o/'F08-F09-direct.mjs');print(t)
