import pathlib,json,hashlib,os,subprocess
out=pathlib.Path(__file__).parent;state=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(state['candidateCopy']);record=json.loads((root/'tests/fixtures/h5-009/f09/completion-20261013/representation.json').read_bytes());env={**os.environ,'F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/completion-20261013/supplemental-inventory.json','F09_INVENTORY_SHA256':(out/'inventory-anchor.txt').read_text().strip()};rows=[]
def run(name):
 p=subprocess.run(['node','--experimental-strip-types','scripts/verify-h5-008-evidence.mjs'],cwd=root,env=env,capture_output=True,timeout=90)
 for suffix,b in [('stdout',p.stdout),('stderr',p.stderr)]:
  with (out/(name+'.'+suffix+'.log')).open('xb') as f:f.write(b)
 rows.append(dict(name=name,exit=p.returncode,expected=1,verified=p.returncode==1,stderrSha256=hashlib.sha256(p.stderr).hexdigest()));print(name,'FAIL expected' if p.returncode==1 else 'UNEXPECTED',flush=True);assert p.returncode==1,name
try:
 for i,e in enumerate(record['items']):
  p=root/e['compressedPath'];raw=p.read_bytes()
  for kind in ['byte','absent','symlink','permissions','coexisting-raw']:
   try:
    if kind=='byte':p.write_bytes(bytes([raw[0]^1])+raw[1:])
    elif kind=='absent':p.unlink()
    elif kind=='symlink':p.unlink();p.symlink_to(pathlib.Path(state['root'])/e['compressedPath'])
    elif kind=='permissions':p.chmod(0o600)
    else:(root/e['path']).write_text('unauthorized raw replacement\n')
    run('gzip-'+str(i+1)+'-'+kind)
   finally:
    if p.is_symlink():p.unlink()
    p.write_bytes(raw);p.chmod(0o644)
    if (root/e['path']).exists():(root/e['path']).unlink()
 # The pinned original source hashes cannot be replaced by the lost original hash.
 path=root/'tests/fixtures/h5-009/f09/completion-20261013/representation.json';raw=path.read_bytes()
 try:path.write_bytes(raw.replace(b'171ec560',b'063f7ffa'));run('gzip-26-false-original-hash')
 finally:path.write_bytes(raw)
finally:
 with (out/'gzip-counterproofs.json').open('x') as f:json.dump(dict(status='PASS' if len(rows)==26 and all(x['verified'] for x in rows) else 'STOP',rows=rows),f,indent=2);f.write('\n')
