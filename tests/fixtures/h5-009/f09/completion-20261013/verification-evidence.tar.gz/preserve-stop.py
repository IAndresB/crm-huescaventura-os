import pathlib,json,hashlib,gzip,tarfile,io,subprocess,datetime,stat
root=pathlib.Path.cwd();out=pathlib.Path(__file__).parent.resolve();prefix='tests/fixtures/h5-009/f09/completion-20261013/';dest=root/prefix;sha=(out/'tested-sha.txt').read_text().strip();digest=lambda b:hashlib.sha256(b).hexdigest();jb=lambda v:(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode();pg=out/'gates/postgres-full/preservation';stdout=(pg/'postgres.stdout.log').read_bytes();stderr=(pg/'postgres.stderr.log').read_bytes();wrapper=json.loads((pg/'status.json').read_bytes());assert wrapper['result']['exitCode']==1 and wrapper['restorationComplete'] and not wrapper['unexpectedTrackedChanges'];assert b'\xe2\x84\xb9 pass 2472' in stdout and b'\xe2\x84\xb9 fail 1' in stdout
assert subprocess.check_output(['git','status','--porcelain'])==b''
files=['tests/integration/postgres-h4-014.test.ts','tests/support/h4-cancellation-fixtures.ts','tests/support/h4-confirmation-fixtures.ts','supabase/migrations/20261005223726_h4_cancellation_right.sql','supabase/migrations/20261005202444_h4_operational_modification.sql','supabase/migrations/20261003093202_h3_customer_payment_reconciliation.sql'];sources=[]
for path in files:
 b=(root/path).read_bytes();assert b==subprocess.check_output(['git','show',sha+':'+path]);sources.append(dict(path=path,bytes=len(b),sha256=digest(b)))
diag={'status':'STOP','observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedSha':sha,'candidateInputSha256':json.loads((dest/'candidate.json').read_bytes())['inputSha256'],'newBlocker':{'case':'H4-014 C12 AC042 full civil day 2026-10-13T00:01:00+02:00','error':'CANCELLATION_EVIDENCE_REQUIRED:E3','location':'tests/integration/postgres-h4-014.test.ts:17','suite':{'tests':2473,'pass':2472,'fail':1,'cancelled':0,'skipped':0},'startedAtUtc':json.loads((out/'gates/postgres-full/status.json').read_bytes())['startedAtUtc'],'endedAtUtc':json.loads((out/'gates/postgres-full/status.json').read_bytes())['endedAtUtc'],'staticTrace':['C12 uses fixed command/facts at=2026-10-13T00:01:00+02:00 (2026-10-12T22:01:00Z).','cancellationFixture attest calls conf.proof without supplying the command instant.','confirmationFixture captures at=new Date().toISOString(); conf.proof uses that value for occurredAt.','cancellation SQL requires modification_proof; modification_proof calls payment_evidence; payment_evidence requires occurred_at<=at_time.','Suite started at 22:20Z, after the fixed command instant. Thus fresh evidence is too late for this case.'],'confidence':'Source chain and execution interval demonstrate inconsistent fixture chronology; no new controlled reproduction or correction after STOP; generated database row was not retained.','recommendedScope':'Make only the affected test fixture construct an explicit consistent synthetic chronology, preserving product evidence authority and all civil-day expected assertions. Inventory any protected-file transition for specific approval before editing.','notExecutedAfterFailure':['retest','advisors57 final candidate','documentary closure','final commit','push']},'stdout':{'path':'gates/postgres-full/preservation/postgres.stdout.log','bytes':len(stdout),'sha256':digest(stdout)},'stderr':{'path':'gates/postgres-full/preservation/postgres.stderr.log','bytes':len(stderr),'sha256':digest(stderr)},'wrapper':{'restorationComplete':True,'unexpectedTrackedChanges':[],'childExit':1,'artifacts':wrapper['artifacts']},'sources':sources,'scope':'H5-009/010 local/isolated','F09':'OPEN','F06_F07_F08':'local controls passed; global closure pending','R67_R030':'independent historical anomaly, cause not demonstrated, not the current failure','candidateCommitAlreadyCreatedBeforeFailure':sha,'finalCommitCreated':False,'published':False}
with (out/'stop-diagnosis.json').open('x') as f:f.write(jb(diag).decode())
# Source excerpts and exact hashes enable diagnosis without rewriting any protected source.
with (out/'stop-source-trace.txt').open('x') as f:
 for p,lo,hi in [('tests/integration/postgres-h4-014.test.ts',15,18),('tests/support/h4-cancellation-fixtures.ts',38,44),('tests/support/h4-confirmation-fixtures.ts',6,7),('tests/support/h4-confirmation-fixtures.ts',17,18),('supabase/migrations/20261005223726_h4_cancellation_right.sql',103,106),('supabase/migrations/20261005202444_h4_operational_modification.sql',85,87),('supabase/migrations/20261003093202_h3_customer_payment_reconciliation.sql',73,80)]:
  f.write('\n'+p+'\n');lines=(root/p).read_text().splitlines();f.write('\n'.join(str(n)+': '+lines[n-1] for n in range(lo,hi+1))+'\n')
excludedDrafts=['prepare-closure-draft.py','closure-counterproofs.py','seal-and-apply-closure.py'];drafts=[dict(path=n,sha256=digest((out/n).read_bytes()),status='NOT EXECUTED; invalidated by global FAIL; no closure claims applied') for n in excludedDrafts]
with (out/'unexecuted-closure-drafts.json').open('x') as f:f.write(jb(drafts).decode())
entries=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(out)
 if 'frozen-install' in rel.parts or p.name.endswith('.index') or p.name in excludedDrafts:continue
 entries.append((str(rel),p.read_bytes(),p.stat().st_mode&0o777))
manifest={'status':'STOP','testedSha':sha,'entries':[dict(path=p,bytes=len(b),sha256=digest(b),mode=oct(m)[2:].zfill(4)) for p,b,m in entries]};buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
 for p,b,m in entries+[('archive-inventory.json',jb(manifest),0o644)]:
  info=tarfile.TarInfo(p);info.size=len(b);info.mode=m;tar.addfile(info,io.BytesIO(b))
packed=gzip.compress(buf.getvalue(),mtime=0)
with (dest/'verification-evidence.tar.gz').open('xb') as f:f.write(packed)
with tarfile.open(fileobj=io.BytesIO(packed),mode='r:gz') as tar:
 for e in manifest['entries']:assert digest(tar.extractfile(e['path']).read())==e['sha256']
report=f'''# H5-009/010 — STOP en revalidación del candidato

**No hay PASS global ni cierre. F09 OPEN; F06–F08 con controles locales aprobados y cierre global pendiente.**

Candidato realmente probado: `{sha}`. Huella ejecutable: `{diag['candidateInputSha256']}`. Se creó este commit local candidato antes de la revalidación definitiva. No se ha creado commit documental final ni publicado. Rama main; origin/main permanece en `fdbd08bafdc6651d1ad6867242cd71791a25deb6`, divergencia 8/0 antes de añadir este informe. El PASS previo a ese commit se conserva por separado y no se atribuye al nuevo SHA.

## Bloqueo nuevo

PostgreSQL completa: **2472/2473 PASS, 1 FAIL, 0 cancelados, 0 omitidos**, exit 1. Caso `H4-014 C12 AC042 full civil day 2026-10-13T00:01:00+02:00`; error `CANCELLATION_EVIDENCE_REQUIRED:E3`, `tests/integration/postgres-h4-014.test.ts:17`. Ejecución {diag['newBlocker']['startedAtUtc']} → {diag['newBlocker']['endedAtUtc']}.

La cadena de fuentes muestra una incoherencia temporal del fixture: C12 fija el acto en `2026-10-12T22:01:00Z`, mientras `confirmationFixture` crea la evidencia con la hora real al ejecutarse. La regresión comenzó a las22:20Z. `cancellationFixture.attest` utiliza esa evidencia; `modification_proof` delega en `payment_evidence`, que exige `occurred_at <= at_time`. La nueva evidencia resulta posterior al acto fijo y se rechaza. El error, el intervalo y las fuentes están conservados. No se ha ejecutado una reproducción adicional ni aplicado un correctivo; no se dispone de la fila generada después del cierre del entorno aislado.

**STOP aplicado sin retest, cambios de producto o ampliaciones de transiciones.** Este fallo es independiente de R52 y de R67/R030. R67/R030 continúa abierta como anomalía histórica de causa no demostrada.

## Controles del candidato ya terminados

| Control | Resultado |
|---|---|
| R52: A primero, B primero, simultáneo, inverso y fallo inducido | PASS |
| H3-006 completo | 75/75 PASS |
| Focales H4/H5, incluido V-MIG fresh/upgrade poblado/rollback/retry | 70/70 PASS |
| Unitarias | 171/171 PASS |
| Health independiente | 1/1 PASS |
| Frozen install, typecheck, lint/import boundaries, build | PASS |
| Auditoría de dependencias de producción | PASS, cero vulnerabilidades informadas |
| F01 | 12 controles esperados PASS, copia con R52 regular |
| F05 | 18 controles esperados PASS tras aislar el índice Git del arnés |
| F08/F09, recuperación, gzip, wrapper | 40 / 13 / 26 / 14 controles esperados PASS |
| Clasificación del auditor | 29 controles cubiertos; FAIL de arnés y retest separados |
| F10/F12 y preservación H5-008 | PASS antes de la regresión |
| Diff de todo el candidato preparado respecto al baseline | PASS |
| PostgreSQL completa | **FAIL: 2472/2473** |
| Advisors57 final, certificado/cierre y publicación | No ejecutados tras STOP |

El primer F05 compartía el índice Git actual con un archivo histórico temporal y por eso veía rutas posteriores ausentes. La corrección se limita al arnés desechable con GIT_INDEX_FILE propio, sin modificar las aserciones ni el auditor. Se conservan el FAIL original y las18 contrapruebas posteriores. El protocolo F01 usa una copia regular de R52 para respetar la guarda contra symlinks, sin cambiar expectativas.

## Preservación

El wrapper devuelve el código real1, conserva stdout/stderr y restaura F01, F02, preservation.log y F16 con bytes, permisos0644 y tipo regular exactos. `restorationComplete=true`; `unexpectedTrackedChanges=[]`. Expected de24.417bytes SHA-256 `b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639` intacto; manifiestos históricos intactos.

Las223 rutas del snapshot se conservan:218 directamente iguales, cuatro mediante las representaciones gzip byte a byte autorizadas y una correspondiente al auditor corregido. No se han aplicado las siete transiciones documentales de cierre. La quinta conversión gzip es la copia de recuperación adicional. Los documentos de estado conservan F09 OPEN.

La comparación F16 después del FAIL vuelve a mostrar diferencias de digest en las mismas69 de131 tablas, sin otras diferencias del documento. Los UUID sintéticos varían entre ejecuciones; C16 mantiene su contraste dentro de la misma ejecución. El JSON histórico permanece restaurado. El wrapper no acredita por sí solo la corrección de datos.

## Dos originales no recuperados

- build.log: **ORIGINAL NO RECUPERADO**,545bytes, SHA-256 `063f7ffad5445d9b2a45a17aceb16a01a6dfbbe70032787c0fdd02ea690fd0fa`.
- health-independent.log: **ORIGINAL NO RECUPERADO**,202bytes, SHA-256 `2794076bee6b763f2a15c62a692735addf3e6b08e4fa296266b92953489f6f30`.

La autorización excepcional y las nuevas comprobaciones sustitutorias siguen registradas; no equivalen a recuperar los originales ni a PASS global. Las evidencias anteriores y sus hashes permanecen intactos.

## Evidencias y trazabilidad

[Paquete de la ejecución](verification-evidence.tar.gz): {len(packed)}bytes, SHA-256 `{digest(packed)}`; {len(entries)} entradas verificadas por inventario interno. Incluye `stop-diagnosis.json`, `stop-source-trace.txt`, `f16-stop-comparison.json`, stdout/stderr completos, códigos reales, contrapruebas y FAIL/retests. Los tres borradores de automatización de cierre no se ejecutaron; solo se registra su identidad y estado, sin aplicar ni publicar sus afirmaciones previstas.

PostgreSQL stdout: {len(stdout)}bytes, SHA-256 `{digest(stdout)}`. PostgreSQL stderr: {len(stderr)}bytes, SHA-256 `{digest(stderr)}`. [Inventario suplementario sellado](final-inventory.json): rutas literales, tipos, permisos, tamaños y hashes. El sello externo de su invocación queda en el recibo local de auditoría posterior; no se incorpora un hash autorreferente.

## Correctivo propuesto, pendiente de autorización

Revisar exclusivamente la preparación temporal sintética del caso de cancelación: evidencia válida no posterior al instante de su comando, manteniendo las expectativas de día civil, autoridad, reglas monetarias y producto. La ruta candidata de helper es `tests/support/h4-cancellation-fixtures.ts`, hash actual `1c3e91375632a520893f4a92d2ffd969ff17a2012776a9e7a1abdc3e51c6ec03`. Es histórica; cualquier modificación necesita inventario y autorización de transición exacta antes de aplicarse. No se propone desplazar fechas sin más ni debilitar la guarda.

Contrapruebas exigibles: C12 completo en ambos lados del límite temporal, rechazo de evidencia posterior al acto, todos los permisos/aserciones originales, focal H4-014 y preservación de la transición exacta; después nueva regresión completa sobre otro candidato identificado. No se inicia ese correctivo en este STOP.

No se cierran H5-009/010 ni F09. No se inician H5-011/012, H6 ni conectores reales. Hosted/Production no acreditados.
'''
with (dest/'report.md').open('x') as f:f.write(report)
v=json.loads((dest/'supplemental-inventory.json').read_bytes())
for name in ['supplemental-inventory.json','verification-evidence.tar.gz','report.md']:
 path=prefix+name;assert not any(e['path']==path for e in v['entries']);b=(root/path).read_bytes();v['entries'].append(dict(path=path,type='regular',mode='0644',bytes=len(b),sha256=digest(b),purpose='Current candidate STOP evidence and new independent blocker; no closure accreditation',provenance='Actual '+sha+' execution and read-only source diagnosis after failure'))
with (dest/'final-inventory.json').open('xb') as f:f.write(jb(v))
seal=digest(jb(v));(out/'stop-final-seal.txt').write_text(seal+'\n');print(json.dumps({'status':'STOP','archiveBytes':len(packed),'archiveSha256':digest(packed),'entries':len(entries),'inventorySha256':seal,'stdoutSha256':digest(stdout)},indent=2))
