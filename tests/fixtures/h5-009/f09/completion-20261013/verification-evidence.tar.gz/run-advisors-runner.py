import pathlib,json,subprocess,os,hashlib
out=pathlib.Path(__file__).parent;state=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(state['candidateCopy']);primary=pathlib.Path(state['root']);name='postgres-h5-009-advisors-probe.test.ts';p=root/'tests/integration'/name
s=(out/'advisors-57-short-socket.mjs').read_text().replace("'/Users/andres/Developer/crm-huescaventura-os/tests/support/h5-boundary-isolated.ts'","'../support/h5-boundary-isolated.ts'")
s=s.replace("console.log('H5-009 advisors57 local loopback PASS; two B09 tables present:',await h.observer`select count(*)::int n from pg_tables where schemaname='crm_private' and tablename in ('b09_event_receipts','b09_external_event_keys')`);","const rows=await h.observer`select count(*)::int n from pg_tables where schemaname='crm_private' and tablename in ('b09_event_receipts','b09_external_event_keys')`;assert.equal(rows[0].n,2);console.log('H5-009 advisors57 local loopback PASS; both B09 tables verified');")
with p.open('x') as f:f.write(s)
with (out/name).open('x') as f:f.write(s)
try:
 result=subprocess.run(['python3',str(out/'run-gate.py'),'advisors57-with-isolated-runner','node','scripts/test-postgres.mjs',name],cwd=primary,env={**os.environ,'F09_GATE_CWD':str(root)})
 with (out/'advisors-final-fixture.json').open('x') as f:json.dump(dict(fixture=name,sha256=hashlib.sha256(s.encode()).hexdigest(),basis='Existing isolated runner sets the required real local Storage runtime; short socket label; no historical fixture changes',exit=result.returncode),f,indent=2)
finally:p.unlink()
raise SystemExit(result.returncode)
