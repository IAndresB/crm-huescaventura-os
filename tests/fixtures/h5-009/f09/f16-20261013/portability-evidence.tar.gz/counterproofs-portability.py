import pathlib,subprocess,json,os,hashlib,datetime,gzip
out=pathlib.Path(__file__).parent;state=json.loads((out/'clean-copy.json').read_bytes());root=pathlib.Path(state['copy']);prefix='tests/fixtures/h5-009/f09/f16-20261013/';seal=(out/'phase1-seal.txt').read_text().strip();rows=[];logs=out/'counterproofs';logs.mkdir()
base_env={**os.environ,'GIT_OPTIONAL_LOCKS':'0','F16_TRUST_SHA256':seal,'C12_TRUST_SHA256':'eff6a0afc814707138913bdd3a2270e7458f5029d9569ce42d2b46bbe45f80f0','F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/final-inventory.json','F09_INVENTORY_SHA256':'847ef52f945eb5eedf66f3ee58a07ccaf43967a40267b1d0097d58532e3c2ce9'}
def run(name,expected=0,reason=None,portable=False,env=None):
 cmd=['python3','-B',prefix+'verify.py','--seal',seal,'--auditor'] if portable else ['node','--experimental-strip-types','scripts/verify-h5-008-evidence.mjs']
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,cwd=root,env=env or base_env,capture_output=True)
 with (logs/(name+'.stdout.log')).open('xb') as f:f.write(p.stdout)
 with (logs/(name+'.stderr.log')).open('xb') as f:f.write(p.stderr)
 ok=p.returncode==expected and (reason is None or reason in p.stderr.decode())
 rows.append(dict(case=name,expectedExit=expected,exit=p.returncode,reason=reason,verified=ok,command=cmd,startedAtUtc=start,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),stdoutSha256=hashlib.sha256(p.stdout).hexdigest(),stderrSha256=hashlib.sha256(p.stderr).hexdigest()))
 print(name,'PASS' if ok else 'UNEXPECTED',flush=True)
 assert ok,p.stderr.decode()[-2500:]
def mutate(name,path,operation,reason,portable=False):
 p=root/path;raw=p.read_bytes();mode=p.stat().st_mode&0o777
 try:
  if operation=='byte':p.write_bytes(raw+b' ')
  elif operation=='missing':p.unlink()
  elif operation=='mode':p.chmod(0o600)
  elif operation=='symlink':p.unlink();p.symlink_to('authorization.json')
  run(name,1,reason,portable)
 finally:
  if p.is_symlink() or p.exists():p.unlink()
  p.write_bytes(raw);p.chmod(mode)
try:
 run('01-clean-portable-audit-and-43-probes',portable=True)
 env={**base_env};env.pop('F16_TRUST_SHA256');run('02-absent-external-seal',1,'F16 independent trust seal required',env=env)
 run('03-wrong-external-seal',1,'F16 independent trust seal',env={**base_env,'F16_TRUST_SHA256':'0'*64})
 for name,op,reason in [('04-missing-package','missing','ENOENT'),('05-package-byte','byte','F16 supplemental hash'),('06-package-symlink','symlink','F16 regular file'),('07-package-permissions','mode','F16 exact permissions')]:mutate(name,prefix+'verification-evidence.tar.gz',op,reason)
 mutate('08-authorization-absent',prefix+'authorization.json','missing','ENOENT')
 mutate('09-authorization-changed',prefix+'authorization.json','byte','F16 supplemental hash')
 mutate('10-trust-record-changed',prefix+'trust.json','byte','F16 independent trust seal')
 mutate('11-prior-auditor-changed',prefix+'auditor-before.mjs.gz','byte','F16 supplemental hash')
 mutate('12-auditor-third-version','scripts/verify-h5-008-evidence.mjs','byte','F16 externally sealed auditor')
 mutate('13-portable-verifier-third-version',prefix+'verify.py','byte','F16 supplemental hash')
 mutate('14-C12-trust-changed','tests/fixtures/h5-009/f09/c12-20261013/trust.json','byte','AssertionError')
 mutate('15-independent-expected-changed','specs/001-core-crm/expected-TSK-H5-009-010.md','byte','AssertionError')
 mutate('16-historical-F16-changed','tests/fixtures/h4-012-f16/preservation.json','byte','AssertionError')
 mutate('17-historical-F01-changed','tests/fixtures/h2-011/reproducer-F01-corrected.log','byte','AssertionError')
 mutate('18-historical-manifest-changed','tests/fixtures/h5-008/definitive/verification.json','byte','AssertionError')
 for name,path in [('19-unknown-supplement',prefix+'unlisted.json'),('20-unknown-other-path','tests/fixtures/h5-009/f09/unlisted-f16.json')]:
  p=root/path
  try:p.write_text('{}\n');run(name,1,'unlisted posterior path')
  finally:p.unlink()
 # Restore the previous approved context, without this new folder, in the clone only.
 p=root/prefix;aside=root.parent/'f16-package-aside';auditor=root/'scripts/verify-h5-008-evidence.mjs';current=auditor.read_bytes();before=gzip.decompress((p/'auditor-before.mjs.gz').read_bytes())
 try:
  p.rename(aside);auditor.write_bytes(before);env={**base_env};env.pop('F16_TRUST_SHA256');run('21-prior-C12-context-unchanged',env=env)
 finally:aside.rename(p);auditor.write_bytes(current)
 run('22-clean-copy-restored-portable-audit',portable=True)
finally:
 with (out/'portability-counterproofs.json').open('x') as f:json.dump(dict(status='PASS' if len(rows)==22 and all(x['verified'] for x in rows) else 'STOP',trustSeal=seal,candidate=state,currentAuditorSha256=hashlib.sha256((root/'scripts/verify-h5-008-evidence.mjs').read_bytes()).hexdigest(),newPostgresExecution=False,rows=rows),f,indent=2);f.write('\n')
