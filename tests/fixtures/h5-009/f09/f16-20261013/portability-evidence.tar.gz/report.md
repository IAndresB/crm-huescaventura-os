# Incorporacion reproducible F16 - validacion local

Alcance: incorporacion suplementaria, sin cierre F09, commit ni publicacion.
Paquete F16 original y comparador conservados byte a byte. Auditor modificado
unicamente para rutas literales y una transicion sellada externamente.
Los 22 pendientes previos se conservan salvo el auditor autorizado;
expected, F01/F02/F16, C12 y manifiestos historicos permanecen intactos.

## Ejecuciones y limites

- Fase1 en checkout principal: PASS.
- Primera copia limpia: FAIL de preparacion; F12 requeria
  node_modules/postgres/package.json. Log original conservado.
- pnpm install --frozen-lockfile --offline --ignore-scripts: exit0,
  30 paquetes reutilizados, cero descargados. Lockfile sin cambios.
- README corregido para declarar la dependencia del auditor completo.
- Fase2: 22/22 controles de incorporacion esperados; las dos comprobaciones
  portables positivas ejecutan tambien las 43 contrapruebas originales.
- Rechazos esperados: ausencia/sello incorrecto, ausencia/alteracion de paquete,
  symlink, permisos, autorizacion ausente/cambiada, registro alterado, tercera
  version del auditor/verificador, expected/F01/F16/manifiesto alterados y rutas
  desconocidas. El contexto C12 anterior sigue pasando.
- Copia nueva con los cambios autorizados superpuestos, sin directorios
  privados de ejecuciones del .git original, sin compartir indice y sin crear
  commits. Dependencias instaladas desde el lockfile y cache local.
- No se repite PostgreSQL: comparaciones sobre salidas archivadas y
  contrapruebas del comparador/preservacion. Ningun PASS cambia de candidato.

El paquete de esta fase se incorpora al registro final despues de Fase2.
El control positivo del sello final se entrega separadamente en el hilo;
los resultados de fase2 no se relabelan como pruebas de otro sello.

## Estado

F09 OPEN; H5-009/010 sin cierre. build.log y health-independent.log siguen
ORIGINAL NO RECUPERADO. R67/R030 conserva causa no demostrada. STOP para
cierre, commit y publicacion. No H5-011/012, H6 ni conectores reales.
