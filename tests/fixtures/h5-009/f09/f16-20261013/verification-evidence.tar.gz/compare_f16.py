"""Supplemental F16 comparison. Only two newly-created function OIDs vary.
Historical JSON remains byte-frozen. Known cross-run table digests require the
unchanged C16 in-run data preservation assertions to have actually passed.
"""
import copy, hashlib, json, pathlib, re
HISTORICAL_SHA256='8b6c0298b17b7ede0fabb58a264953f0ccfa5e880e89a8d472b3644e870003d7'
TABLE_RECORD_SHA256='2faa2fbe8746e84164e180e149564584bc057029f84b940927dedf9efccdda2a'
C16_SOURCE_SHA256='6ba6413979bfeae2eb32ad1e396884c14c5f4822ba4042a8e7c9a5cd489335b1'
HEADERS={
 'CREATE OR REPLACE FUNCTION crm_private.modification_source_material(src jsonb, bid uuid, sid uuid, s text, material jsonb)': ('crm_private','modification_source_material','jsonb,uuid,uuid,text,jsonb'),
 'CREATE OR REPLACE FUNCTION crm_private.modification_counterparty(p jsonb, mid uuid, bid uuid, s text)': ('crm_private','modification_counterparty','jsonb,uuid,uuid,text'),
}
sha=lambda b:hashlib.sha256(b).hexdigest()
def require(value,message):
 if not value:raise AssertionError(message)
def identity(row):
 require(isinstance(row,dict) and isinstance(row.get('body'),str),'function structure')
 header=row['body'].splitlines()[0]
 m=re.fullmatch(r'CREATE OR REPLACE (?:FUNCTION|PROCEDURE) ([a-z_][a-z_0-9]*)\.([a-z_][a-z_0-9]*)\((.*)\)',header)
 require(m and m[2]==row.get('proname'),'schema/name/signature in complete definition')
 # Exact declaration includes schema and signature; no normalizing functional text.
 return header

def compare(historical_raw,current_raw,known_tables,in_run_data_proven=False):
 require(sha(historical_raw)==HISTORICAL_SHA256,'frozen historical F16 hash')
 old=json.loads(historical_raw);new=json.loads(current_raw)
 require(new.keys()==old.keys(),'top-level structure')
 require(new['before']==old['before'],'preexisting before catalogue')
 require(new['changedBodies']==old['changedBodies'],'named original body transitions')
 require(new['after'].keys()==old['after'].keys(),'after catalogue structure')
 for key in old['after']:
  if key!='functions':require(new['after'][key]==old['after'][key],'protected after object: '+key)
 old_functions=old['after']['functions'];new_functions=new['after']['functions']
 require(len(old_functions)==len(new_functions),'function count')
 def index(rows):
  result={};oids=set()
  for row in rows:
   key=identity(row);require(key not in result,'duplicate function identity');oid=row.get('oid')
   require(type(oid)==int and 0<oid<2**32 and oid not in oids,'invalid or duplicate function OID');oids.add(oid);result[key]=row
  return result
 before=index(old['before']['functions']);a=index(old_functions);b=index(new_functions)
 require(a.keys()==b.keys(),'function identity/schema/signature set')
 require(set(HEADERS)<=a.keys() and not set(HEADERS)&before.keys(),'exactly named new functions, absent from before')
 observed=[]
 for key,previous in a.items():
  current=b[key]
  if key in HEADERS:
   require({k:v for k,v in previous.items() if k!='oid'}=={k:v for k,v in current.items() if k!='oid'},'functional attributes differ: '+key)
   observed.append(dict(schema=HEADERS[key][0],name=HEADERS[key][1],signature=HEADERS[key][2],historicalOid=previous['oid'],observedOid=current['oid'],definitionSha256=sha(current['body'].encode()),allOtherAttributesEqual=True))
  else:require(current==previous,'unapproved function or preexisting OID change: '+key)
 require(len(new['tables'])==len(old['tables']),'protected table count')
 differences=[]
 for previous,current in zip(old['tables'],new['tables']):
  require(current.keys()==previous.keys()=={'table','sha256'},'table record fields')
  require(current['table']==previous['table'],'table identity/order')
  require(isinstance(current['sha256'],str) and re.fullmatch('[a-f0-9]{64}',current['sha256']),'table digest format')
  if current!=previous:differences.append(previous['table'])
 require(not differences or sorted(differences)==sorted(known_tables),'unapproved protected table/data difference')
 require(not differences or in_run_data_proven,'known table digests require actual unchanged C16 data assertions')
 return dict(status='PASS',scope='H5-009/010 local/isolated',historicalSha256=sha(historical_raw),generatedSha256=sha(current_raw),functionCount=len(new_functions),beforeCatalogueEqual=True,otherCatalogueObjectsEqual=True,observedOids=observed,tableCount=len(new['tables']),tableDigestDifferences=differences,tableEvaluation='Separate nondeterministic cross-run digests; exact before/after data equality proved inside C16' if differences else 'Exact table digests',historicalDataReconstructionClaimed=False)

def compare_run(root,preservation):
 root=pathlib.Path(root);preservation=pathlib.Path(preservation)
 import gzip
 record=(root/'tests/fixtures/h5-009/f09/f16-comparison-full-postgres.json').read_bytes();require(sha(record)==TABLE_RECORD_SHA256,'unchanged 69-table diagnostic')
 known=json.loads(record)['comparison']['changedTableNames'];require(len(known)==69 and len(set(known))==69,'exact known table inventory')
 source=(root/'tests/integration/postgres-h4-012-f16.test.ts').read_bytes();require(sha(source)==C16_SOURCE_SHA256,'unchanged original C16 assertions')
 status=json.loads((preservation/'status.json').read_bytes());require(status['preflightPassed'] and status['result']['exitCode']==0 and status['restorationComplete'] and not status['unexpectedTrackedChanges'],'real suite success and exact restoration')
 stdout=(preservation/'postgres.stdout.log').read_text();require('✔ H4-012-F16 C16 populated43 upgrade DDL rollback retry all data and prior catalogue preserved except named bodies' in stdout,'C16 actually passed in this execution');require(re.search(r'ℹ fail 0\b',stdout),'suite zero failures')
 historical=(root/'tests/fixtures/h4-012-f16/preservation.json').read_bytes();generated=gzip.decompress((preservation/'generated/tests/fixtures/h4-012-f16/preservation.json.gz').read_bytes())
 return compare(historical,generated,known,True)
