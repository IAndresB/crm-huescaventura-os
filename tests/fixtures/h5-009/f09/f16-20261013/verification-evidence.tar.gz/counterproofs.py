import pathlib,json,copy,traceback,hashlib
from compare_f16 import compare,compare_run,HEADERS
out=pathlib.Path(__file__).parent;root=pathlib.Path.cwd();raw=(root/'tests/fixtures/h4-012-f16/preservation.json').read_bytes();original=json.loads(raw);known=json.loads((root/'tests/fixtures/h5-009/f09/f16-comparison-full-postgres.json').read_bytes())['comparison']['changedTableNames'];rows=[]
def run(name,mutate=lambda v:None,expected=True,proof=False):
 v=copy.deepcopy(original);mutate(v);b=(json.dumps(v,indent=2)+'\n').encode();error=None
 try:result=compare(raw,b,known,proof)
 except Exception as e:error=traceback.format_exc();result=None
 verified=bool(error)!=expected
 with (out/(name+'.log')).open('x') as f:f.write(error if error else json.dumps(result,indent=2)+'\n')
 rows.append(dict(name=name,expected='PASS' if expected else 'FAIL',observed='FAIL' if error else 'PASS',verified=verified,probeSha256=hashlib.sha256(b).hexdigest()));print(name,'PASS' if verified else 'UNEXPECTED',flush=True);assert verified,error or name

def chosen(v,i):return v['after']['functions'][i]
try:
 run('01-exact-historical')
 run('02-only-two-OIDs',lambda v:[chosen(v,i).update(oid=chosen(v,i)['oid']+10000) for i in [153,154]])
 for i in [153,154]:
  cases=[('body',lambda f:f.update(body=f['body']+'\n-- changed')),('signature',lambda f:f.update(body=f['body'].replace('src jsonb' if i==153 else 'p jsonb','src text' if i==153 else 'p text',1))),('schema',lambda f:f.update(body=f['body'].replace('crm_private.','public.',1))),('owner',lambda f:f.update(proowner=f['proowner']+1)),('acl',lambda f:f.update(proacl=[])),('volatility',lambda f:f.update(body=f['body'].replace(' STABLE\n',' VOLATILE\n',1))),('security',lambda f:f.update(prosecdef=not f['prosecdef'])),('search-path',lambda f:f.update(proconfig=['search_path=public'])),('return-type',lambda f:f.update(prorettype=23)),('arguments',lambda f:f.update(proargtypes='23')),('strict',lambda f:f.update(body=f['body'].replace(' STABLE\n',' STABLE STRICT\n',1))),('parallel',lambda f:f.update(body=f['body'].replace(' STABLE\n',' STABLE PARALLEL SAFE\n',1))),('leakproof',lambda f:f.update(body=f['body'].replace(' STABLE\n',' STABLE LEAKPROOF\n',1))),('extra-functional-field',lambda f:f.update(prosupport='unexpected'))]
  for name,fn in cases:run(str(i)+'-'+name,lambda v,fn=fn,i=i:fn(chosen(v,i)),False)
 run('31-missing-function',lambda v:v['after']['functions'].pop(),False)
 run('32-added-function',lambda v:v['after']['functions'].append(copy.deepcopy(chosen(v,153))),False)
 run('33-preexisting-object',lambda v:v['after']['relations'][0].update(relowner=0),False)
 run('34-third-OID',lambda v:chosen(v,0).update(oid=999999),False)
 run('35-before-object',lambda v:v['before']['functions'][0].update(oid=999999),False)
 run('36-protected-data-outside69',lambda v:v['tables'][0].update(sha256='0'*64),False)
 run('37-table-disappeared',lambda v:v['tables'].pop(),False)
 run('38-changed-bodies-list',lambda v:v['changedBodies'].append('unexpected'),False)
 def known_change(v):
  for t in v['tables']:
   if t['table'] in known:t['sha256']='0'*64
 run('39-known69-without-in-run-proof',known_change,False)
 run('40-only-one-of-known69',lambda v:next(t for t in v['tables'] if t['table'] in known).update(sha256='0'*64),False,True)
 run('41-duplicate-OID',lambda v:chosen(v,153).update(oid=chosen(v,0)['oid']),False)
 run('42-invalid-OID',lambda v:chosen(v,153).update(oid=-1),False)
 run('43-only-allowed-OID-order',lambda v:v['after']['functions'].__setitem__(slice(153,155),list(reversed(v['after']['functions'][153:155]))))
 # Recorded previous execution is an input example, never credited as a new regression.
 result=compare_run(root,root/'.git/c12-authorized/20261012T233543Z/gates/postgres-full/preservation')
 with (out/'prior-execution-reclassification.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
finally:
 with (out/'counterproofs.json').open('x') as f:json.dump(dict(status='PASS' if len(rows)==43 and all(x['verified'] for x in rows) else 'STOP',rows=rows),f,indent=2);f.write('\n')
