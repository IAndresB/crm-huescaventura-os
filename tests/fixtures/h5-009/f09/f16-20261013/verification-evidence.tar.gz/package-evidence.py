import datetime, gzip, hashlib, json, pathlib, stat, tarfile

out = pathlib.Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
assert json.loads((out / 'final-integrity.json').read_bytes())['status'] == 'PASS'
assert (out / 'report.md').is_file()
excluded = {'evidence-inventory.json', 'verification-evidence.tar.gz', 'package-receipt.json'}
rows = []
for path in sorted(out.rglob('*')):
    if path.is_dir() or '__pycache__' in path.parts or path.name in excluded:
        continue
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode), path
    data = path.read_bytes()
    rows.append(dict(path=path.relative_to(out).as_posix(), type='regular',
                     mode=f'{stat.S_IMODE(s.st_mode):04o}', bytes=len(data), sha256=sha(data)))
inventory = out / 'evidence-inventory.json'
with inventory.open('x') as f:
    json.dump(dict(scope='F16 supplemental local correction; no historical manifest changes',
                   selfReferenceExcluded=True, entries=rows), f, indent=2)
    f.write('\n')
archive = out / 'verification-evidence.tar.gz'
with archive.open('xb') as sink:
    with gzip.GzipFile(filename='', mode='wb', fileobj=sink, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for row in rows:
                tar.add(out / row['path'], arcname=row['path'], recursive=False)
            tar.add(inventory, arcname=inventory.name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    assert set(tar.getnames()) == {row['path'] for row in rows} | {inventory.name}
    for row in rows:
        member = tar.getmember(row['path'])
        assert member.isfile() and member.size == row['bytes'] and member.mode == int(row['mode'], 8), row['path']
        assert sha(tar.extractfile(member).read()) == row['sha256'], row['path']
    assert tar.extractfile(inventory.name).read() == inventory.read_bytes()
receipt = dict(status='PASS', createdAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               entries=len(rows), archiveEntries=len(rows)+1,
               inventorySha256=sha(inventory.read_bytes()),
               archiveBytes=archive.stat().st_size, archiveSha256=sha(archive.read_bytes()),
               originalInputsUnchanged=True, historicalManifestUpdated=False,
               committed=False, published=False)
with (out / 'package-receipt.json').open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps(receipt, indent=2))
