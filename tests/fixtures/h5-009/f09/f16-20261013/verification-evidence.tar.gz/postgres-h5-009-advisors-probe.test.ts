import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {isolatedBoundaries} from '../support/h5-boundary-isolated.ts';
const label='h509_adv',port=59119;
const help=spawnSync('npx',['--yes','supabase@2.119.0','db','advisors','--help'],{encoding:'utf8',timeout:45000});
console.log(help.stdout);console.error(help.stderr);assert.equal(help.status,0);assert.match(help.stdout,/--db-url/);assert.match(help.stdout,/--fail-on/);
const h=await isolatedBoundaries(label,port);
try{
 const result=spawnSync('npx',['--yes','supabase@2.119.0','db','advisors','--db-url',`postgresql://crm_h0_migration@127.0.0.1:${port}/${label}?sslmode=disable`,'--type','all','--fail-on','error'],{encoding:'utf8',timeout:45000});
 console.log(result.stdout);console.error(result.stderr);assert.equal(result.status,0);assert.deepEqual(JSON.parse(result.stdout).results,[]);
 const rows=await h.observer`select count(*)::int n from pg_tables where schemaname='crm_private' and tablename in ('b09_event_receipts','b09_external_event_keys')`;assert.equal(rows[0].n,2);console.log('H5-009 advisors57 local loopback PASS; both B09 tables verified');
}finally{await h.close();}
