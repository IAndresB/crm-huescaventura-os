import pathlib,subprocess,json,hashlib,stat,gzip,datetime,os
r=pathlib.Path('/Users/andres/Developer/crm-huescaventura-os');os.chdir(r);old=r/'.git/c12-authorized/20261012T233543Z';o=r/'.git/f16-corrective'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');o.mkdir(parents=True);(r/'.git/f16-corrective/current-run.txt').write_text(str(o)+'\n');sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *args:subprocess.check_output(['git',*args]).decode().strip()
assert git('branch','--show-current')=='main';assert git('rev-parse','HEAD')=='eda8b0becb3daa2dff1baa02be53cec914750f13';assert git('rev-parse','origin/main')=='fdbd08bafdc6651d1ad6867242cd71791a25deb6';assert git('rev-list','--left-right','--count','HEAD...origin/main').split()==['8','0'];assert not git('diff','--cached','--name-only')
v=json.loads((r/'tests/fixtures/h5-009/f09/c12-20261013/candidate.json').read_bytes());assert v['inputSha256']=='e55e6b06fefcf3591eee71b02f96e5d2cafebbae8579fcbac93fce75908ed2c9';assert sha(json.dumps(v['inputs'],separators=(',',':'),ensure_ascii=False).encode())==v['inputSha256']
for e in v['inputs']:
 p=r/e['path'];s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode&0o777==int(e['mode'],8);assert sha(p.read_bytes())==e['sha256'],e['path']
trust=json.loads((r/'tests/fixtures/h5-009/f09/c12-20261013/trust.json').read_bytes());assert sorted(git('diff','--name-only').splitlines())==sorted(e['path'] for e in trust['entries'])
for e in trust['entries']:assert sha((r/e['path']).read_bytes())==e['sha256']
prior=json.loads((old/'preflight.json').read_bytes());allowed={e['path']:e['sha256'] for e in trust['entries']}
for e in prior['snapshot223']:
 p=r/e['representation'];s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_mode&0o777==int(e['mode'],8);b=p.read_bytes();b=gzip.decompress(b) if e['path']!=e['representation'] else b;assert sha(b)==allowed.get(e['path'],e['sha256'])
files=set(filter(None,subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z']).decode().split('\0')));rows=[]
for path in sorted(files):
 p=r/path;s=p.lstat();assert stat.S_ISREG(s.st_mode);b=p.read_bytes();rows.append(dict(path=path,type='regular',mode=oct(s.st_mode&0o777)[2:].zfill(4),bytes=len(b),sha256=sha(b)))
env={**os.environ,'C12_TRUST_SHA256':(old/'trust-seal.txt').read_text().strip(),'F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/final-inventory.json','F09_INVENTORY_SHA256':(old/'stop-final-seal.txt').read_text().strip()}
p=subprocess.run(['node','--experimental-strip-types','scripts/verify-h5-008-evidence.mjs'],env=env,capture_output=True);(o/'preflight-auditor.stdout.log').write_bytes(p.stdout);(o/'preflight-auditor.stderr.log').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode()[-2000:]
(o/'preflight.json').write_text(json.dumps(dict(status='PASS',head=git('rev-parse','HEAD'),originMain=git('rev-parse','origin/main'),divergence='8/0',indexEmpty=True,inputSha256=v['inputSha256'],pending=rows,snapshot223='PASS with exact prior transitions',auditorExit=p.returncode),indent=2)+'\n');print(o);print('PASS:',len(rows),'pending files inventoried; 223 protected entries verified')
