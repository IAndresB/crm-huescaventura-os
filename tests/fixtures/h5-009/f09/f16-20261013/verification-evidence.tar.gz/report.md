# F16 — correctivo limitado de comparación suplementaria

## Resultado y punto de parada

Correctivo y revalidación solicitada: **PASS local/aislado**. F09 permanece **OPEN**. No se cierra H5-009/010, no se crea commit y no se publica. No se ejecutan H5-011/012, H6 ni conectores reales. Este informe no declara cierre global.

## Candidato y preservación

- Rama: main. HEAD/base probado: `eda8b0becb3daa2dff1baa02be53cec914750f13`.
- origin/main: `fdbd08bafdc6651d1ad6867242cd71791a25deb6`; divergencia 8/0; índice vacío.
- Huella de los 433 archivos de entrada: `e55e6b06fefcf3591eee71b02f96e5d2cafebbae8579fcbac93fce75908ed2c9`.
- Se conservan exactamente las 22 rutas pendientes de entrada y las tres modificaciones C12 ya autorizadas. Esta intervención no modifica ningún archivo versionado del checkout.
- Las 223 entradas se mantienen en su representación autorizada: 217 directas idénticas, cuatro representaciones comprimidas sin pérdida y dos guardas con transiciones C12 preexistentes. No se añade ninguna transición histórica.
- El comparador nuevo se identifica además por su SHA-256; la huella del candidato de producto no incluye herramientas suplementarias alojadas en `.git`.
- `git diff --check`: PASS. No se prepara el índice; no se atribuye a un índice vacío la validación de un conjunto staged.
- Los comandos, tiempos, salidas y códigos reales figuran en `gates/*/status.json`, los recibos de contrapruebas y `environment.json`. Node v24.21.0, PostgreSQL 17.11 local, pnpm 11.19.0.

## Causa y alcance del cambio

El rechazo provenía de `.git/c12-authorized/20261012T233543Z/run-protected-gates.py`: comparaba literalmente todo el catálogo suplementario, incluidos los OID de dos funciones que no existían antes de la migración. Se conserva el archivo original y su FAIL. La nueva ejecución utiliza una copia del runner que delega en `compare_f16.py`. El diff íntegro está en `comparator.patch`.

Ambas funciones son creadas por `supabase/migrations/20261005215404_h4_modification_counterparty.sql` (SHA-256 `077b415c5c04f014fefb36aa752ae02ac5d8e87344628ddefa5bf0b32f4ce3b1`). Son nuevas respecto de los 153 procedimientos anteriores; el catálogo posterior tiene exactamente 155.

PostgreSQL asigna el OID al insertar el nuevo objeto en `pg_proc` mediante `GetNewOidWithIndex`. Su numeración entre bases creadas separadamente no constituye identidad funcional. No se ha reconstruido qué asignación intermedia concreta produjo el desplazamiento observado en la ejecución anterior. Referencias: [tipos OID](https://www.postgresql.org/docs/17/datatype-oid.html), [implementación de ProcedureCreate](https://raw.githubusercontent.com/postgres/postgres/REL_17_STABLE/src/backend/catalog/pg_proc.c), [pg_get_functiondef](https://www.postgresql.org/docs/17/functions-info.html).

La comparación exige exactamente esquema, nombre, firma, definición completa, cuerpo, argumentos, retorno, propietario, ACL, configuración, seguridad y todos los demás campos presentes. La definición completa de `pg_get_functiondef` conserva los atributos funcionales declarados. Únicamente se omite la igualdad numérica del campo `oid` de esas dos identidades literales. Se rechazan OID inválidos/duplicados, otras funciones, cambios del catálogo previo y diferencias en los restantes objetos.

| Identidad exacta | OID histórico | Focal nuevo | PostgreSQL completo nuevo |
|---|---:|---:|---:|
| `crm_private.modification_source_material(jsonb,uuid,uuid,text,jsonb)` | 20452 | 20452 | 20452 |
| `crm_private.modification_counterparty(jsonb,uuid,uuid,text)` | 20453 | 20453 | 20453 |

El ejemplo previo con desplazamiento 20452→20453 y 20453→20454 se conserva y se reevalúa en `prior-execution-reclassification.json`. Esa reevaluación es una prueba del comparador sobre evidencia anterior, no una ejecución nueva de PostgreSQL.

## Las 69 diferencias de hashes de tablas

Se registran **separadamente** en `f16-focal-comparison.json` y `f16-current-comparison.json`; no se eliminan ni se normalizan sus hashes. Se exige el inventario exacto de 69 tablas del diagnóstico congelado `f16-comparison-full-postgres.json`, cuyo hash está anclado. Una tabla adicional, ausente o una diferencia parcial de ese inventario falla.

La aceptación suplementaria exige además que el C16 original, con su SHA-256 inalterado, haya pasado realmente en la misma ejecución: igualdad íntegra de los datos antes/después de rollback y upgrade, y preservación del catálogo previo. El wrapper debe haber terminado con exit 0 y restauración exacta. Sin esa prueba interna, incluso las 69 diferencias conocidas se rechazan. Los hashes entre ejecuciones no permiten reconstruir los datos históricos originales: no se afirma esa reconstrucción ni se acepta de forma general una discrepancia de datos.

## Resultados nuevos

| Control | Resultado | Detalle | Evidencia |
|---|---|---|---|
| Contrapruebas del comparador | PASS | 43/43 respuestas esperadas | counterproofs.json y logs individuales |
| Clasificación/preservación | PASS | 29/29, incluye F10/F12/H5-008 | classification-counterproofs.json |
| F05 | PASS | 18/18, índice temporal independiente | f05-index-isolated/result.json |
| F07/F08/F09 | PASS | 40/40 transiciones y rechazos esperados | F08-F09-direct.json |
| F01 | PASS | 12/12 contrapruebas | f01-retest/result.json |
| f01 | PASS | exit 0 | gates/f01/status.json |
| f16-focal | PASS | 26/26; FAIL 0; omitidos 0 | gates/f16-focal/status.json |
| focal-h4-h5 | PASS | 70/70; FAIL 0; omitidos 0 | gates/focal-h4-h5/status.json |
| postgres-full | PASS | 2473/2473; FAIL 0; omitidos 0 | gates/postgres-full/status.json |
| advisors57-with-isolated-runner | PASS | exit 0 | gates/advisors57-with-isolated-runner/status.json |
| final-auditor | PASS | exit 0 | gates/final-auditor/status.json |

Los FAIL inducidos permanecen como FAIL esperado en sus logs. Los cambios de cuerpo, firma, esquema, propietario, ACL, volatilidad, seguridad, search_path, retorno, argumentos, strict, parallel, leakproof y atributos adicionales se rechazan para cada función. También se rechazan una función ausente/adicional, un objeto previo, un tercer OID y datos fuera de las garantías acreditadas.

F01–F09 se revisan con los controles anteriores, el auditor y la regresión completa; los estados documentales de cierre no se alteran. Los controles previos que no se repiten en esta intervención no se presentan como ejecuciones nuevas. En particular, la batería de contrapruebas del wrapper anterior se referencia con su hash y `newCounterproofExecution: false`; el wrapper no ha cambiado y cada ejecución actual acredita su propia restauración.

## Integridad histórica

| Archivo | Bytes | SHA-256 inalterado |
|---|---:|---|
| `specs/001-core-crm/expected-TSK-H5-009-010.md` | 24417 | `b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639` |
| `tests/fixtures/h2-011/reproducer-F01-corrected.log` | 904 | `3d123ac41cf6a9da845dd89518fff92c4012db3ede9da6b90f44e69839821ccc` |
| `tests/fixtures/h2-011/reproducer-F02-corrected.log` | 1917 | `e5edcf607bde904fc25e5f9665dc45922a96443f7762f97ce6bac4484d54b8ae` |
| `tests/fixtures/h2-011/preservation.log` | 312 | `3bc0004daa86ad07d66a3081190b23dfd89049397f12dab34418a9caa15eb9d9` |
| `tests/fixtures/h4-012-f16/preservation.json` | 1858702 | `8b6c0298b17b7ede0fabb58a264953f0ccfa5e880e89a8d472b3644e870003d7` |

Los manifiestos y las guardas permanecen inalterados respecto al preflight; el auditor final valida su cadena. Cada ejecución protegida conserva las salidas generadas en `gates/<ejecución>/preservation/generated/`, restaura todos los artefactos originales y confirma cero cambios históricos inesperados. El cuarto artefacto `h2-011/preservation.log` también está protegido por el wrapper existente.

F16 generado en focal: `c47cd8dccc577c6f4f6561bdc64772f465c0a77fae193b83dcd70168f625c963`.

F16 generado en regresión completa: `363fdb08cf84e4dcbb435d2478304c2f5555e52da1758dd55090ef3e2a8c79b9`.

## Inventario del correctivo

| Archivo | Bytes | SHA-256 |
|---|---:|---|
| `.git/c12-authorized/20261012T233543Z/run-protected-gates.py` | 3024 | `8d085eb5cf7635919cd712725b2c404a0451231cb674d4edfb8fc74c776219f9` |
| `.git/f16-corrective/20261013T001249Z/run-protected-gates.py` | 2018 | `7af5ef6ffc006c1e361a0705736cbb08b447c214d39cad4db5cbda9de3b4df3a` |
| `.git/f16-corrective/20261013T001249Z/compare_f16.py` | 5965 | `fd85642e0df6fd387781d813d0b0e2469efc5adb6ac95881b87430a82f80baf0` |

El archivo original del runner sigue intacto. Los archivos nuevos son herramientas y evidencia suplementaria local en esta carpeta `.git/f16-corrective/20261013T001249Z/`, sin incorporación a manifiestos históricos ni ampliación del allowlist. `evidence-inventory.json` registra ruta literal, tamaño, tipo, modo y SHA-256 de cada archivo empaquetado. El paquete no queda versionado automáticamente.

## Límites y asuntos pendientes

- `build.log`: **ORIGINAL NO RECUPERADO**, 545 bytes; SHA-256 histórico `063f7ffad5445d9b2a45a17aceb16a01a6dfbbe70032787c0fdd02ea690fd0fa`.
- `health-independent.log`: **ORIGINAL NO RECUPERADO**, 202 bytes; SHA-256 histórico `2794076bee6b763f2a15c62a692735addf3e6b08e4fa296266b92953489f6f30`.
- Se mantiene el registro de pérdida y la excepción documental previa; los hashes de salidas posteriores no sustituyen los originales.
- R67/R030 sigue como anomalía histórica independiente de causa no demostrada. No se le atribuye este correctivo.
- Esta comparación no demuestra igualdad entre todos los datos de bases históricas distintas: conserva las garantías exactas del C16 dentro de cada ejecución y documenta por separado los 69 digests variables.
- Se requiere revisión humana para continuar hacia cierre documental, incorporación de esta evidencia a un candidato publicable, commit final y publicación. F09 permanece OPEN; no se acredita Hosted/Production.

**STOP solicitado tras la revalidación.**
