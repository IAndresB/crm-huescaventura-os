import pathlib,json,subprocess,os
out=pathlib.Path(__file__).parent;env={**os.environ,'C12_TRUST_SHA256':(out/'trust-seal.txt').read_text().strip(),'F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/final-inventory.json','F09_INVENTORY_SHA256':(out/'inventory-anchor.txt').read_text().strip()}
steps=[('preservation',['python3',str(out/'run-counterproofs.py')]),('F07-F09',['node','--experimental-strip-types',str(out/'F08-F09-direct.mjs')]),('F01',['python3',str(out/'run-gate.py'),'f01','node','--experimental-strip-types',str(out/'f01-regular-fixture-retest.mjs')]),('F16',['python3',str(out/'run-f16.py')]),('global',['python3',str(out/'run-protected-gates.py')]),('advisors',['python3',str(out/'run-advisors-runner.py')]),('final-auditor',['python3',str(out/'run-gate.py'),'final-auditor','node','--experimental-strip-types','scripts/verify-h5-008-evidence.mjs'])]
for name,cmd in steps:
 with (out/(name+'-execution.log')).open('xb') as f:p=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(name,p.returncode,flush=True)
 if p.returncode:print((out/(name+'-execution.log')).read_text()[-6000:]);raise SystemExit(p.returncode)
