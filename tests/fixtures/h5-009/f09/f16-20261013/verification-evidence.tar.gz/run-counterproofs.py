import json,pathlib,subprocess,hashlib,os,datetime
out=pathlib.Path(__file__).parent;state=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(state['root']);copy=pathlib.Path(state['candidateCopy']);rows=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
def run(name,expected=0,reason=None,script='scripts/verify-h5-008-evidence.mjs',cwd=copy):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();command=['node','--experimental-strip-types',script];p=subprocess.run(command,cwd=cwd,capture_output=True,timeout=60)
 stdout=out/(name+'.stdout.log');stderr=out/(name+'.stderr.log')
 for file,b in [(stdout,p.stdout),(stderr,p.stderr)]:
  with file.open('xb') as f:f.write(b)
 text=(p.stdout+p.stderr).decode();okay=p.returncode==expected and (reason is None or reason in text)
 row={'case':name,'command':command,'cwd':str(cwd),'startedAtUtc':start,'endedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'expectedExit':expected,'expectedReason':reason,'verified':okay,'stdout':{'path':str(stdout),'bytes':len(p.stdout),'sha256':sha(p.stdout)},'stderr':{'path':str(stderr),'bytes':len(p.stderr),'sha256':sha(p.stderr)},'auditorSha256':state['auditorSha256']};rows.append(row);print(name,('PASS' if expected==0 else 'FAIL expected') if okay else 'UNEXPECTED',flush=True)
 if not okay:raise AssertionError(text[:4000])
 return p

def changed(name,path,fn,reason=None):
 p=copy/path;b=p.read_bytes();mode=p.lstat().st_mode&0o777
 try:p.write_bytes(fn(b));run(name,1,reason)
 finally:p.write_bytes(b);p.chmod(mode)

def deleted(name,path):
 p=copy/path;b=p.read_bytes();mode=p.lstat().st_mode&0o777;p.unlink()
 try:run(name,1,'ENOENT')
 finally:p.write_bytes(b);p.chmod(mode)

def symlinked(name,path):
 p=copy/path;b=p.read_bytes();mode=p.lstat().st_mode&0o777;p.unlink();os.symlink(root/path,p)
 try:run(name,1,'file type')
 finally:p.unlink();p.write_bytes(b);p.chmod(mode)

def permissions(name,path):
 p=copy/path;mode=p.lstat().st_mode&0o777;p.chmod(0o600)
 try:run(name,1,'permissions')
 finally:p.chmod(mode)
try:
 run('01-preexisting-intact-and-R52-corrected')
 cache='supabase/.temp/cli-latest'
 changed('02-preexisting-one-byte',cache,lambda b:bytes([b[0]^1])+b[1:],'preexisting snapshot hash')
 deleted('03-preexisting-deleted',cache)
 symlinked('04-preexisting-symlink',cache)
 permissions('05-preexisting-permissions',cache)
 permissions('06-auditor-permissions','scripts/verify-h5-008-evidence.mjs')
 changed('07-snapshot-tampered',state['baselineControl'],lambda b:bytes([b[0]^1])+b[1:],'immutable preexisting snapshot')
 unknown='tests/fixtures/h5-009/f09/unlisted-limited-auditor-probe.txt';p=copy/unknown
 with p.open('xb') as f:f.write(b'UNAUTHORIZED SUPPLEMENT\n')
 try:run('08-unknown-supplement',1,'unlisted posterior path: '+unknown)
 finally:p.unlink()
 changed('09-supplement-byte','tests/fixtures/h5-009/f09/audit-production.json',lambda b:b[:-1]+b' ','preexisting snapshot hash')
 changed('10-R52-third-version','tests/integration/postgres-h3-006.test.ts',lambda b:b+b' ','preexisting file bytes')
 deleted('11-R52-deleted','tests/integration/postgres-h3-006.test.ts')
 symlinked('12-R52-symlink','tests/integration/postgres-h3-006.test.ts')
 permissions('13-R52-permissions','tests/integration/postgres-h3-006.test.ts')
 changed('14-R52-transition-tampered','tests/fixtures/h5-009/f09/r52-transition.json',lambda b:bytes([b[0]^1])+b[1:],'preexisting snapshot hash')
 changed('15-original-manifest-tampered','tests/fixtures/h2-011/raw-log-manifest.json',lambda b:b+b' ')
 changed('16-independent-expected-tampered','specs/001-core-crm/expected-TSK-H5-009-010.md',lambda b:b+b' ')
 for tag,id in [('17-premature-H5-011','011'),('18-premature-H5-012','012'),('19-premature-H6','h6')]:
  def transform(b):
   t=b.decode();anchor='<a id="tsk-h6-001"></a>' if id=='h6' else '<a id="tsk-h5-'+id+'"></a>';at=t.index(anchor);tail=t[at:];assert 'Ejecución: NOT STARTED'in tail;return (t[:at]+tail.replace('Ejecución: NOT STARTED','Ejecución: COMPLETED',1)).encode()
  changed(tag,'specs/001-core-crm/tasks.md',transform)
 for n,environment in [(20,'Hosted'),(21,'Production')]:changed(str(n)+'-premature-'+environment,'specs/001-core-crm/evidence-TSK-H5-009-010.md',lambda b:b+('\n'+environment+': PASS acreditado sin evidencia.\n').encode())
 for n,path in [(22,'tests/fixtures/h2-011/reproducer-F01-corrected.log'),(23,'tests/fixtures/h2-011/reproducer-F02-corrected.log'),(24,'tests/fixtures/h4-012-f16/preservation.json')]:changed(str(n)+'-historical-artifact-tampered',path,lambda b:bytes([b[0]^1])+b[1:])
 run('25-F10','0' if False else 0,script='scripts/verify-h5-006-f10-preservation.mjs')
 run('26-F12',script='tests/fixtures/h5-006/f12/chain-counterexamples.mjs')
 run('27-H5-008-preservation')
 run('28-F05-retest',script=str(out/'f05-index-isolated-retest.mjs'))
 run('29-final-isolated-candidate')
finally:
 with (out/'classification-counterproofs.json').open('x') as f:json.dump({'status':'PASS' if len(rows)==29 and all(x['verified'] for x in rows) else 'STOP','candidate':state,'rows':rows,'scope':'Complete current checkout including all recovery documents and sealed supplemental evidence; no evidence omitted'},f,indent=2);f.write('\n')
