import pathlib,json,subprocess,shutil,os
from compare_f16 import compare_run
out=pathlib.Path(__file__).parent;s=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(s['candidateCopy']);store=root/'tests/fixtures/h5-009/f09/postgres-preservation';before=set(store.iterdir())
p=subprocess.run(['python3',str(out/'run-gate.py'),'f16-focal','node','tests/fixtures/h5-009/f09/run-postgres-preserving-artifacts.mjs','--','node','scripts/test-postgres.mjs','postgres-h4-012-f16.test.ts'],env={**os.environ,'F09_GATE_CWD':str(root)})
folders=set(store.iterdir())-before;assert len(folders)==1;folder=next(iter(folders));dest=out/'gates/f16-focal/preservation';shutil.move(str(folder),str(dest));assert p.returncode==0,'F16 focal failure: STOP'
comparison=compare_run(pathlib.Path(s['root']),dest)
with (out/'f16-focal-comparison.json').open('x') as f:json.dump(comparison,f,indent=2);f.write('\n')
print('F16 focal and exact OID-only comparison PASS',flush=True)
