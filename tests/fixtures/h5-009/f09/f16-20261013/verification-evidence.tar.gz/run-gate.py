import pathlib,subprocess,json,os,sys,datetime,gzip,hashlib
r=pathlib.Path('/Users/andres/Developer/crm-huescaventura-os');o=pathlib.Path(__file__).parent;name=sys.argv[1];cmd=sys.argv[2:];d=o/'gates'/name;d.mkdir(parents=True,exist_ok=False);candidate=json.loads((r/'tests/fixtures/h5-009/f09/c12-20261013/candidate.json').read_bytes());env={**os.environ,'POSTGRES_H0_BIN':'/Users/andres/Applications/Postgres.app/Contents/Versions/17/bin','NEXT_TELEMETRY_DISABLED':'1','F09_INVENTORY_PATH':'tests/fixtures/h5-009/f09/c12-20261013/final-inventory.json','F09_INVENTORY_SHA256':(o/'inventory-anchor.txt').read_text().strip()}
env['C12_TRUST_SHA256']=(o/'trust-seal.txt').read_text().strip()
for k in ['STORAGE_H1_ENDPOINT','DATABASE_URL','SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY']:env.pop(k,None)
cwd=pathlib.Path(os.environ.get('F09_GATE_CWD',str(r)));testedSha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip();assert testedSha==(o/'tested-sha.txt').read_text().strip();start=datetime.datetime.now(datetime.timezone.utc).isoformat();print(name,'START',candidate['inputSha256'],flush=True)
with (d/'output.log').open('xb') as f:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
raw=(d/'output.log').read_bytes();packed=gzip.compress(raw,mtime=0)
with (d/'output.log.gz').open('xb') as f:f.write(packed)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip()==testedSha
row=dict(sha=testedSha,name=name,command=cmd,cwd=str(cwd),candidateInputSha256=candidate['inputSha256'],baseCommit=candidate['baseCommit'],startedAtUtc=start,endedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=p.returncode,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),compressedSha256=hashlib.sha256(packed).hexdigest(),scope='local/isolated')
with (d/'status.json').open('x') as f:json.dump(row,f,indent=2);f.write('\n')
print(name,'PASS' if p.returncode==0 else 'FAIL',flush=True)
if p.returncode:print(raw.decode(errors='replace')[-5000:])
sys.exit(p.returncode)
