import pathlib,json,subprocess,os,shutil,hashlib,gzip,datetime
out=pathlib.Path(__file__).parent;state=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(state['candidateCopy']);primary=pathlib.Path(state['root']);assert json.loads((out/'wrapper-prior-counterproofs.json').read_bytes())['status']=='PASS';store=root/'tests/fixtures/h5-009/f09/postgres-preservation';env={**os.environ,'F09_GATE_CWD':str(root)};wrapper='tests/fixtures/h5-009/f09/run-postgres-preserving-artifacts.mjs'
# The exact wrapper and executable candidate are unchanged; the clone isolates
# incidental generated files from the user's preserved working tree.
for e in json.loads((primary/'tests/fixtures/h5-009/f09/c12-20261013/candidate.json').read_bytes())['inputs']:
 b=(root/e['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==e['sha256'],e['path']
for name,args in [('focal-h4-h5',['node','scripts/test-postgres.mjs','postgres-h4-006.test.ts','postgres-h4-021.test.ts','postgres-h5-008-migration.test.ts','postgres-h5-009-migration.test.ts','postgres-h5-009.test.ts']),('postgres-full',['pnpm','test:postgres'])]:
 before=set(store.iterdir());p=subprocess.run(['python3',str(out/'run-gate.py'),name,'node',wrapper,'--',*args],env=env,cwd=primary);new=set(store.iterdir())-before;assert len(new)==1;folder=next(iter(new));dest=out/'gates'/name/'preservation';shutil.move(str(folder),str(dest));status=json.loads((dest/'status.json').read_bytes());print(name,'child',status['result']['exitCode'],'restored',status['restorationComplete'],'unexpected',len(status['unexpectedTrackedChanges']),flush=True)
 assert p.returncode==0 and status['result']['exitCode']==0 and status['restorationComplete'] and not status['unexpectedTrackedChanges'],f'{name}: STOP; preserve original failed streams and do not retest'
 if name=='postgres-full':
  from compare_f16 import compare_run
  comparison=compare_run(primary,dest)
  with (out/'f16-current-comparison.json').open('x') as f:json.dump(comparison,f,indent=2);f.write('\n')
