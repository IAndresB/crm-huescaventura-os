import pathlib,json,subprocess,shutil,tempfile,os,hashlib,tarfile,io,difflib
r=pathlib.Path.cwd();o=pathlib.Path(__file__).parent.resolve();old=r/'.git/c12-authorized/20261012T233543Z';t=pathlib.Path(tempfile.mkdtemp(prefix='crm-f16-verified-'));subprocess.run(['tar','-x','-C',str(t)],input=subprocess.check_output(['git','archive','HEAD']),check=True)
for p in filter(None,subprocess.check_output(['git','ls-files','--modified','--others','--exclude-standard','-z']).decode().split('\0')):(t/p).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,t/p)
os.symlink(r/'.git',t/'.git');(t/'node_modules').mkdir(exist_ok=True)
for p in (r/'node_modules').iterdir():os.symlink(p,t/'node_modules'/p.name)
(o/'test-state.json').write_text(json.dumps(dict(root=str(r),output=str(o),candidateCopy=str(t),baseHead=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),auditorSha256=hashlib.sha256((r/'scripts/verify-h5-008-evidence.mjs').read_bytes()).hexdigest(),baselineControl='tests/fixtures/h5-009/f09/recovery-20261012T202326Z/preflight-inventory.json'),indent=2)+'\n')
for name in ['run-gate.py','run-counterproofs.py','f05-index-isolated-retest.mjs','f01-regular-fixture-retest.mjs','F08-F09-direct.mjs','run-advisors-runner.py','advisors-57-short-socket.mjs']:
 s=(old/name).read_text().replace(str(old),str(o)).replace('/var/folders/yl/gkcr80ts3q78l9tnv5943flc0000gn/T/crm-f09-verified-xwyl0ib7',str(t))
 if name=='run-gate.py':s=s.replace('c12-20261013/supplemental-inventory.json','c12-20261013/final-inventory.json')
 (o/name).write_text(s)
shutil.copy2(old/'trust-seal.txt',o/'trust-seal.txt');shutil.copy2(old/'stop-final-seal.txt',o/'inventory-anchor.txt');(o/'tested-sha.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD']))
# Reuse the already-verified, unchanged wrapper, with an explicitly historical receipt.
archive=(r/'tests/fixtures/h5-009/f09/c12-20261013/verification-evidence.tar.gz').read_bytes();assert hashlib.sha256(archive).hexdigest()=='5c4c792a9580e78be0e4077598ddfe5196bc9974fce614db42653fe3eb8630db'
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:b=tar.extractfile('wrapper-counterproofs.json').read()
assert b==(old/'wrapper-counterproofs.json').read_bytes();assert json.loads(b)['status']=='PASS'
wrapper='tests/fixtures/h5-009/f09/run-postgres-preserving-artifacts.mjs';wh=hashlib.sha256((r/wrapper).read_bytes()).hexdigest();assert wh=='24605fd931e9a1aa3c375650115b4c3fd2378741e9db3a9b8c1e6a2ca375caaf'
(o/'wrapper-prior-counterproofs.json').write_bytes(b);(o/'wrapper-validation-reference.json').write_text(json.dumps(dict(wrapper=wrapper,sha256=wh,priorProofArchiveSha256=hashlib.sha256(archive).hexdigest(),receiptSha256=hashlib.sha256(b).hexdigest(),newCounterproofExecution=False,currentExecutionRestorationCheckedSeparately=True),indent=2)+'\n')
p=o/'run-protected-gates.py';s=p.read_text().replace("out/'wrapper-counterproofs.json'","out/'wrapper-prior-counterproofs.json'");p.write_text(s)
(o/'comparator.patch').write_text(''.join(difflib.unified_diff((o/'run-protected-gates.before.py').read_text().splitlines(True),s.splitlines(True),fromfile='prior/run-protected-gates.py',tofile='corrected/run-protected-gates.py'))+'\n'+''.join(difflib.unified_diff([], (o/'compare_f16.py').read_text().splitlines(True),fromfile='/dev/null',tofile='corrected/compare_f16.py')))
print(t)
