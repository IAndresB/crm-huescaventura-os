import datetime, gzip, hashlib, json, os, pathlib, re, stat, subprocess

out = pathlib.Path(__file__).resolve().parent
root = pathlib.Path('/Users/andres/Developer/crm-huescaventura-os')
os.chdir(root)
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args]).decode().strip()
read = lambda path: json.loads(path.read_bytes())

def fingerprint(path):
    s = path.lstat()
    assert stat.S_ISREG(s.st_mode), str(path)
    data = path.read_bytes()
    return dict(type='regular', mode=f'{stat.S_IMODE(s.st_mode):04o}',
                bytes=len(data), sha256=sha(data))

pre = read(out / 'preflight.json')
assert git('branch', '--show-current') == 'main'
assert git('rev-parse', 'HEAD') == pre['head']
assert git('rev-parse', 'origin/main') == pre['originMain']
assert git('rev-list', '--left-right', '--count', 'HEAD...origin/main').split() == ['8', '0']
assert not git('diff', '--cached', '--name-only')
pending = set(filter(None, subprocess.check_output([
    'git', 'ls-files', '--modified', '--others', '--exclude-standard', '-z'
]).decode().split('\0')))
assert pending == {e['path'] for e in pre['pending']}, 'unexpected pending path'
for e in pre['pending']:
    assert fingerprint(root / e['path']) == {k: e[k] for k in ['type', 'mode', 'bytes', 'sha256']}, e['path']

candidate = read(root / 'tests/fixtures/h5-009/f09/c12-20261013/candidate.json')
assert sha(json.dumps(candidate['inputs'], separators=(',', ':'), ensure_ascii=False).encode()) == pre['inputSha256']
clone = pathlib.Path(read(out / 'test-state.json')['candidateCopy'])
for base in [root, clone]:
    for e in candidate['inputs']:
        assert fingerprint(base / e['path']) == {k: e[k] for k in ['type', 'mode', 'bytes', 'sha256']}, str(base / e['path'])

trust = read(root / 'tests/fixtures/h5-009/f09/c12-20261013/trust.json')
allowed = {e['path']: e['sha256'] for e in trust['entries']}
prior = read(root / '.git/c12-authorized/20261012T233543Z/preflight.json')
assert len(prior['snapshot223']) == 223
for e in prior['snapshot223']:
    p = root / e['representation']
    f = fingerprint(p)
    assert f['mode'] == e['mode'], e['path']
    data = p.read_bytes()
    if e['path'] != e['representation']:
        data = gzip.decompress(data)
    assert sha(data) == allowed.get(e['path'], e['sha256']), e['path']

frozen = [
    ('specs/001-core-crm/expected-TSK-H5-009-010.md', 24417, 'b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639'),
    ('tests/fixtures/h2-011/reproducer-F01-corrected.log', 904, '3d123ac41cf6a9da845dd89518fff92c4012db3ede9da6b90f44e69839821ccc'),
    ('tests/fixtures/h2-011/reproducer-F02-corrected.log', 1917, 'e5edcf607bde904fc25e5f9665dc45922a96443f7762f97ce6bac4484d54b8ae'),
    ('tests/fixtures/h2-011/preservation.log', 312, '3bc0004daa86ad07d66a3081190b23dfd89049397f12dab34418a9caa15eb9d9'),
    ('tests/fixtures/h4-012-f16/preservation.json', 1858702, '8b6c0298b17b7ede0fabb58a264953f0ccfa5e880e89a8d472b3644e870003d7'),
]
for path, size, digest in frozen:
    assert fingerprint(root / path) == dict(type='regular', mode='0644', bytes=size, sha256=digest), path
for e in read(out / 'source-inventory.json')['files']:
    assert sha((root / e['path']).read_bytes()) == e['sha256'], e['path']

gates = []
for name in ['f01', 'f16-focal', 'focal-h4-h5', 'postgres-full', 'advisors57-with-isolated-runner', 'final-auditor']:
    d = out / 'gates' / name
    receipt = read(d / 'status.json')
    assert receipt['exit'] == 0 and receipt['candidateInputSha256'] == pre['inputSha256'], name
    assert sha((d / 'output.log').read_bytes()) == receipt['sha256'], name
    if (d / 'preservation').exists():
        preserved = read(d / 'preservation/status.json')
        assert preserved['result']['exitCode'] == 0 and preserved['restorationComplete'], name
        assert not preserved['unexpectedTrackedChanges'] and not preserved['restoreErrors'], name
        assert all(a['restoredExact'] for a in preserved['artifacts']), name
        log = (d / 'preservation/postgres.stdout.log').read_text()
        counts = {key: int(re.findall(r'ℹ ' + key + r' (\d+)', log)[-1]) for key in ['tests', 'pass', 'fail', 'skipped']}
        assert counts['fail'] == 0 and counts['skipped'] == 0, name
        receipt['testCounts'] = counts
    gates.append(receipt)
for name in ['counterproofs.json', 'classification-counterproofs.json', 'f16-focal-comparison.json', 'f16-current-comparison.json']:
    assert read(out / name)['status'] == 'PASS', name
diff = subprocess.run(['git', 'diff', '--check'], capture_output=True)
assert diff.returncode == 0, diff.stdout.decode() + diff.stderr.decode()
with (out / 'final-integrity.json').open('x') as f:
    json.dump(dict(status='PASS', verifiedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   head=pre['head'], originMain=pre['originMain'], divergence='8/0', indexEmpty=True,
                   inputSha256=pre['inputSha256'], candidateInputsVerified=len(candidate['inputs']),
                   pendingFilesVerified=len(pending), snapshot223='PASS with only existing exact transitions',
                   frozen=[dict(path=p, **fingerprint(root / p)) for p, _, _ in frozen],
                   gitDiffCheckExit=diff.returncode, gates=gates,
                   historicalLogs='ORIGINAL NO RECUPERADO: build.log and health-independent.log',
                   F09='OPEN; no closure authorized in this task'), f, indent=2)
    f.write('\n')
print('Final integrity PASS: 22 pending files, 223 snapshot entries, 433 candidate inputs, unchanged index and base')
