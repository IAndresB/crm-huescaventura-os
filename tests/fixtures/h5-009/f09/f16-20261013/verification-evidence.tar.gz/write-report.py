import json, pathlib

out = pathlib.Path(__file__).resolve().parent
read = lambda name: json.loads((out / name).read_bytes())
final = read('final-integrity.json')
assert final['status'] == 'PASS'
focal = read('f16-focal-comparison.json')
full = read('f16-current-comparison.json')
old = read('prior-execution-reclassification.json')
counter = read('counterproofs.json')
classification = read('classification-counterproofs.json')
source = read('source-inventory.json')
gate_rows = []
for g in final['gates']:
    counts = g.get('testCounts')
    detail = f"{counts['pass']}/{counts['tests']}; FAIL {counts['fail']}; omitidos {counts['skipped']}" if counts else 'exit 0'
    gate_rows.append(f"| {g['name']} | PASS | {detail} | gates/{g['name']}/status.json |")
oid_rows = []
for i, row in enumerate(full['observedOids']):
    oid_rows.append(f"| `{row['schema']}.{row['name']}({row['signature']})` | {row['historicalOid']} | {focal['observedOids'][i]['observedOid']} | {row['observedOid']} |")
hash_rows = [f"| `{e['path']}` | {e['bytes']} | `{e['sha256']}` |" for e in final['frozen']]
source_rows = [f"| `{e['path']}` | {e['bytes']} | `{e['sha256']}` |" for e in source['files']]
text = f"""# F16 — correctivo limitado de comparación suplementaria

## Resultado y punto de parada

Correctivo y revalidación solicitada: **PASS local/aislado**. F09 permanece **OPEN**. No se cierra H5-009/010, no se crea commit y no se publica. No se ejecutan H5-011/012, H6 ni conectores reales. Este informe no declara cierre global.

## Candidato y preservación

- Rama: main. HEAD/base probado: `{final['head']}`.
- origin/main: `{final['originMain']}`; divergencia 8/0; índice vacío.
- Huella de los 433 archivos de entrada: `{final['inputSha256']}`.
- Se conservan exactamente las 22 rutas pendientes de entrada y las tres modificaciones C12 ya autorizadas. Esta intervención no modifica ningún archivo versionado del checkout.
- Las 223 entradas se mantienen en su representación autorizada: 217 directas idénticas, cuatro representaciones comprimidas sin pérdida y dos guardas con transiciones C12 preexistentes. No se añade ninguna transición histórica.
- El comparador nuevo se identifica además por su SHA-256; la huella del candidato de producto no incluye herramientas suplementarias alojadas en `.git`.
- `git diff --check`: PASS. No se prepara el índice; no se atribuye a un índice vacío la validación de un conjunto staged.
- Los comandos, tiempos, salidas y códigos reales figuran en `gates/*/status.json`, los recibos de contrapruebas y `environment.json`. Node v24.21.0, PostgreSQL 17.11 local, pnpm 11.19.0.

## Causa y alcance del cambio

El rechazo provenía de `.git/c12-authorized/20261012T233543Z/run-protected-gates.py`: comparaba literalmente todo el catálogo suplementario, incluidos los OID de dos funciones que no existían antes de la migración. Se conserva el archivo original y su FAIL. La nueva ejecución utiliza una copia del runner que delega en `compare_f16.py`. El diff íntegro está en `comparator.patch`.

Ambas funciones son creadas por `supabase/migrations/20261005215404_h4_modification_counterparty.sql` (SHA-256 `077b415c5c04f014fefb36aa752ae02ac5d8e87344628ddefa5bf0b32f4ce3b1`). Son nuevas respecto de los 153 procedimientos anteriores; el catálogo posterior tiene exactamente 155.

PostgreSQL asigna el OID al insertar el nuevo objeto en `pg_proc` mediante `GetNewOidWithIndex`. Su numeración entre bases creadas separadamente no constituye identidad funcional. No se ha reconstruido qué asignación intermedia concreta produjo el desplazamiento observado en la ejecución anterior. Referencias: [tipos OID](https://www.postgresql.org/docs/17/datatype-oid.html), [implementación de ProcedureCreate](https://raw.githubusercontent.com/postgres/postgres/REL_17_STABLE/src/backend/catalog/pg_proc.c), [pg_get_functiondef](https://www.postgresql.org/docs/17/functions-info.html).

La comparación exige exactamente esquema, nombre, firma, definición completa, cuerpo, argumentos, retorno, propietario, ACL, configuración, seguridad y todos los demás campos presentes. La definición completa de `pg_get_functiondef` conserva los atributos funcionales declarados. Únicamente se omite la igualdad numérica del campo `oid` de esas dos identidades literales. Se rechazan OID inválidos/duplicados, otras funciones, cambios del catálogo previo y diferencias en los restantes objetos.

| Identidad exacta | OID histórico | Focal nuevo | PostgreSQL completo nuevo |
|---|---:|---:|---:|
{chr(10).join(oid_rows)}

El ejemplo previo con desplazamiento 20452→20453 y 20453→20454 se conserva y se reevalúa en `prior-execution-reclassification.json`. Esa reevaluación es una prueba del comparador sobre evidencia anterior, no una ejecución nueva de PostgreSQL.

## Las 69 diferencias de hashes de tablas

Se registran **separadamente** en `f16-focal-comparison.json` y `f16-current-comparison.json`; no se eliminan ni se normalizan sus hashes. Se exige el inventario exacto de 69 tablas del diagnóstico congelado `f16-comparison-full-postgres.json`, cuyo hash está anclado. Una tabla adicional, ausente o una diferencia parcial de ese inventario falla.

La aceptación suplementaria exige además que el C16 original, con su SHA-256 inalterado, haya pasado realmente en la misma ejecución: igualdad íntegra de los datos antes/después de rollback y upgrade, y preservación del catálogo previo. El wrapper debe haber terminado con exit 0 y restauración exacta. Sin esa prueba interna, incluso las 69 diferencias conocidas se rechazan. Los hashes entre ejecuciones no permiten reconstruir los datos históricos originales: no se afirma esa reconstrucción ni se acepta de forma general una discrepancia de datos.

## Resultados nuevos

| Control | Resultado | Detalle | Evidencia |
|---|---|---|---|
| Contrapruebas del comparador | PASS | {len(counter['rows'])}/{len(counter['rows'])} respuestas esperadas | counterproofs.json y logs individuales |
| Clasificación/preservación | PASS | {len(classification['rows'])}/{len(classification['rows'])}, incluye F10/F12/H5-008 | classification-counterproofs.json |
| F05 | PASS | 18/18, índice temporal independiente | f05-index-isolated/result.json |
| F07/F08/F09 | PASS | 40/40 transiciones y rechazos esperados | F08-F09-direct.json |
| F01 | PASS | 12/12 contrapruebas | f01-retest/result.json |
{chr(10).join(gate_rows)}

Los FAIL inducidos permanecen como FAIL esperado en sus logs. Los cambios de cuerpo, firma, esquema, propietario, ACL, volatilidad, seguridad, search_path, retorno, argumentos, strict, parallel, leakproof y atributos adicionales se rechazan para cada función. También se rechazan una función ausente/adicional, un objeto previo, un tercer OID y datos fuera de las garantías acreditadas.

F01–F09 se revisan con los controles anteriores, el auditor y la regresión completa; los estados documentales de cierre no se alteran. Los controles previos que no se repiten en esta intervención no se presentan como ejecuciones nuevas. En particular, la batería de contrapruebas del wrapper anterior se referencia con su hash y `newCounterproofExecution: false`; el wrapper no ha cambiado y cada ejecución actual acredita su propia restauración.

## Integridad histórica

| Archivo | Bytes | SHA-256 inalterado |
|---|---:|---|
{chr(10).join(hash_rows)}

Los manifiestos y las guardas permanecen inalterados respecto al preflight; el auditor final valida su cadena. Cada ejecución protegida conserva las salidas generadas en `gates/<ejecución>/preservation/generated/`, restaura todos los artefactos originales y confirma cero cambios históricos inesperados. El cuarto artefacto `h2-011/preservation.log` también está protegido por el wrapper existente.

F16 generado en focal: `{focal['generatedSha256']}`.

F16 generado en regresión completa: `{full['generatedSha256']}`.

## Inventario del correctivo

| Archivo | Bytes | SHA-256 |
|---|---:|---|
{chr(10).join(source_rows)}

El archivo original del runner sigue intacto. Los archivos nuevos son herramientas y evidencia suplementaria local en esta carpeta `.git/f16-corrective/20261013T001249Z/`, sin incorporación a manifiestos históricos ni ampliación del allowlist. `evidence-inventory.json` registra ruta literal, tamaño, tipo, modo y SHA-256 de cada archivo empaquetado. El paquete no queda versionado automáticamente.

## Límites y asuntos pendientes

- `build.log`: **ORIGINAL NO RECUPERADO**, 545 bytes; SHA-256 histórico `063f7ffad5445d9b2a45a17aceb16a01a6dfbbe70032787c0fdd02ea690fd0fa`.
- `health-independent.log`: **ORIGINAL NO RECUPERADO**, 202 bytes; SHA-256 histórico `2794076bee6b763f2a15c62a692735addf3e6b08e4fa296266b92953489f6f30`.
- Se mantiene el registro de pérdida y la excepción documental previa; los hashes de salidas posteriores no sustituyen los originales.
- R67/R030 sigue como anomalía histórica independiente de causa no demostrada. No se le atribuye este correctivo.
- Esta comparación no demuestra igualdad entre todos los datos de bases históricas distintas: conserva las garantías exactas del C16 dentro de cada ejecución y documenta por separado los 69 digests variables.
- Se requiere revisión humana para continuar hacia cierre documental, incorporación de esta evidencia a un candidato publicable, commit final y publicación. F09 permanece OPEN; no se acredita Hosted/Production.

**STOP solicitado tras la revalidación.**
"""
with (out / 'report.md').open('x') as f:
    f.write(text)
print(out / 'report.md')
