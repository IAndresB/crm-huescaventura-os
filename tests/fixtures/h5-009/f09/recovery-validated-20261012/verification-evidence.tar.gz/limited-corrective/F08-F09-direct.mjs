import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdtempSync,mkdirSync,unlinkSync,symlinkSync,chmodSync,rmSync} from 'node:fs';
import {join,dirname} from 'node:path';import {tmpdir} from 'node:os';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
const state=JSON.parse(readFileSync(new URL('./test-state.json',import.meta.url))),root=state.root,out=state.output;
const {assertHistoricalHash,f07Transitions,f09R52Transition}=await import(root+'/tests/support/h5-006-dependency-preservation.ts');
const temp=mkdtempSync(join(tmpdir(),'crm-f09-direct-')),rows=[],digest=b=>createHash('sha256').update(b).digest('hex');
const expectedPath=join(temp,'specs/001-core-crm/expected-TSK-H5-009-010.md'),expected=readFileSync(join(root,'specs/001-core-crm/expected-TSK-H5-009-010.md'));
mkdirSync(dirname(expectedPath),{recursive:true});writeFileSync(expectedPath,expected,{flag:'wx',mode:0o644});symlinkSync(join(root,'.git'),join(temp,'.git'));
const probe=(name,fn,shouldPass)=>{let error=null;try{fn();}catch(e){error=e.message;}const verified=shouldPass?!error:!!error;rows.push({name,expected:shouldPass?'PASS':'FAIL',observed:error?'FAIL':'PASS',verified,error});assert.ok(verified,name);console.log(name+' '+(shouldPass?'PASS':'FAIL expected'));};
try{
 for(const [path,t]of [...Object.entries(f07Transitions),[f09R52Transition.path,{historical:f09R52Transition.historical,current:f09R52Transition.current}]]){
  const original=execFileSync('git',['show','fdbd08bafdc6651d1ad6867242cd71791a25deb6:'+path],{cwd:root}),current=readFileSync(join(root,path)),file=join(temp,path);assert.equal(digest(original),t.historical);assert.equal(digest(current),t.current);mkdirSync(dirname(file),{recursive:true});
  writeFileSync(file,original,{mode:0o644});chmodSync(file,0o644);probe(path+' historical baseline',()=>assertHistoricalHash(path,readFileSync(file),t.historical,temp),true);
  writeFileSync(file,current);probe(path+' corrected authorized context',()=>assertHistoricalHash(path,readFileSync(file),t.historical,temp),true);
  const changed=Buffer.from(current);changed[0]^=1;writeFileSync(file,changed);probe(path+' third version',()=>assertHistoricalHash(path,readFileSync(file),t.historical,temp),false);writeFileSync(file,current);
  probe(path+' wrong historical hash',()=>assertHistoricalHash(path,current,'0'.repeat(64),temp),false);
  unlinkSync(file);probe(path+' deletion',()=>assertHistoricalHash(path,current,t.historical,temp),false);writeFileSync(file,current,{mode:0o644});
  unlinkSync(file);symlinkSync(join(root,path),file);probe(path+' symlink',()=>assertHistoricalHash(path,current,t.historical,temp),false);unlinkSync(file);writeFileSync(file,current,{mode:0o644});
  chmodSync(file,0o600);probe(path+' permissions0600',()=>assertHistoricalHash(path,current,t.historical,temp),false);chmodSync(file,0o644);
  unlinkSync(expectedPath);probe(path+' absent authorized context',()=>assertHistoricalHash(path,current,t.historical,temp),false);writeFileSync(expectedPath,expected,{mode:0o644});
  const corrupted=Buffer.from(expected);corrupted[0]^=1;writeFileSync(expectedPath,corrupted);probe(path+' wrong authorized expected',()=>assertHistoricalHash(path,current,t.historical,temp),false);writeFileSync(expectedPath,expected);
  probe(path+' hash exchanged with unrelated path',()=>assertHistoricalHash('tests/integration/postgres-h3-006-defects.test.ts',current,digest(readFileSync(join(root,'tests/integration/postgres-h3-006-defects.test.ts'))),temp),false);
 }
}finally{writeFileSync(join(out,'F08-F09-direct.json'),JSON.stringify({status:rows.length===40&&rows.every(x=>x.verified)?'PASS':'STOP',baseHead:state.baseHead,auditorSha256:state.auditorSha256,F08Cases:30,F09Cases:10,rows},null,2)+'\n',{flag:'wx',mode:0o644});rmSync(temp,{recursive:true,force:true});}
