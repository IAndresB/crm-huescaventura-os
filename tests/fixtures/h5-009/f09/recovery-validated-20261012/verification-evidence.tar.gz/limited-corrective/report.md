# Correctivo limitado del auditor — STOP tras verificaciones

Base main: 8c1109426a8e85effeda6c2bb59c08ac0693c032. origin/main fdbd08bafdc6651d1ad6867242cd71791a25deb6, divergencia7/0, índice vacío. Auditor probado SHA256 944e02cf5072b6b3cb15623bd871f487160f607617775be0635ffb7dae3a9d34. Fingerprint del checkout completo: c2fe74e6b92fb9110bb71446170401fe51e55b5a321691a1bb75d76bde11d98f. Fingerprint de la copia aislada: a05fa3b85cfc1b95fa2b08dcab4b489870a55a142241f4fea2dfcfffacb298fa. Son fingerprints de contenido/tipos/permisos, no nuevos commits.

## Cambios exactos

Solo cambia scripts/verify-h5-008-evidence.mjs. El diff exclusivo respecto al archivo antes de este turno está en auditor-corrective.diff; el diff respecto a HEAD incluye también correctivos previos.

1. Se carga el inventario original de223 rutas únicamente cuando existe, verificando el hash fijo88eb5525fd94a586ad6aee2b0793be2ac3c9094cf13aba6daeca82c867e4873f, tamaño78537, archivo regular y permisos0644. Cada entrada se comprueba por presencia/tipo/permisos/tamaño/SHA256. Solo los bytes del propio auditor admiten el correctivo humano actual; sus permisos/tipo permanecen comprobados. Los controles históricos y de producto posteriores siguen activos. No se añade supabase/.temp/ al allowlist ni una regla por el nombre cli-latest.
2. La guarda final de R52 reutiliza assertHistoricalHash, después de verificar el registro r52-transition.json existente. Acepta exclusivamente histórico49b382e6781bfed7a8685d74d34ccd5b5b4ca48c95726dcc217e795e6b7ff128 y corregido4719b89eb0d38d951ca9380b79b330fbb758dfc4a6ce794e72a2c66f1e66584e en su contexto H5-009/010 local/aislado.
3. La salida mantiene ambos logs como ORIGINAL NO RECUPERADO, excepción documentalOPEN, F09OPEN y cierre globalNOT VALIDATED. Validar el snapshot de trabajo no acredita el original histórico perdido.

## Contrapruebas y verificaciones

- Clasificación:29 ejecuciones con resultados esperados. Incluyen bytes alterados, ausencia, symlink, permisos0600, inventario alterado, ruta adicional desconocida, R52/registro alterados, manifest/expected alterados, H5-011/012/H6 y Hosted/Production prematuros, y F01/F02/F16 modificados.
- F05:18/18 esperadas, incluido cierre histórico intacto. Aserciones originales conservadas; solo root/output del arnés temporal redirigidos.
- F08:30/30 directas esperadas para las tres transiciones previas.
- F09 R52:10/10 directas esperadas; versión histórica real en baseline, corregida real en contexto autorizado, tercera versión, hash histórico falso, eliminación, symlink, permisos, contexto ausente/alterado e intercambio de ruta. No se ejecutan pruebas PostgreSQL funcionales de R52 en este turno.
- F10/F12 y preservación H5-008:PASS en copia aislada.

La copia aislada contiene el inventario original223 más su archivo de control inmutable. Los14 documentos posteriores se omiten exclusivamente en la preparación de esa fixture para probar las dos ramas corregidas. El checkout real conserva TODOS sus archivos y se audita separadamente. Los contadores PostgreSQL/unit/health que imprime el auditor pertenecen al informe histórico H5-008; no son ejecuciones nuevas.

## Resultado del checkout completo

El auditor real devuelve exit1 en tests/fixtures/h5-009/f09/documentary-exception-20261012T204228Z-e1f88cb4/authorization.json. Ya no rechaza cli-latest. Hay14 documentos posteriores al snapshot original, excluido su control:9 del diagnóstico de recuperación y5 de la excepción documental. Su clasificación/procedencia/tipo/permisos/tamaño/hash están en post-snapshot-routes.json. Son evidencias de tareas humanas anteriores, permanecen intactos y no pertenecen a un manifiesto histórico modificado. No se incorporan automáticamente ni se crea un permiso de directorio.

Las94 rutas suplementarias del inventario previo están dentro de las223 y se validan por snapshot exacto;8 continúan en el allowlist literal anterior. La única ruta adicional reconocida como control es preflight-inventory.json, con hash/tipo/permisos/tamaño fijos. Las rutas nuevas desconocidas siguen rechazadas.

## Preservación y límites

222 de las223 rutas originales conservan exactamente sus bytes; el auditor es el único cambio autorizado. Los tipos y permisos de las223 permanecen iguales. Los15 documentos de recuperación, expected24417/SHA b9f5beaa45c3d4a08f101694115724a6569a43fd590e965f28f9a1ab79c5e639, F01/F02/F16 y los50 manifiestos/snapshots permanecen intactos. Se comprobaron todas las rutas de preflight, sin cambios inesperados.

build.log y health-independent.log:ORIGINAL NO RECUPERADO. Sus hashes históricos siguen063f7ffad5445d9b2a45a17aceb16a01a6dfbbe70032787c0fdd02ea690fd0fa y2794076bee6b763f2a15c62a692735addf3e6b08e4fa296266b92953489f6f30. No se aceptan salidas sobrescritas como originales ni se reconstruyen bytes. Registro de pérdida intacto.

Se conservan los FAIL de preparación del arnés (Python antiguo, symlinknode_modules y permisos0664 de extracción) y sus retests; se corrigió únicamente la preparación de copias desechables. Ninguno procede de cambios de datos/código en el checkout real.

Las evidencias se escriben exclusivamente en este directorio NUEVO de metadatos Git, dentro del proyecto y fuera de las evidencias versionadas. No se cambia .gitignore ni se crea ninguna exclusión. Para futuras incorporaciones versionadas requerirán revisión literal; no se añaden automáticamente al auditor.

F09OPEN, H5-009/010 no cerrados, excepción documentalOPEN, F06–F08 cierre global pendiente. R67/R030 separada y sin causa atribuida. Sin regresión global, commit, push, publicación ni tareas posteriores. STOP para revisión humana del correctivo y de las rutas pendientes.
