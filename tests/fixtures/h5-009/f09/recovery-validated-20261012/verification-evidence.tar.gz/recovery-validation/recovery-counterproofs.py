import pathlib,json,subprocess,hashlib,os,datetime
out=pathlib.Path(__file__).parent;state=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(state['candidateCopy']);prefix='tests/fixtures/h5-009/f09/recovery-validated-20261012/';inv=root/prefix/'supplemental-inventory.json';original=inv.read_bytes();anchor=hashlib.sha256(original).hexdigest();rows=[]
def execute(name,env=None):
 p=subprocess.run(['node','--experimental-strip-types','scripts/verify-h5-008-evidence.mjs'],cwd=root,env=env or {**os.environ,'F09_INVENTORY_SHA256':anchor},capture_output=True,timeout=90)
 for suffix,b in [('stdout',p.stdout),('stderr',p.stderr)]:
  with (out/(name+'.'+suffix+'.log')).open('xb') as f:f.write(b)
 rows.append(dict(name=name,exit=p.returncode,expected=1,verified=p.returncode==1,stdoutSha256=hashlib.sha256(p.stdout).hexdigest(),stderrSha256=hashlib.sha256(p.stderr).hexdigest()));assert p.returncode==1,name;print(name,'FAIL expected',flush=True)
def mutate(name,path,fn,reseal=False):
 f=root/path;b=f.read_bytes();mode=f.stat().st_mode&0o777
 try:
  fn(f,b)
  env={**os.environ,'F09_INVENTORY_SHA256':anchor}
  if reseal:
   v=json.loads(original);x=next(e for e in v['entries'] if e['path']==path);nb=f.read_bytes();x['bytes']=len(nb);x['sha256']=hashlib.sha256(nb).hexdigest();raw=(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode();inv.write_bytes(raw);env['F09_INVENTORY_SHA256']=hashlib.sha256(raw).hexdigest()
  execute(name,env)
 finally:
  if f.is_symlink():f.unlink()
  f.write_bytes(b);f.chmod(mode);inv.write_bytes(original)
try:
 env={**os.environ};env.pop('F09_INVENTORY_SHA256',None);execute('recovery-01-missing-independent-seal',env)
 execute('recovery-02-wrong-seal',{**os.environ,'F09_INVENTORY_SHA256':'0'*64})
 mutate('recovery-03-missing-authorization',prefix+'authorization.json',lambda f,b:f.unlink())
 mutate('recovery-04-denied-authorization-sealed',prefix+'authorization.json',lambda f,b:f.write_bytes(b.replace(b'AUTHORIZED DOCUMENTARY SUBSTITUTION',b'DENIED')),True)
 mutate('recovery-05-original-hash-falsified-sealed',prefix+'substitution.json',lambda f,b:f.write_bytes(b.replace(b'063f7ffa',b'00000000')),True)
 mutate('recovery-06-substitute-absent',prefix+'build.log.gz',lambda f,b:f.unlink())
 mutate('recovery-07-substitute-altered',prefix+'health-independent.log.gz',lambda f,b:f.write_bytes(b+b'x'))
 mutate('recovery-08-substitute-permissions',prefix+'build.log.gz',lambda f,b:f.chmod(0o600))
 def link(f,b):f.unlink();f.symlink_to(pathlib.Path(state['root'])/prefix/'build.log.gz')
 mutate('recovery-09-substitute-symlink',prefix+'build.log.gz',link)
 mutate('recovery-10-false-PASS-sealed',prefix+'executions.json',lambda f,b:f.write_bytes(b.replace(b'"exitCode": 0',b'"exitCode": 1',1)),True)
 mutate('recovery-11-false-original-recovery-sealed',prefix+'substitution.json',lambda f,b:f.write_bytes(b.replace(b'"originalRecoveryClaimed": false',b'"originalRecoveryClaimed": true')),True)
 mutate('recovery-12-candidate-hash-wrong-sealed',prefix+'candidate.json',lambda f,b:f.write_bytes(b.replace(b'"inputSha256": "',b'"inputSha256": "0',1)),True)
 unknown=root/prefix/'unauthorized.txt';unknown.write_text('not authorized\n')
 try:
  v=json.loads(original);v['entries'].append(dict(path=prefix+'unauthorized.txt',type='regular',mode='0644',bytes=15,sha256=hashlib.sha256(unknown.read_bytes()).hexdigest(),provenance='invented',purpose='invented'));raw=json.dumps(v).encode();inv.write_bytes(raw);execute('recovery-13-unknown-path-even-if-resealed',{**os.environ,'F09_INVENTORY_SHA256':hashlib.sha256(raw).hexdigest()})
 finally:unknown.unlink();inv.write_bytes(original)
finally:
 with (out/'recovery-counterproofs.json').open('x') as f:json.dump(dict(status='PASS' if len(rows)==13 and all(x['verified'] for x in rows) else 'STOP',rows=rows),f,indent=2)
