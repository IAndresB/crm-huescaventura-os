import pathlib,json,hashlib,stat
r=pathlib.Path.cwd();out=r/'.git/f09-completion/20261012T213428Z';rel='tests/fixtures/h5-009/f09/recovery-validated-20261012/';old=json.loads((r/'.git/f09-auditor-limited/20261012T205221Z-93895cee/post-snapshot-routes.json').read_bytes());entries=[]
for e in old:
 b=(r/e['path']).read_bytes();s=(r/e['path']).lstat();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'] and stat.S_ISREG(s.st_mode) and s.st_mode&0o777==0o644
 entries.append({**{k:e[k] for k in ['path','type','mode','bytes','sha256']},'provenance':e['provenance'],'purpose':e['classification']})
for n,purpose in [('authorization.json','Human authorization and immutable original references'),('substitution.json','Explicit documentary loss and substitute binding'),('candidate.json','Exact executable inputs and dependency/environment identification'),('build.log.gz','New build raw stream, lossless gzip'),('health-independent.log.gz','New independent health raw stream, lossless gzip'),('executions.json','Actual commands, times, return codes and raw stream hashes')]:
 p=rel+n;b=(r/p).read_bytes();entries.append(dict(path=p,type='regular',mode='0644',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),provenance='Current human-authorized recovery run; prepare-and-run.py retained in verification package',purpose=purpose))
p=r/rel/'supplemental-inventory.json';raw=(json.dumps(dict(scope='H5-009/010 local/isolated',entries=entries),indent=2,ensure_ascii=False)+'\n').encode()
with p.open('xb') as f:f.write(raw)
h=hashlib.sha256(raw).hexdigest();(out/'inventory-anchor.txt').write_text(h+'\n');print(h)
