import pathlib,subprocess,json,os,hashlib,shutil,signal,time
out=pathlib.Path(__file__).parent;state=json.loads((out/'test-state.json').read_bytes());root=pathlib.Path(state['candidateCopy']);script='tests/fixtures/h5-009/f09/run-postgres-preserving-artifacts.mjs';store=root/'tests/fixtures/h5-009/f09/postgres-preservation';art=['tests/fixtures/h2-011/reproducer-F01-corrected.log','tests/fixtures/h2-011/reproducer-F02-corrected.log','tests/fixtures/h2-011/preservation.log','tests/fixtures/h4-012-f16/preservation.json'];orig={p:(root/p).read_bytes() for p in art+['README.md']};rows=[];(out/'wrapper-captures').mkdir()
def execute(name,code,expected=0,preflight=True,restored=True,unexpected=0,terminate=False):
 before=set(store.iterdir());cmd=['node',script,'--','node','-e',code];log=out/('wrapper-'+name+'.log')
 with log.open('xb') as stream:
  p=subprocess.Popen(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
  if terminate:
   deadline=time.monotonic()+30
   while (root/art[0]).read_bytes()==orig[art[0]]:
    assert p.poll() is None and time.monotonic()<deadline,'child did not reach mutation';time.sleep(.05)
   p.send_signal(signal.SIGTERM)
  exit=p.wait(timeout=60)
 dirs=set(store.iterdir())-before;assert len(dirs)==1;d=next(iter(dirs));report=json.loads((d/'status.json').read_bytes());shutil.move(str(d),str(out/'wrapper-captures'/name));valid=exit==expected and report['preflightPassed']==preflight and report['restorationComplete']==restored and len(report['unexpectedTrackedChanges'])==unexpected
 rows.append(dict(name=name,command=cmd,exit=exit,expected=expected,preflight=report['preflightPassed'],restored=report['restorationComplete'],unexpected=len(report['unexpectedTrackedChanges']),pass_=valid));print(name,valid,flush=True);assert valid,report
try:
 execute('preflight','process.exit(0)')
 for name,kind in [('wrong-hash','hash'),('absent','delete'),('symlink','link'),('mode','mode')]:
  p=root/art[0]
  try:
   if kind=='hash':p.write_bytes(orig[art[0]]+b'x')
   elif kind=='delete':p.unlink()
   elif kind=='link':p.unlink();p.symlink_to(pathlib.Path(state['root'])/art[0])
   else:p.chmod(0o600)
   execute(name,'process.exit(0)',1,False)
  finally:
   if p.is_symlink():p.unlink()
   p.write_bytes(orig[art[0]]);p.chmod(0o644)
 for n,p in enumerate(art):execute('modify-'+str(n+1),"require('fs').appendFileSync("+json.dumps(p)+",'generated evidence\\n')")
 execute('child-exit-7',"require('fs').appendFileSync("+json.dumps(art[0])+",'failure evidence\\n');process.exit(7)",7)
 execute('induced-error',"require('fs').appendFileSync("+json.dumps(art[1])+",'error evidence\\n');throw Error('INDUCED_EXECUTION_FAILURE')",1)
 execute('fourth-uninventoried',"require('fs').appendFileSync('README.md','unauthorized\\n')",1,unexpected=1)
 execute('controlled-SIGTERM',"require('fs').appendFileSync("+json.dumps(art[0])+",'interrupted evidence\\n');setInterval(()=>{},1000)",1,terminate=True)
 parent=root/'tests/fixtures/h2-011';mode=parent.stat().st_mode&0o777
 try:
  execute('restore-failure',"const fs=require('fs');fs.appendFileSync("+json.dumps(art[0])+",'unrestorable\\n');fs.chmodSync('tests/fixtures/h2-011',0o555)",1,restored=False)
 finally:parent.chmod(mode);(root/art[0]).write_bytes(orig[art[0]])
 for p,b in orig.items():assert (root/p).read_bytes()==b,p
finally:
 with (out/'wrapper-counterproofs.json').open('x') as f:json.dump(dict(status='PASS' if len(rows)==14 and all(x['pass_'] for x in rows) else 'STOP',rows=rows),f,indent=2)
