import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID as uid} from 'node:crypto';
import {isolatedJointClosures,read,write} from '../support/h5-joint-closure-isolated.ts';
import {bookingFixture} from '../support/h2-booking-fixtures.ts';
import {closureCommands} from '../support/h5-closure-fixtures.ts';
import type {JointClosureCommand} from '../../src/domain/closure-assessment.ts';
let h:Awaited<ReturnType<typeof isolatedJointClosures>>;
before(async()=>{h=await isolatedJointClosures('h5015',59525);});after(async()=>{await h?.close();});
test('H5-015 J01 no implicit closure and pending dimensions reject',async()=>{
 const f=await bookingFixture(h);await h.booking.apply(await h.auth(),write,f.q);
 const c=await closureCommands(h,f.q.bookingId),v=await c.view();assert.equal(v.jointClosure.current,false);
 const q:Omit<JointClosureCommand,'evidenceId'>={action:'close',bookingId:f.q.bookingId,operationId:uid(),expectedRevision:v.revision,expectedMaterial:v.material,expectedJointRevision:0,sourceRef:'SYNTHETIC close',reason:'SYNTHETIC explicit review',at:new Date().toISOString()};
 const hash=(await h.observer`select crm_private.booking_preparation_hash(${JSON.stringify(Object.fromEntries(Object.entries(q).filter(([k])=>k!=='operationId')))}::text::jsonb) h`)[0]!.h;
 const e=h.req('evidence',{claim:'closure:'+hash,coverage:f.q.bookingId,certainty:'reviewed',source_kind:'manual'},f.q.bookingId,'other');await h.evidence.apply(await h.auth(),write,{...e,occurredAt:q.at,coverage:f.q.bookingId});
 await assert.rejects(h.closures.close(await h.auth(),write,{...q,evidenceId:e.targetId}),/DIMENSION_PENDING/);
 assert.equal((await c.view()).jointClosure.history.length,0);
});

import {jointFixture,jointCommands,conclusions} from '../support/h5-joint-closure-fixtures.ts';
import {incidentFixture} from '../support/h4-incident-fixtures.ts';
test('H5-015 J01/J06 explicit closure, canonical projection, replay and duplicate rejection',async()=>{
 const f=await jointFixture(h),j=f.j,v=await j.c.view();assert.equal(v.jointClosure.current,false);
 const q=await j.command(),r=await j.run(q);assert.equal(r.result.status,'Cerrada / Histórico');assert.equal(r.result.actorId,h.actorId);
 assert.equal((await j.run(q)).replayed,true);await assert.rejects(j.run(await j.attest({...q,reason:'different'})),/REPLAY_CONFLICT/);
 await assert.rejects(j.run(await j.command()),/ALREADY_CLOSED/);assert.equal((await j.c.view()).jointClosure.history.length,1);
 const canonical=await h.booking.read(await h.auth(),read,f.bookingId) as {closureAssessments:{jointClosure:{current:boolean}}};assert.equal(canonical.closureAssessments.jointClosure.current,true);
});
for(const omit of ['commercial','operational','economic'] as const)test('H5-015 J01 pending '+omit+' blocks independently',async()=>{
 const f=await jointFixture(h,(['commercial','operational','economic'] as const).filter(d=>d!==omit));
 await assert.rejects(f.j.run(await f.j.command()),/DIMENSION_PENDING/);assert.equal((await f.j.c.view()).jointClosure.revision,0);
});
test('H5-015 J04/J05 close, economic incident, founded reopen, correction, reevaluation and new close',async()=>{
 const f=await jointFixture(h),j=f.j;await j.run(await j.command());const history=(await j.c.view()).jointClosure.history;
 const incident=await incidentFixture(h,undefined,{bookingId:f.bookingId,serviceId:f.b.detail.services[0]!.id});
 await h.incidents.apply(await h.auth(),write,await incident.command('detect',{...incident.data,severity:'Importante',impact:{...incident.impact,effect:'economic-review'}}));
 let v=await j.c.view();assert.equal(v.jointClosure.current,false);assert.equal(v.assessments.economic!.currentStatus,'Pendiente');assert.equal(v.assessments.commercial!.currentStatus,'Resuelto');assert.equal(v.assessments.operational!.currentStatus,'Resuelto');assert.equal(v.invalidations.length,1);
 await j.c.run(await j.c.command('economic',{}, {action:'reopen',serviceApplicability:await j.flags()}));
 await assert.rejects(j.c.run(await j.c.command('economic',{}, {action:'reopen',serviceApplicability:await j.flags()})),/NOT_RESOLVED/);
 await h.incidents.apply(await h.auth(),write,await incident.resolve());await h.incidents.apply(await h.auth(),write,await incident.close());
 await j.c.run(await j.c.command('economic',{...conclusions.economic,'economic-incidents':'not_applicable'},{action:'evaluate',serviceApplicability:await j.flags()}));
 assert.equal((await j.c.view()).jointClosure.current,false);await j.run(await j.command());v=await j.c.view();assert.equal(v.jointClosure.current,true);assert.equal(v.jointClosure.revision,2);assert.deepEqual(v.jointClosure.history.slice(0,1),history);
});
test('H5-015 J05 unfounded explicit reopen is rejected',async()=>{
 const f=await jointFixture(h);await assert.rejects(f.j.c.run(await f.j.c.command('commercial',{}, {action:'reopen'})),/REOPEN_UNFOUNDED/);assert.equal((await f.j.c.view()).revision,6);
});
test('H5-015 J02 global critical guard persists invalidation even outside dimension materiality filter',async()=>{
 const f=await jointFixture(h),j=f.j;await j.run(await j.command());
 const incident=await incidentFixture(h,undefined,{bookingId:f.bookingId,serviceId:f.b.detail.services[0]!.id});
 await h.incidents.apply(await h.auth(),write,await incident.command('detect',{...incident.data,impact:{...incident.impact,material:false,effect:'complete-close'}}));
 const v=await j.c.view();assert.equal(v.jointClosure.current,false);assert.equal(v.assessments.operational!.currentStatus,'Pendiente');
});
