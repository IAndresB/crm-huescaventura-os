import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
import {isolatedJointClosures} from '../support/h5-joint-closure-isolated.ts';
import {jointFixture} from '../support/h5-joint-closure-fixtures.ts';
test('H5-016 F01 original candidate accepts full close with JSON null and empty terms',async()=>{
 const h=await isolatedJointClosures('h5016original',59565,true);
 try{await h.migration.unsafe(gunzipSync(await readFile('tests/fixtures/h5-016/F01-original-migration63.sql.gz')).toString());
  const accepted=[];for(const damaged of [null,{}]){const f=await jointFixture(h,[]);await h.admin.unsafe(`update crm_private.b04_bookings set terms='${JSON.stringify(damaged)}'::jsonb where booking_id=$1`,[f.bookingId]);for(const d of ['commercial','operational','economic']as const)await f.j.resolve(d);await f.j.run(await f.j.command());const v=await f.j.c.view();accepted.push({damaged,current:v.jointClosure.current,status:v.jointClosure.latestClose!.status});}console.log('H5016 original end-to-end evidence',JSON.stringify(accepted));assert.ok(accepted.every(x=>!x.current),'Incomplete terms must not authorize joint closure');
 }finally{await h.close();}
});
