-- H5-018-3-F01/F02. Forward67: canonical execution ownership and typed parent history.
-- Only two existing function bodies change. No row rewrite, object or privilege added.
begin;
do $$begin if current_user<>'crm_h0_migration'then raise exception 'DIAGNOSTIC_MIGRATION_AUTHORITY_REQUIRED';end if;end$$;
create or replace function crm_private.diagnostic_nodes(s text,k text,root uuid)returns jsonb
language plpgsql stable set search_path=pg_catalog,pg_temp as $$
declare canonical jsonb;historical jsonb;authorized jsonb;observations jsonb;nodes jsonb;
begin
 canonical:=crm_private.diagnostic_canonical_nodes(s,k,root);
 -- Work owns immutable versioned context and command history. Its operation's
 -- original context is not replaced by the execution's current definition.
 -- Verify that original version AND its evidence link still authorize this
 -- typed root. An observation itself never establishes historical ownership.
 with work_history as(
  select h.history_id,h.operation_id,h.subject_id,h.actor_id,h.recorded_at,
   o.actor_id operation_actor,o.recorded_at operation_time,d.version
  from crm_private.b07_history h
  join crm_private.b07_operations o on o.operation_id=h.operation_id and o.result_ref=h.subject_id
  join crm_private.b08_command_results r on r.operation_id=o.operation_id
  join crm_private.b08_executions e on e.execution_id=h.subject_id
  join crm_private.b08_definitions d on d.definition_id=e.definition_id
   and d.definition_id::text=h.after_state#>>'{definition,definition_id}'
   and d.version::text=h.after_state#>>'{definition,version}'
   and d.context=h.after_state#>'{definition,context}'
  where h.admin_scope=s and o.admin_scope=s and r.admin_scope=s and e.admin_scope=s and d.admin_scope=s
   and left(h.action_kind,5)='work_' and h.subject_id::text=h.after_state#>>'{execution,execution_id}'
   and exists(select 1 from crm_private.diagnostic_contexts(s,k,root)c
    where c.context_kind=d.context->>'contextKind' and c.context_id::text=d.context->>'contextId')
   and crm_private.b08_context(d,s)
 ), projected as(
  select jsonb_build_object('key','b07_operations/'||operation_id,'source','b07_operations','id',operation_id,
   'references',jsonb_build_array(operation_id,subject_id,operation_id,null),
   'actorId',operation_actor,'recordedAt',operation_time,'historical',true,'definitionVersion',version)node from work_history
  union all
  select jsonb_build_object('key','b07_history/'||history_id,'source','b07_history','id',history_id,
   'references',jsonb_build_array(history_id,subject_id,operation_id,null),
   'actorId',actor_id,'recordedAt',recorded_at,'historical',true,'definitionVersion',version)node from work_history
 )select coalesce(jsonb_agg(distinct node),'[]')into historical from projected;
 -- Keep existing node identity and projection when it is currently authorized.
 select canonical||coalesce(jsonb_agg(n),'[]')into authorized from jsonb_array_elements(historical)n
 where not exists(select 1 from jsonb_array_elements(canonical)c where c->>'key'=n->>'key');
 select coalesce(jsonb_agg(jsonb_build_object('key','observation/'||o.observation_id,'source','b10_diagnostic_observations','id',o.observation_id,
  'references',jsonb_build_array(o.observation_id,o.request_ref,o.operation_id,o.execution_id,o.event_id),
  'actorId',o.actor_id,'recordedAt',o.recorded_at,'outcome',o.outcome,'issues',o.issues,
  'operationReferenceState',crm_private.diagnostic_operation_reference(o.operation_id,authorized))
  ||case when crm_private.diagnostic_operation_reference(o.operation_id,canonical)='incompatible'
    then jsonb_build_object('historicalOperationReference',true)else '{}'::jsonb end),'[]')into observations
 from crm_private.b10_diagnostic_observations o
 where o.admin_scope=s and o.context_kind=k and o.context_id=root
 -- A visible operation and a visible execution are not necessarily related.
 -- Revalidate legacy observations and late confirmations against the B08 owner;
 -- an unknown operation remains only an unverified attempt.
 and(o.execution_id is null or o.operation_id is null
  or crm_private.diagnostic_operation_reference(o.operation_id,authorized)='unverified_attempt'
  or exists(select 1 from crm_private.b07_operations op
   join crm_private.b08_command_results result using(operation_id)
   where op.operation_id=o.operation_id and op.result_ref=o.execution_id
    and op.admin_scope=s and result.admin_scope=s))
 and(
  crm_private.diagnostic_operation_reference(o.operation_id,canonical)<>'incompatible'
  or(
   crm_private.diagnostic_operation_reference(o.operation_id,authorized)<>'incompatible'
   and exists(select 1 from jsonb_array_elements(historical)n where n->>'source'='b07_operations'and n->>'id'=o.operation_id::text
    and(o.execution_id is null or (n->'references'->>1)=o.execution_id::text))
   and(o.event_id is null or exists(select 1 from crm_private.b07_records e join crm_private.b07_links l using(record_id)
    where e.record_id=o.event_id and e.record_kind='external_event'and e.admin_scope=s and l.admin_scope=s and l.context_kind=k and l.context_id=root))
  )
 );
 -- No current execution/definition/approval of another context is projected.
 -- C01's existing final F1/F2 checks still run after materializing this result.
 nodes:=authorized||observations;return nodes;
end$$;

create or replace function crm_api.h5_diagnostic_record(f2p bytea,f2s bytea,f1p bytea,f1s bytea,q bytea)returns jsonb
language plpgsql volatile security definer set search_path=pg_catalog,pg_temp as $$
declare h text[];t text[];f text[];a jsonb;i jsonb;s text;k text;root uuid;old crm_private.b10_diagnostic_observations%rowtype;r jsonb;opstate text;
begin
 h:=crm_f2.admit(f2p,f2s,q,'C03','write_evidence');t:=crm_f1.verify_envelope(f1p,f1s,q,'C03','evidence','write_evidence');f:=crm_f1.fields(q);
 if h[17]<>t[14] or cardinality(f)<>2 or f[1]<>'CRM-H5-DIAGNOSTIC1' then raise exception 'DIAGNOSTIC_DENIED';end if;
 a:=f[2]::jsonb;s:=h[17];k:=a->>'contextKind';root:=(a->>'contextId')::uuid;
 if a-array['contextKind','contextId','observationId','requestRef','operationId','executionId','eventId','outcome','issues']<>'{}'
 or not(a?&array['contextKind','contextId','observationId','requestRef','outcome','issues'])
 or not crm_private.diagnostic_root(s,k,root) or coalesce(a->>'requestRef','')!~'^ref-[a-f0-9]{16}$'
 or coalesce(a->>'outcome','')not in('accepted','previous','pending','rejected')
 or jsonb_typeof(a->'issues')is distinct from 'array' then raise exception 'DIAGNOSTIC_DENIED';end if;
 if jsonb_array_length(a->'issues')>8 or (a->>'outcome' in('accepted','previous'))<>(jsonb_array_length(a->'issues')=0) then raise exception 'DIAGNOSTIC_DENIED';end if;
 for i in select value from jsonb_array_elements(a->'issues')loop
  if jsonb_typeof(i)<>'object' or i-array['code','affectedScope']<>'{}' or not(i?&array['code','affectedScope'])
   or coalesce(i->>'code','')not in('E1','E2','E3','E4','E5','E6','E7','E8')
   or coalesce(i->>'affectedScope','')not in('request','access','operation','execution','event','evidence','dependency','identity','document','work')
   or (i->>'code'='E4' and a->>'outcome'='rejected')then raise exception 'DIAGNOSTIC_DENIED';end if;
 end loop;
 if a?'executionId' and not exists(select 1 from crm_private.b08_executions e join crm_private.b08_definitions d using(definition_id,version)
 where e.execution_id=(a->>'executionId')::uuid and e.admin_scope=s and d.admin_scope=s and crm_private.b08_context(d,s) and exists(select 1 from crm_private.diagnostic_contexts(s,k,root)c
  where c.context_kind=d.context->>'contextKind' and c.context_id::text=d.context->>'contextId'))then raise exception 'DIAGNOSTIC_DENIED';end if;
 if a?'eventId' and not exists(select 1 from crm_private.b07_records e join crm_private.b07_links l using(record_id)
 where e.record_id=(a->>'eventId')::uuid and e.record_kind='external_event' and e.admin_scope=s and l.admin_scope=s and l.context_kind=k and l.context_id=root)then raise exception 'DIAGNOSTIC_DENIED';end if;
 if a?'operationId' then
  opstate:=crm_private.diagnostic_operation_reference((a->>'operationId')::uuid,crm_private.diagnostic_canonical_nodes(s,k,root));
  if opstate='incompatible' or(opstate='canonical' and a?'executionId' and not exists(
   select 1 from crm_private.b07_operations op join crm_private.b08_command_results result using(operation_id)
   where op.operation_id=(a->>'operationId')::uuid and op.result_ref=(a->>'executionId')::uuid
    and op.admin_scope=s and result.admin_scope=s))then raise exception 'DIAGNOSTIC_DENIED';end if;
 end if;
 -- Serialize only technical observation identity; conflicting content is not a replay.
 perform pg_advisory_xact_lock(hashtextextended(a->>'observationId',17017));
 select * into old from crm_private.b10_diagnostic_observations where observation_id=(a->>'observationId')::uuid;
 if found then
  if old.admin_scope<>s or old.actor_id<>h[12]::uuid or old.context_kind<>k or old.context_id<>root or old.request_ref<>a->>'requestRef'
   or old.operation_id is distinct from (a->>'operationId')::uuid or old.execution_id is distinct from (a->>'executionId')::uuid
   or old.event_id is distinct from(a->>'eventId')::uuid or old.outcome<>a->>'outcome' or old.issues<>a->'issues'then raise exception 'DIAGNOSTIC_DENIED';end if;
  r:=jsonb_build_object('id',old.observation_id,'replayed',true);
 else
  insert into crm_private.b10_diagnostic_observations(observation_id,admin_scope,actor_id,context_kind,context_id,request_ref,operation_id,execution_id,event_id,outcome,issues)
   values((a->>'observationId')::uuid,s,h[12]::uuid,k,root,a->>'requestRef',(a->>'operationId')::uuid,(a->>'executionId')::uuid,(a->>'eventId')::uuid,a->>'outcome',a->'issues');
  r:=jsonb_build_object('id',a->>'observationId','replayed',false);
 end if;
 perform crm_f2.verify(f2p,f2s,q,'C03','human_evidence','write_evidence');perform crm_f1.verify_envelope(f1p,f1s,q,'C03','evidence','write_evidence');return r;
end$$;
commit;
