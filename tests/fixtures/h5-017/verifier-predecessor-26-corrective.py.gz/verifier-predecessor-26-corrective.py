#!/usr/bin/env python3
"""Read-only verification of H5-017 receipts, inputs and historical integrity.
No staging, commit, publication or independent H5-018 audit.
"""
import gzip,hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'tests/fixtures/h5-017'
def read(path):
 p=ROOT/path
 return gzip.decompress(p.read_bytes())if p.suffix=='.gz'else p.read_bytes()
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def require(value,message):
 if not value:raise RuntimeError(message)
def verify():
 pre=json.loads(read('tests/fixtures/h5-017/preflight.json.gz'))
 require(git('rev-parse','HEAD').decode().strip()==pre['base'],'BASE_CHANGED')
 require(git('diff','--cached','--name-only')==b'','REAL_INDEX_NOT_EMPTY')
 mutable={'docs/PROJECT-STATUS.md','docs/NEXT-STEPS.md','specs/001-core-crm/tasks.md'}
 checked=0
 for path,item in pre['files'].items():
  if path in mutable:continue
  p=ROOT/path
  require(p.is_file()and not p.is_symlink(),path+': missing or changed type')
  require(sha(p.read_bytes())==item['sha256'],path+': historical bytes changed')
  require(oct(p.stat().st_mode&0o777)==item['mode'],path+': mode changed');checked+=1
 prior=json.loads(read('tests/fixtures/h5-016/final-inputs.json'))['inputs']
 for path,h in prior.items():require(sha((ROOT/path).read_bytes())==h,path+': H5-016 input changed')
 counts={'11-focal-expanded':31,'13-unit':201,'15-regression-on64':104,'16-postgres-complete':2787,'17-health':1}
 gates=[*counts,'18-frozen-install','19-audit','20-typecheck','21-lint','22-build','23-versions']
 summaries={}
 for name in gates:
  receipt=json.loads(read('tests/fixtures/h5-017/'+name+'.status.json'))
  require(receipt['exit']==0 and receipt['changedDuringRun']==[],name+': failed/changed during run')
  require(receipt['base']==pre['base'],name+': wrong base')
  inputs=json.loads(read('tests/fixtures/h5-017/'+name+'.inputs.json'))
  for path,h in inputs.items():require((ROOT/path).is_file()and sha((ROOT/path).read_bytes())==h,name+': input changed '+path)
  if name in counts:
   stream=read('tests/fixtures/h5-017/'+name+'.stdout.log.gz').decode()
   summary={k:int(v)for k,v in re.findall(r'(?:ℹ |# )(tests|pass|fail|cancelled|skipped) (\d+)',stream)}
   require(summary=={'tests':counts[name],'pass':counts[name],'fail':0,'cancelled':0,'skipped':0},name+': exact counts differ');summaries[name]=summary
 require(len(list((ROOT/'supabase/migrations').glob('*.sql')))==64,'MIGRATION_CHAIN_CHANGED')
 require('NOT STARTED' in (ROOT/'specs/001-core-crm/tasks.md').read_text().split('#### TSK-H5-018',1)[1].split('#### ',1)[0],'H5-018_STARTED')
 result={'base':pre['base'],'historicalFilesUnchanged':checked,'statusDocumentsAllowed':sorted(mutable),'priorH5016InputsUnchanged':len(prior),'migrationChain':64,'newPostgres':31,'priorPostgres':2756,'newUnit':4,'counts':summaries,'gates':gates,'scope':'H5-017 implementation only, local/isolated','independentH5018Executed':False,'realIndexEmpty':True}
 print(json.dumps(result,indent=2));return result
if __name__=='__main__':verify()
