import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash,randomUUID as id} from 'node:crypto';
import {thirdDatabase,migration66,read,write} from '../support/h5-018-third-isolated.ts';
import {workFixture} from '../support/h5-work-isolated.ts';
import {communicationFixture} from '../support/h5-communication-isolated.ts';
import {diagnosticReference} from '../../src/server/diagnostics.ts';
import {semanticIssue} from '../../src/domain/semantic-error.ts';
test('M01 independent catalog, populated upgrade, aborted DDL, function recovery and exact effective privileges',async()=>{
 const h=await thirdDatabase('h5018thirdmig',59952,true);
 try{
  const f=await workFixture(h);await f.run(f.definition);
  const o={contextKind:'booking' as const,contextId:f.context.contextId,operationId:f.definition.operationId,executionId:f.executionId,observationId:id(),requestRef:diagnosticReference(id()),outcome:'pending' as const,issues:[semanticIssue('E4','execution')]};await h.diagnostic.record(await h.auth(),write,o);
  const dest=await communicationFixture(h),material={...f.material,content:'Migración independiente sintética'},approval=await f.approve(material);await f.run({...f.definition,...f.base(),action:'revise',version:2,material,...approval,context:{recordId:dest.recordId,...dest.context},affectedRefs:[dest.recordId]});
  const q={contextKind:'booking' as const,contextId:o.contextId,reference:o.requestRef,pageSize:100};assert.deepEqual((await h.diagnostic.read(await h.auth(),read,q)).nodes,[]);
  const classes=()=>h.admin`select c.oid::int oid,n.nspname,c.relname,c.relkind,c.relowner::int owner,c.relacl::text acl,c.relrowsecurity,c.relforcerowsecurity,c.reloptions from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname like 'crm%' order by c.oid`;
  const functions=()=>h.admin`select p.oid::int oid,p.oid::regprocedure::text name,to_jsonb(p) attributes from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname like 'crm%' order by p.oid`;
  const policies=()=>h.admin`select to_jsonb(p) row from pg_policy p order by oid`;
  const constraints=()=>h.admin`select to_jsonb(c) row from pg_constraint c where connamespace in(select oid from pg_namespace where nspname like 'crm%') order by oid`;
  const rights=async()=>{
   const rows=[];for(const role of ['crm_h0_runtime','crm_h0_ha_tx','crm_h0_f2_executor','anon','authenticated']){
    rows.push(await h.admin`select ${role} role_name,has_table_privilege(${role},'crm_private.b10_diagnostic_observations','SELECT') r,has_table_privilege(${role},'crm_private.b10_diagnostic_observations','INSERT') w,has_function_privilege(${role},'crm_private.diagnostic_nodes(text,text,uuid)','EXECUTE') helper,has_schema_privilege(${role},'crm_private','CREATE') ddl`);
   }return rows;
  };
  const tables=(await classes()).filter(x=>x.relkind==='r');
  const rowsHash=async()=>{
   const hash=createHash('sha256');for(const t of tables){hash.update(t.nspname+'.'+t.relname);hash.update(JSON.stringify(await h.admin.unsafe(`select to_jsonb(x) row from ${t.nspname}.${t.relname} x order by to_jsonb(x)::text`)));}return hash.digest('hex');
  };
  const before={classes:await classes(),functions:await functions(),policies:await policies(),constraints:await constraints(),rights:await rights(),data:await rowsHash()};
  const oldDefinition=(await h.admin`select pg_get_functiondef('crm_private.diagnostic_nodes(text,text,uuid)'::regprocedure) body`)[0]!.body,sql=await readFile(migration66,'utf8');
  const ordinary=await h.runtime.reserve();try{await assert.rejects(ordinary.unsafe(sql),/DIAGNOSTIC_MIGRATION_AUTHORITY_REQUIRED/);await ordinary.unsafe('rollback');}finally{ordinary.release();}
  await assert.rejects(h.migration.unsafe(sql.replace(/commit;\s*$/,'select 1/0;commit;')),/division by zero/);await h.migration.unsafe('rollback');
  assert.deepEqual(await functions(),before.functions);assert.deepEqual(await classes(),before.classes);assert.deepEqual(await policies(),before.policies);assert.deepEqual(await constraints(),before.constraints);assert.deepEqual(await rights(),before.rights);assert.equal(await rowsHash(),before.data);
  await h.migration.unsafe(sql);const after=await functions();assert.equal(after.length,before.functions.length);const changed=[];
  for(const old of before.functions){const now=after.find(x=>x.oid===old.oid)!;assert.ok(now);if(now.attributes.prosrc!==old.attributes.prosrc)changed.push(old.name);assert.deepEqual({...now.attributes,prosrc:old.attributes.prosrc},old.attributes);}
  assert.deepEqual(changed,['crm_private.diagnostic_nodes(text,text,uuid)']);assert.deepEqual(await classes(),before.classes);assert.deepEqual(await policies(),before.policies);assert.deepEqual(await constraints(),before.constraints);assert.deepEqual(await rights(),before.rights);assert.equal(await rowsHash(),before.data);
  assert.ok((await h.diagnostic.read(await h.auth(),read,q)).nodes.some(n=>n.id===o.observationId));
  // Recovery experiment only in this disposable database: install the prior body,
  // observe its old limitation, then reapply the byte-identical candidate66.
  await h.migration.unsafe(oldDefinition);assert.deepEqual(await functions(),before.functions);assert.deepEqual((await h.diagnostic.read(await h.auth(),read,q)).nodes,[]);await h.migration.unsafe(sql);assert.ok((await h.diagnostic.read(await h.auth(),read,q)).nodes.some(n=>n.id===o.observationId));assert.equal(await rowsHash(),before.data);
  console.log('M01 independent66',JSON.stringify({tables:tables.length,classes:before.classes.length,functions:after.length,policies:before.policies.length,constraints:before.constraints.length,changed,newObjects:0,rowsHash:before.data,aclRlsUnchanged:true,ordinaryDDLRejected:true,abortedMigration:true,priorFunctionRecoveryAndForwardRetry:true}));
 }finally{await h.close();}
});
test('M02 new empty cluster installs through66 with API roles introduced afterwards, direct access and bypass denied',async()=>{
 const h=await thirdDatabase('h5018thirdclean',59953,true);
 try{
  await h.admin.unsafe('drop role anon;drop role authenticated');await h.migration.unsafe(await readFile(migration66,'utf8'));await h.admin.unsafe('create role anon login;create role authenticated login');
  const f=await workFixture(h);await f.run(f.definition);assert.ok((await h.diagnostic.read(await h.auth(),read,{contextKind:'booking',contextId:f.context.contextId,pageSize:100})).nodes.some(n=>n.id===f.executionId));
  const rls=(await h.admin`select relrowsecurity,relforcerowsecurity from pg_class where oid='crm_private.b10_diagnostic_observations'::regclass`)[0]!;assert.equal(rls.relrowsecurity,true);assert.equal(rls.relforcerowsecurity,true);
  for(const role of ['anon','authenticated','crm_h0_runtime','crm_h0_ha_tx']){
   const db=h.connect(role);try{await assert.rejects(db.unsafe('select * from crm_private.b10_diagnostic_observations'));await assert.rejects(db.unsafe("select crm_private.diagnostic_nodes('synthetic','booking',null)"));}finally{await db.end({timeout:1});}
  }
  const owner=(await h.admin`select p.prosecdef,p.proconfig,r.rolsuper,r.rolbypassrls,r.rolcanlogin from pg_proc p join pg_roles r on r.oid=p.proowner where p.oid='crm_private.diagnostic_nodes(text,text,uuid)'::regprocedure`)[0]!;
  assert.equal(owner.prosecdef,false);for(const key of ['rolsuper','rolbypassrls','rolcanlogin'])assert.equal(owner[key],false);assert.deepEqual(owner.proconfig,['search_path=pg_catalog, pg_temp']);
  console.log('M02 clean66',JSON.stringify({newEmptyCluster:true,rolesAfterMigration:true,ordinaryDirectAttempts:8,denied:8,rls,owner}));
 }finally{await h.close();}
});
