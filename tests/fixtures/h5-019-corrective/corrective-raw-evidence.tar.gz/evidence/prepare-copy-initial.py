from pathlib import Path
import tarfile,subprocess
W=Path(__file__).parent;P=W/'work'/'replay';assert not P.exists();P.mkdir()
with tarfile.open(W/'original-candidate.tar.gz') as t:t.extractall(P,filter='data')
subprocess.run(['git','init','-q','-b','main'],cwd=P,check=True)
(P/'.git/objects/info/alternates').write_text('/Users/andres/Developer/crm-huescaventura-os/.git/objects\n')
for n in ['refs/heads/main','refs/remotes/origin/main']:
 p=P/'.git'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('1e7822c11be817e4f2d4791338284aa825ad1a24\n')
subprocess.run(['git','read-tree','HEAD'],cwd=P,check=True)
print(P,flush=True)
