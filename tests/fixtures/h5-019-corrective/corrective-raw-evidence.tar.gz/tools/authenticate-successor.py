"""External bootstrap: authenticate candidate bytes BEFORE executing its code.
Trust comes from the operator-supplied handoff SHA, never a value learned from
candidate code. This external tool does not import the candidate's instruments.
"""
from pathlib import Path,PurePosixPath
import sys,json,hashlib,gzip,stat,subprocess
root=Path(sys.argv[1]).resolve();pin=sys.argv[2]
S='tests/fixtures/h5-019-corrective/candidate-seal.json';I='tests/fixtures/h5-019-corrective/candidate-inventory.json.gz'
def fail(s):raise ValueError(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def pairs(rows):
 d={}
 for k,v in rows:
  if k in d:fail('DUPLICATE_KEY')
  d[k]=v
 return d
def path(n):
 p=PurePosixPath(n)
 if str(p)!=n or p.is_absolute()or'..'in p.parts or'\\'in n:fail('UNSAFE_PATH')
 q=root/n
 for s in [q,*q.parents]:
  if s.is_symlink():fail('SYMLINK')
  if s==root:break
 if not stat.S_ISREG(q.lstat().st_mode):fail('NOT_REGULAR')
 return q
def meta(n):
 q=path(n);b=q.read_bytes();return {'bytes':len(b),'mode':stat.S_IMODE(q.stat().st_mode),'type':'regular','sha256':sha(b)}
try:
 if sha(path(S).read_bytes())!=pin:fail('EXTERNAL_SEAL_MISMATCH')
 seal=json.loads(path(S).read_bytes(),object_pairs_hook=pairs)
 if sha(path(I).read_bytes())!=seal['inventorySha256']or meta(I)!=seal['inventoryMetadata']:fail('INVENTORY_CHANGED')
 inv=json.loads(gzip.decompress(path(I).read_bytes()),object_pairs_hook=pairs)
 if inv['selfMetadataExcluded']!=[I,S]:fail('BAD_EXCLUSIONS')
 current=set(filter(None,subprocess.check_output(['git','ls-files','-c','-o','--exclude-standard','-z'],cwd=root).decode().split('\0')))
 if current!=set(inv['files'])|{I,S}:fail('BAD_UNIVERSE')
 for folder in ['tests/fixtures/h5-019/', 'tests/fixtures/h5-019-corrective/']:
  for q in (root/folder).rglob('*'):
   if (q.is_file()or q.is_symlink())and str(q.relative_to(root))not in current:fail('UNDECLARED_SCOPED_FILE')
 for n,m in inv['files'].items():
  if meta(n)!=m:fail('CHANGED: '+n)
 if meta(S)['mode']!=0o644:fail('SEAL_MODE')
 print(json.dumps({'authenticatedBeforeCandidateCode':True,'sealSha256':pin,'files':len(current),'authority':'external identity only; no acceptance'}))
except (ValueError,OSError,KeyError,TypeError)as e:
 print('BOOTSTRAP_REJECTED: '+str(e),file=sys.stderr);sys.exit(1)
