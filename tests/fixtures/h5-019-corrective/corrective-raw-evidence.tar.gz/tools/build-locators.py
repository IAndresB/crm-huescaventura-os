from pathlib import Path
import json,hashlib,re
R=Path('/Users/andres/Developer/crm-huescaventura-os');A=Path('/Users/andres/Developer/crm-h5-019-independent-audit-20261018T035950Z');O=R/'tests/fixtures/h5-019-corrective'
review=json.loads((A/'evidence/independent-normative-matrix.json').read_text());runs=json.loads((A/'evidence/independent-full.json').read_text())
rows=[]
for row in review['rows']:
 anchors=[]
 sources=row['assertionSourcesReviewed']
 if row['id']=='AC-071':sources=[{'path':'tests/integration/postgres-h5-012-candidate61.test.ts','phase':'independent-full-15'}]
 for source in sources:
  path=R/source['path'];s=path.read_text();lines=s.splitlines()
  options=[c for c in row['actualCaseLocators']if c['phase']==source['phase']and c['name']in s]
  if row['id']=='AC-051':options=[c for c in options if c['name']in ['R07','R09','R12','R20']]
  if row['id']=='AC-067':
   options=[c for c in row['actualCaseLocators']if c['name']=='H5-014 C03 invoice writer first; real root wait and stale check']
  for c in options[:3]:
   if row['id']=='AC-067':start=next(i for i,l in enumerate(lines)if 'for(const kind of'in l);end=next(i for i in range(start+1,len(lines))if lines[i].startswith("test("))
   elif row['id']=='AC-051':start=next(i for i,l in enumerate(lines)if l.startswith(' '+c['name']+':'));end=next((i for i in range(start+1,len(lines))if re.match(r' R\d+:',lines[i])),len(lines))
   else:
    start=next(i for i,l in enumerate(lines)if c['name']in l);end=next((i for i in range(start+1,len(lines))if re.match(r'(?:for.*)?test\(',lines[i])or lines[i].startswith('test(')),min(start+30,len(lines)))
   assertions=[{'line':i+1,'text':lines[i]}for i in range(start,end)if re.search(r'assert\.(equal|deepEqual|rejects|ok|match|throws)',lines[i])]
   if not assertions:continue
   phase=next(p for p in runs['phases']if p['tag']==c['phase']);assert path.name in phase['files']and phase['exit']==0
   if row['id']=='AC-051':case={'name':c['name'],'phase':c['phase'],'file':source['path'],'ordinal':'No se asigna ordinal único: el reporter repite Rxx; archivo seleccionado, registro y fase sin fallos acreditan su ejecución.'}
   else:case=c
   anchors.append({'file':source['path'],'fileSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'registrationLine':start+1,'case':case,'assertions':assertions,'rawExecution':phase['stdout'],'rawExecutionSha256':phase['stdoutSha256'],'executionExit':0,'provenance':'independent audit original; not a new execution','dynamicInstance':{'kind':'invoice','first':'writer'}if row['id']=='AC-067'else None})
  if len(anchors)>=3:break
 assert anchors,row['id']
 rows.append({'id':row['id'],'expected':row['expected'],'observed':row['observed'],'localState':row['localState'],'anchors':anchors,'scope':'Representative inspectable assertions. Full AC conclusion inherited only from pinned independent review, not computed from these anchors.'})
with(O/'assertion-locators.json').open('x')as f:json.dump({'schema':'H5-019-assertion-locators/v1','auditSealSha256':'649565d21191f585d57038c4ef1ee9c3f86f817db8c32dbc92d820285af8a2ab','rows':rows,'notAnOracle':True},f,ensure_ascii=False,indent=2);f.write('\n')
print('26 explicit assertion locators, historical audit provenance retained')
