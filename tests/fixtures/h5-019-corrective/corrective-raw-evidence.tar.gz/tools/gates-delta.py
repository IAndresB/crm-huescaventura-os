from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess,time,gzip,os
W=Path(__file__).parent;R=Path('/Users/andres/Developer/crm-huescaventura-os');P=W/'work/gates-clean';O=W/'evidence/gates-r01';P.mkdir();O.mkdir()
def h(b):return hashlib.sha256(b).hexdigest()
with tarfile.open(W/'original-candidate.tar.gz')as t:t.extractall(P)
for n in ['scripts/verify-h5-019.py','scripts/consolidate-h5-019.py','scripts/h5_019_integrity.py','scripts/test-h5-019-corrective.py']:shutil.copy2(R/n,P/n)
shutil.copytree(R/'tests/fixtures/h5-019-corrective',P/'tests/fixtures/h5-019-corrective')
inputs={str(p.relative_to(P)):{'sha256':h(p.read_bytes()),'mode':p.stat().st_mode&0o777}for p in P.rglob('*')if p.is_file()};assert not(P/'node_modules').exists()
rows=[]
for tag,cmd in [('environment',['node','--version']),('package-manager',['pnpm','--version']),('frozen',['pnpm','install','--frozen-lockfile','--ignore-scripts']),('typecheck',['pnpm','typecheck']),('lint',['pnpm','lint']),('build',['pnpm','build']),('unit',['pnpm','test']),('audit',['pnpm','audit','--prod','--json'])]:
 started=time.time();r=subprocess.run(cmd,cwd=P,capture_output=True,env=dict(os.environ,NEXT_TELEMETRY_DISABLED='1'))
 for stream,b in [('stdout',r.stdout),('stderr',r.stderr)]:(O/(tag+'.'+stream+'.gz')).write_bytes(gzip.compress(b,mtime=0))
 row={'gate':tag,'command':cmd,'cwd':str(P),'exit':r.returncode,'started':started,'finished':time.time(),'stdoutContentSha256':h(r.stdout),'stderrContentSha256':h(r.stderr)}
 rows.append(row);(O/'results.json').write_text(json.dumps({'inputs':inputs,'gates':rows},indent=2,sort_keys=True)+'\n');print(tag,r.returncode,flush=True)
changed=[n for n,m in inputs.items()if not(P/n).exists() or h((P/n).read_bytes())!=m['sha256']or(P/n).stat().st_mode&0o777!=m['mode']]
result={'inputs':inputs,'gates':rows,'freshNodeModules':True,'protectedChanged':changed,'newBusinessPostgresExecutions':0,'originalCandidateTestsNotRelabelled':True}
(O/'results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');assert not changed and all(r['exit']==0 for r in rows)
