from pathlib import Path
import hashlib,json,gzip,stat,subprocess,tarfile,os
R=Path('/Users/andres/Developer/crm-huescaventura-os'); A=Path('/Users/andres/Developer/crm-h5-019-independent-audit-20261018T035950Z'); W=Path(__file__).parent
BASE='1e7822c11be817e4f2d4791338284aa825ad1a24';TREE='bbc8b1f1219201a8425e55a5cde6ce873cdc4006';PIN='aefd0f129e57e3324b5bc4a2ea0dd485bb340f1d57ff8810f209c0871bc00626';APIN='649565d21191f585d57038c4ef1ee9c3f86f817db8c32dbc92d820285af8a2ab'
def h(b):return hashlib.sha256(b).hexdigest()
def obj(p):return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def meta(root,n):
 p=root/n; s=p.lstat();assert stat.S_ISREG(s.st_mode) and all(not q.is_symlink() for q in [p,*p.parents]),n
 return dict(bytes=s.st_size,mode=stat.S_IMODE(s.st_mode),sha256=h(p.read_bytes()),type='regular')
def g(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert all(g('rev-parse',n)==BASE for n in ['HEAD','main','origin/main']) and g('rev-parse','HEAD^{tree}')==TREE
assert g('branch','--show-current')=='main' and g('rev-list','--left-right','--count','main...origin/main').split()==['0','0']
assert not g('diff','--name-only') and not g('diff','--cached','--name-only')
S=R/'tests/fixtures/h5-019';assert h((S/'candidate-seal.json').read_bytes())==PIN
seal=obj(S/'candidate-seal.json');assert h((S/'candidate-inventory.json').read_bytes())==seal['inventorySha256']
iv=obj(S/'candidate-inventory.json');bv=obj(S/'received-inventory.json.gz');assert len(bv['files'])==38524
new=set(g('ls-files','--others','--exclude-standard','-z').strip('\0').split('\0'));assert new==set(iv['files'])|set(iv['selfMetadataExcluded']) and len(new)==122
allfiles={}
for n,m in {**bv['files'],**iv['files']}.items():
 actual=meta(R,n);assert {k:actual[k] for k in m}==m,n;allfiles[n]=actual
for n in iv['selfMetadataExcluded']:allfiles[n]=meta(R,n)
# Establish publication independently of supplied manifests, including raw Git blobs.
entries=subprocess.check_output(['git','ls-tree','-rz','HEAD'],cwd=R).split(b'\0');published=[]
for entry in filter(None,entries):
 head,name=entry.split(b'\t');mode,typ,digest=head.decode().split();n=name.decode();b=(R/n).read_bytes()
 assert typ=='blob' and h(b)==allfiles[n]['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==digest,n
 assert bool(int(mode,8)&0o111)==bool(allfiles[n]['mode']&0o111),n
 published.append(n)
assert len(published)==38524 and set(published)==set(bv['files'])
assert h((A/'AUDIT-SEAL.json').read_bytes())==APIN
aseal=obj(A/'AUDIT-SEAL.json');assert h((A/'AUDIT-INVENTORY.json').read_bytes())==aseal['inventorySha256']
ai=obj(A/'AUDIT-INVENTORY.json');auditfiles={}
for n,m in ai['files'].items():
 actual=meta(A,n);assert {k:actual[k]for k in m}==m,n;auditfiles[n]=actual
for n in ai['selfMetadataExcluded']:auditfiles[n]=meta(A,n)
assert len(auditfiles)==152
for label,root,files in [('original-candidate',R,allfiles),('independent-audit',A,auditfiles)]:
 out=W/(label+'.tar.gz');assert not out.exists()
 with tarfile.open(out,'w:gz') as t:
  for n in sorted(files):t.add(root/n,arcname=n,recursive=False)
 with tarfile.open(out) as t:
  assert set(t.getnames())==set(files)
  for m in t:
   assert m.isfile() and m.mode==files[m.name]['mode'] and m.size==files[m.name]['bytes'] and h(t.extractfile(m).read())==files[m.name]['sha256'],m.name
 out.chmod(0o444);os.chflags(out,stat.UF_IMMUTABLE)
 receipt={'source':str(root),'files':files,'fileCount':len(files),'archive':str(out),'archiveSha256':h(out.read_bytes()),'archiveMode':stat.S_IMODE(out.stat().st_mode),'archiveImmutableFlag':bool(out.stat().st_flags&stat.UF_IMMUTABLE),'sealSha256':PIN if root==R else APIN,'base':BASE,'tree':TREE}
 p=W/(label+'-preservation.json');p.write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');p.chmod(0o444);os.chflags(p,stat.UF_IMMUTABLE)
 print(label,len(files),receipt['archiveSha256'],flush=True)
print('Preflight PASS; original 122, published 38524, migrations',len([n for n in published if n.startswith('supabase/migrations/')]))
