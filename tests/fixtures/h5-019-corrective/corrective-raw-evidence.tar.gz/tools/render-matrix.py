from pathlib import Path
import json,hashlib,re
R=Path('/Users/andres/Developer/crm-huescaventura-os');O=R/'tests/fixtures/h5-019-corrective';S=R/'specs/001-core-crm';old=json.loads((R/'tests/fixtures/h5-019/criteria-results.json').read_text());lookup={x['id']:x for x in old['criteria']};assembled=json.loads((O/'criteria-assembly.json').read_text());loc=json.loads((O/'assertion-locators.json').read_text());anchors={x['id']:x['anchors'] for x in loc['rows']}
ns=json.loads((R/'tests/fixtures/h5-019/normative-sources.json').read_text());sources={}
for n,m in ns['files'].items():
 b=(R/n).read_bytes();assert hashlib.sha256(b).hexdigest()==m['sha256'];sources[n]=m
plan=(S/'plan.md').read_text();spec=(S/'spec.md').read_text();tasks=(S/'tasks.md').read_text();rows=[]
for family in ['PT-08','PT-09','PT-10','PT-12']:
 line=next(l for l in plan.splitlines()if l.startswith('| '+family+' |'));ids=[]
 for a,b in re.findall(r'AC-(\d{3})(?:–AC-(\d{3}))?',line.split('|')[2]):ids.extend(f'AC-{n:03d}'for n in range(int(a),int(b or a)+1))
 for id in ids:
  sr=next(l for l in spec.splitlines()if l.startswith('| '+id+' |'));tr=next(l for l in tasks.splitlines()if l.startswith('| **'+id+'**'))
  ar=next(x for x in assembled['rows']if x['id']==id);assert ar['expected']==sr.split('|')[3].strip()
  rows.append({'id':id,'family':family,'sourceSpecRow':sr,'sourceTasksRow':tr,'expected':sr.split('|')[3].strip(),'observedProvenance':'inherited independent audit 649565d2; no new integrated execution','localState':ar['localState']})
assert len(rows)==26 and sum(r['localState']=='SATISFACTORIA'for r in rows)==25 and len(ns['assignedRows'])==187
with(O/'normative-revalidation.json').open('x')as f:json.dump({'sources':sources,'rows':rows,'relatedTasksAssignments':187,'assignmentLedger':'tests/fixtures/h5-019/normative-sources.json','assignmentLedgerSha256':hashlib.sha256((R/'tests/fixtures/h5-019/normative-sources.json').read_bytes()).hexdigest(),'scope':'Tasks2.1-2.3,4.6,6,7; Plan9-12; B06-B10,C01-C06,T08-T10; no global family closure'},f,ensure_ascii=False,indent=2);f.write('\n')
def cell(s):return s.replace('|','\\|').replace('\n',' ')
text='''# H5-019 — Matriz final del sucesor documental

18 de octubre de 2026.26 criterios;25 SATISFACTORIA **heredadas en tramo local**;0 FALLIDA;0 BLOQUEADA;AC-073 NO EJECUTADA, H6-015. No son26 pruebas nuevas ni PASS global de familias. Las observaciones proceden literalmente de la auditoría independiente del candidato original; este correctivo contrasta su identidad y añade pruebas de instrumentos.

Alcance aprobado: B06/B07/B08/B09/B10; C01–C06; T08/T09/T10. Tasks §§2.1–2.3/4.6/6/7 y Plan §§9–12 rigen el cierre. [Revalidación normativa](../../tests/fixtures/h5-019-corrective/normative-revalidation.json): literales actuales de Plan/SPEC/Tasks, hashes de fuentes y187 asignaciones documentales, que no se cuentan como187 pruebas. [Ensamblado autenticado](../../tests/fixtures/h5-019-corrective/criteria-assembly.json): procedencia, casos, ejecuciones y fuentes íntegros por AC. [Aserciones inspeccionables](../../tests/fixtures/h5-019-corrective/assertion-locators.json): archivo/hash/línea/aserción/caso/fase/log/hash, sin convertir anclas representativas en cobertura completa.

| AC / familia y regla | Desarrollo / verificación; contratos e implementación | Expected normativo | Observed independiente y estado local | Casos y procedencia; límites |
|---|---|---|---|---|
'''
for row in assembled['rows']:
 c=lookup[row['id']];a=anchors[row['id']][0];path=a['file'];case=a['case'];ident=case['name'];future=', '.join(row['futureH6']) or 'No nuevas asignaciones; H6 global pendiente'
 first=f"**{row['id']} / {row['family']}**; {c['rules']}"
 dev=f"D: {', '.join(row['developmentTasks'])}; V: {', '.join(row['verificationTasks'])}. {c['contractsAndUnits']}; implementación e identidades en criteria-results original sellado."
 obs=f"**{row['localState']}** heredada: {row['observed']}"
 origin=f"[{Path(path).name}:{a['registrationLine']}](../../{path}); caso {ident}, {case['phase']}; auditoría original/evidence/{Path(a['rawExecution']).name}. Fuente original: [{Path(c['originalEvidence']).name}]({Path(c['originalEvidence']).name}). Límites: {c['limitations']}; futuras: {future} NO EJECUTADA."
 text+='|'+ '|'.join(cell(x)for x in [first,dev,row['expected'],obs,origin])+'|\n'
text+='''
Las correspondencias FR/NFR/DM/SM, guardas G1–G6 y prohibiciones se conservan en el registro normativo original con identidad verificada y en las matrices de las19 dependencias. No se cambia su oráculo ni se acredita ausencia de efecto por una mención. La revisión independiente original inspeccionó las aserciones y ejecutó casos positivos/negativos, PostgreSQL real, carreras y preservación; su sello externo autentica esa revisión. El ensamblador no la sustituye ni acredita por sí solo esas propiedades.

Las PT-08/09/10/12 tienen respectivamente8/5/4/9 criterios. Tramo local satisfactorio8/5/4/8;PT-12 conserva ademásAC-073 pendiente. Otras asignaciones H6 permanecen NO EJECUTADAS: AC-056/088→H6-017;AC-057→H6-006;AC-061→H6-007;AC-067/068→H6-016;AC-074→H6-015. La restauración real no se acredita con W41. Las intenciones, aprobaciones, logs y dobles no equivalen a entrega, ejecución, pago ni hecho de negocio.

DM-PENDING-005 OPEN; Hosted/Production no acreditados. H5-019 y H5 IN PROGRESS, H6 NOT STARTED. Candidato sucesor pendiente de auditoría independiente del delta y decisión del director.
'''
with(S/'matrix-TSK-H5-019-corrective.md').open('x')as f:f.write(text)
print('26 AC current normative rows + inherited observations preserved separately')
