from pathlib import Path
import subprocess,gzip,json,time,hashlib
W=Path(__file__).parent;P=W/'work/gates-clean';O=W/'evidence/gates-unit-r02';O.mkdir()
subprocess.run(['git','init','-q','-b','main'],cwd=P,check=True)
(P/'.git/objects/info/alternates').write_text('/Users/andres/Developer/crm-huescaventura-os/.git/objects\n')
for n in ['refs/heads/main','refs/remotes/origin/main']:
 p=P/'.git'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('1e7822c11be817e4f2d4791338284aa825ad1a24\n')
subprocess.run(['git','read-tree','HEAD'],cwd=P,check=True)
t=time.time();r=subprocess.run(['pnpm','test'],cwd=P,capture_output=True)
for n,b in [('stdout',r.stdout),('stderr',r.stderr)]:(O/(n+'.gz')).write_bytes(gzip.compress(b,mtime=0))
d={'command':['pnpm','test'],'cwd':str(P),'exit':r.returncode,'started':t,'finished':time.time(),'causeOfInitialFailure':'auditor copy lacked Git object context needed by preservation-h5-017-c.test.ts; initialized independent index and read-only object alternates; no input changes','stdoutSha256':hashlib.sha256(r.stdout).hexdigest(),'stderrSha256':hashlib.sha256(r.stderr).hexdigest()}
(O/'result.json').write_text(json.dumps(d,indent=2)+'\n');print(r.stdout.decode()[-400:]);assert r.returncode==0
