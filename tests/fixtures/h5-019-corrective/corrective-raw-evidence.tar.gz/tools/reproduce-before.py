from pathlib import Path
import json,subprocess,hashlib,time,gzip,copy
W=Path(__file__).parent;R=W/'work/replay';O=W/'evidence';S=R/'tests/fixtures/h5-019'
def h(b):return hashlib.sha256(b).hexdigest()
def run(tag,cmd,oracle):
 t=time.time();p=subprocess.run(cmd,cwd=R,capture_output=True);(O/(tag+'.stdout')).write_bytes(p.stdout);(O/(tag+'.stderr')).write_bytes(p.stderr)
 return {'id':tag,'command':cmd,'cwd':str(R),'started':t,'finished':time.time(),'exit':p.returncode,'stdoutSha256':h(p.stdout),'stderrSha256':h(p.stderr),'oracle':oracle}
rows=[];seal=S/'candidate-seal.json';old=seal.read_bytes()
for tag,change in [('baseline',{}),('semantic',dict(accepted=True,H5='COMPLETED',H6='COMPLETED',materialOpen=99)),('missing',{'REMOVE':'H6'}),('unknown',{'unapprovedField':True})]:
 try:
  d=json.loads(old)
  if 'REMOVE'in change:del d[change['REMOVE']]
  else:d.update(change)
  if tag!='baseline':seal.write_text(json.dumps(d,indent=2)+'\n')
  r=run('before-seal-'+tag,['python3','scripts/verify-h5-019.py'],'baseline accepts; all seal mutations must reject');r['defectReproduced']=tag!='baseline' and r['exit']==0;rows.append(r)
 finally:seal.write_bytes(old)
# Each generator trial starts from identical protected outputs and inputs.
paths=[S/'normative-sources.json',S/'current-case-inventory.json.gz',S/'criteria-results.json',S/'results.json',R/'specs/001-core-crm/matrix-TSK-H5-019.md',S/'01-phase-15.stdout.log.gz']
backup={p:p.read_bytes() for p in paths}
for tag in ['correct','foreign','missing-observed','copied-expected','failed-test','historical-misattributed','future-H6','missing-reference']:
 try:
  d=json.loads(backup[paths[0]]);c=next(x for x in d['criteria'] if x['id']=='AC-050')
  if tag=='foreign':c['caseSelector']='^F-P01';c['expectedLocalObservation']='FALSE TASK CLAIM FROM FOREIGN DIAGNOSTIC'
  if tag=='missing-observed':c['expectedLocalObservation']=''
  if tag=='copied-expected':c['expectedLocalObservation']='ARTIFICIAL EXPECTED WITHOUT OBSERVATION'
  if tag=='historical-misattributed':c['currentCodeBase']='UNTESTED-SUCCESSOR';c['provenance']='new execution'
  if tag=='future-H6':c['localApplicable']=False
  if tag=='missing-reference':c['originalEvidence']='specs/001-core-crm/does-not-exist.md'
  if tag=='failed-test':
   b=gzip.decompress(backup[paths[-1]]).decode();b=b.replace('✔ H5-T01/T05/T06/T08','✖ H5-T01/T05/T06/T08',1);paths[-1].write_bytes(gzip.compress(b.encode(),mtime=0))
  paths[0].write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
  for p in paths[1:5]:p.unlink()
  r=run('before-generator-'+tag,['python3','scripts/consolidate-h5-019.py','results'],'SAT requires applicable audited assertions and independent observed; never copy expected')
  if paths[2].exists():
   cr=next(x for x in json.loads(paths[2].read_text())['criteria']if x['id']=='AC-050');r['observed']={k:cr.get(k) for k in ['id','currentObserved','localEvidenceState','currentCodeBase']};r['cases']=cr['caseEvidenceMatches'][:1]
  rows.append(r)
 finally:
  for p,b in backup.items():p.write_bytes(b)
(O/'before-results.json').write_text(json.dumps({'instruments':{n:h((R/n).read_bytes())for n in ['scripts/verify-h5-019.py','scripts/consolidate-h5-019.py']},'trials':rows},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{'id':r['id'],'exit':r['exit'],'state':r.get('observed',{}).get('localEvidenceState')}for r in rows],indent=2),flush=True)
