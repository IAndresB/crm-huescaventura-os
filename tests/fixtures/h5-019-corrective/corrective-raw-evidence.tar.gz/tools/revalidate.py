from pathlib import Path
import hashlib,json,subprocess
R=Path('/Users/andres/Developer/crm-huescaventura-os');A=Path('/Users/andres/Developer/crm-h5-019-independent-audit-20261018T035950Z');O=R/'tests/fixtures/h5-019-corrective'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(n,d):
 with(O/n).open('x') as f:json.dump(d,f,ensure_ascii=False,indent=2,sort_keys=True);f.write('\n')
d=json.loads((A/'evidence/dependencies-independent.json').read_text());rows=[]
for x in d['dependencies']:
 assert sha(R/x['evidence'])==x['evidenceSha256']
 for e in x['referencedEvidence']:assert sha(R/e['path'])==e['sha256'],e['path']
 subprocess.run(['git','merge-base','--is-ancestor',x['publicationOrTestedAncestor'],'HEAD'],cwd=R,check=True)
 rows.append({**x,'state':'SATISFACTORIA','observation':'Identidad de evidencia y ancestro contrastadas ahora; capacidad y ejecución heredadas de auditoría independiente intacta, no nuevas pruebas de negocio.','auditSealSha256':'649565d21191f585d57038c4ef1ee9c3f86f817db8c32dbc92d820285af8a2ab'})
for m in d['manifests']:
 assert sha(R/m['path'])==m['manifestSha256']
 v=json.loads((R/m['path']).read_text())['inputs']
 if isinstance(v,list):pairs=[(x['path'],x['sha256'])for x in v]
 else:pairs=[(n,h['sha256'] if isinstance(h,dict) else h)for n,h in v.items()]
 differences=sorted(n for n,h in pairs if sha(R/n)!=h)
 assert differences==sorted(m['differencesNow']),(m['path'],differences)
 m['currentObservation']={'count':len(pairs),'differencesReproduced':differences,'state':'SATISFACTORIA identity comparison only'}
put('dependency-revalidation.json',{'dependencies':rows,'manifests':d['manifests'],'stateContradictions':d['stateContradictions'],'count':19,'scope':'historical capacity inherited; current hash/ancestry/manifest comparison','publishedCardsChanged':False})
print('19 dependencies and 3 manifest deltas revalidated')
