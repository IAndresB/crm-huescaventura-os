from pathlib import Path
import json,subprocess,hashlib,re
R=Path('/Users/andres/Developer/crm-huescaventura-os');W=Path(__file__).parent
paths=[f'scripts/{n}'for n in ['verify-h5-019.py','consolidate-h5-019.py','h5_019_integrity.py','test-h5-019-corrective.py']]+[f'specs/001-core-crm/{n}'for n in ['corrective-TSK-H5-019.md','matrix-TSK-H5-019-corrective.md','reconciliation-TSK-H5-019.md','integrity-contract-TSK-H5-019.md']]
rows=[];links=[]
for n in paths:
 p=R/n
 if not p.exists():continue
 if p.suffix=='.py':compile(p.read_text(),n,'exec')
 r=subprocess.run(['git','diff','--no-index','--check','--','/dev/null',n],cwd=R,capture_output=True)
 rows.append({'path':n,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'command':['git','diff','--no-index','--check','--','/dev/null',n],'exit':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()});assert r.returncode in [0,1]and not r.stdout and not r.stderr,n
 if p.suffix=='.md':
  for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
   if not target.startswith(('http:','https:','#')):
    q=(p.parent/target.split('#')[0]).resolve();assert q.exists(),(n,target);links.append({'document':n,'target':target})
(W/'evidence/static-postcheck.json').write_text(json.dumps({'checks':rows,'links':links,'pythonCompiledWithoutCache':True,'protectedOutputsNeverNormalized':True},indent=2)+'\n');print('static checks',len(rows),'links',len(links))
