from pathlib import Path
import subprocess,json,hashlib,time
W=Path(__file__).parent;P=W/'work/replay';O=W/'evidence/bootstrap-r01';O.mkdir();tool=W/'authenticate-successor.py';pin=hashlib.sha256((P/'tests/fixtures/h5-019-corrective/candidate-seal.json').read_bytes()).hexdigest();rows=[]
def run(tag,cmd,expected):
 t=time.time();r=subprocess.run(cmd,cwd=P,capture_output=True)
 for n,b in [('stdout',r.stdout),('stderr',r.stderr)]:(O/(tag+'.'+n)).write_bytes(b)
 ok=r.returncode==0 if expected==0 else r.returncode!=0
 rows.append({'id':tag,'command':cmd,'started':t,'finished':time.time(),'exit':r.returncode,'expectedExit':expected,'result':'SATISFACTORIA'if ok else'FALLIDA','stdoutSha256':hashlib.sha256(r.stdout).hexdigest(),'stderrSha256':hashlib.sha256(r.stderr).hexdigest()});print(tag,r.returncode,flush=True)
cmd=['python3',str(tool),str(P),pin];run('intact-before',cmd,0)
p=P/'scripts/verify-h5-019.py';b=p.read_bytes();mode=p.stat().st_mode&0o777
try:
 p.write_text("print('FORGED PASS')\n")
 run('forged-instrument-can-print-pass',['python3','scripts/verify-h5-019.py'],0)
 run('external-rejects-forged-instrument-before-trust',cmd,1)
finally:p.write_bytes(b);p.chmod(mode)
p=P/'tests/fixtures/h5-019-corrective/.env-extra'
try:
 p.write_text('SYNTHETIC=1\n');run('external-rejects-ignored-evidence-extra',cmd,1)
finally:p.unlink()
run('restored-postcontrol',cmd,0)
result={'oracle':'externally supplied fixture seal hash, manifest, full metadata and path universe; no candidate imports','tool':str(tool),'toolSha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'trials':rows,'passed':sum(x['result']=='SATISFACTORIA'for x in rows),'failed':sum(x['result']=='FALLIDA'for x in rows)}
(O/'results.json').write_text(json.dumps(result,indent=2)+'\n');assert result['failed']==0
