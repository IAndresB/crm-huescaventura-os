from pathlib import Path
import json,hashlib,subprocess,datetime,collections,sys
B=Path('/tmp/h6-007-custody-audit');N=Path('/Users/andres/.codex/worktrees/h6-007-local/crm-huescaventura-os');W=N.parent.parent;P=Path('/Users/andres/Developer/crm-huescaventura-os');OLD=W/'h6-prepublication/crm-huescaventura-os';env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0'}
def j(p):return json.loads(p.read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*a,root=N):return subprocess.check_output(['git',*a],cwd=root,env=env)
def mode(p):return '100755' if p.stat().st_mode&0o111 else '100644'
def safe(rel):return bool(rel) and not Path(rel).is_absolute() and '..' not in Path(rel).parts
E=j(B/'core-baseline-expected-v1.json');IDENTITY=Path(sys.argv[1]);I=j(IDENTITY);checks=[]
# Identity input must be created only after the core has been sealed; no default or inferred expected hash.
for required in ['manifest','manifestSHA256','seal','sealSHA256','payloads','payloadBytes']:assert required in I,required
assert IDENTITY.parent==B and safe(I['manifest']) and safe(I['seal'])
output=B/'core-custody-v1.json'
if output.exists():raise RuntimeError('Refuse to overwrite prior result')
def chk(id,ok,detail):checks.append({'id':id,'status':'PASS' if ok else 'FAIL','detail':detail})
def validaterows(root,rows):
 bad=[]
 for x in rows:
  p=root/x['path']
  if not safe(x['path']) or not p.is_file() or p.is_symlink() or h(p)!=x['sha256'] or p.stat().st_size!=x['bytes'] or ('gitMode' in x and mode(p)!=x['gitMode']):bad.append(x['path'])
 return bad
bad=validaterows(B,E['immutableAuditInputs']);chk('C01_own_baseline_preserved',not bad,{'immutableInputs':len(E['immutableAuditInputs']),'mismatches':bad})
manifest=N/I['manifest'];seal=N/I['seal'];M=j(manifest);S=j(seal)
chk('C02_core_envelopes',h(manifest)==I['manifestSHA256'] and h(seal)==I['sealSHA256'],{'manifest':I['manifest'],'manifestSHA256':h(manifest),'seal':I['seal'],'sealSHA256':h(seal),'sealFields':S})
rows=M['files'];bad=validaterows(N,rows);paths=[x['path'] for x in rows];chk('C03_core_payloads',len(rows)==len(set(paths))==I['payloads'] and sum(x['bytes'] for x in rows)==I['payloadBytes'] and not bad and I['manifest'] not in paths and I['seal'] not in paths,{'payloads':len(rows),'bytes':sum(x['bytes'] for x in rows),'mismatches':bad,'envelopesExcludedFromOwnPayload':True})
F=j(N/E['candidateInputManifest']);bad=validaterows(N,F['files']);chk('C04_nine_frozen_test_sources',h(N/E['candidateInputManifest'])==E['candidateInputManifestSHA256'] and len(F['files'])==9 and not bad,{'files':len(F['files']),'manifestSHA256':h(N/E['candidateInputManifest']),'mismatches':bad})
H=j(B/'primary-baseline-v1.json');bad=validaterows(P,H['files']);untracked=[x.decode() for x in git('ls-files','--others','--exclude-standard','-z',root=P).split(b'\0') if x];chk('C05_primary14954_hashes',not bad and set(untracked)=={x['path'] for x in H['files']} and len(untracked)==E['primaryPaths'] and H['bytes']==E['primaryBytes'],{'paths':len(untracked),'bytes':H['bytes'],'baselineSHA256':h(B/'primary-baseline-v1.json'),'mismatches':bad,'pathSetExact':set(untracked)=={x['path'] for x in H['files']}})
primary={'head':git('rev-parse','HEAD',root=P).decode().strip(),'branch':git('symbolic-ref','HEAD',root=P).decode().strip(),'indexEmpty':not git('diff','--cached','--name-only','-z',root=P),'trackedClean':not git('diff','HEAD','--name-only','-z',root=P)};local={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'indexEmpty':not git('diff','--cached','--name-only','-z'),'trackedClean':not git('diff','HEAD','--name-only','-z')};chk('C06_git_state',primary['head']==j(B/'expected-v1.json')['primaryHead'] and primary['branch']=='refs/heads/main' and primary['indexEmpty'] and primary['trackedClean'] and local['head']==E['base'] and local['tree']==E['tree'] and local['indexEmpty'] and local['trackedClean'],{'primary':primary,'candidate':local})
prod=j(B/'product-migration-baseline-v1.json')['files'];bad=validaterows(N,prod);chk('C07_product110_migrations68',len(prod)==178 and sum(x['path'].startswith('supabase/migrations/') for x in prod)==68 and not bad,{'product':110,'migrations':68,'mismatches':bad})
norm=j(B/'normative-source-baseline-v1.json')['files'];bad=validaterows(N,norm);chk('C08_canonical_normative_and_acceptances',len(norm)==10 and not bad,{'wholeCanonicalSources':10,'mismatches':bad,'acceptanceCapsule2NotAppliedToCanonicalFiles':True})
for task,root,n in [('H6-001',W/'h6-001-local/crm-huescaventura-os',376),('H6-004',W/'h6-004-local/crm-huescaventura-os',701)]:
 inv=j(B/'protected-inputs'/f'{task}-inventory.json');bad=validaterows(root,inv['files']);idx=not git('diff','--cached','--name-only','-z',root=root);chk('C09_'+task,len(inv['files'])==n and not bad and idx,{'files':n,'mismatches':bad,'indexEmpty':idx})
base15=j(B/'H6015-documentary-baseline-v1.json');cache={}
def sourcedata(source,path):
 key=(source,path)
 if key not in cache:
  if source.startswith('snapshot:'):cache[key]=git('show',source.split(':',1)[1]+':'+path,root=OLD)
  else:
   p=W/source/'crm-huescaventura-os'/path
   if not p.is_file() or p.is_symlink():raise RuntimeError('Nonregular documentary H6-015 member')
   cache[key]=p.read_bytes()
 return cache[key]
results=[]
for pin in base15['manifestPins']:
 raw=sourcedata(pin['source'],pin['manifest']);m=json.loads(raw);bad=[]
 for row in m['files']:
  b=sourcedata(pin['source'],row['path'])
  if sha(b)!=row['sha256'] or len(b)!=row['bytes']:bad.append(row['path'])
 results.append({'source':pin['source'],'manifest':pin['manifest'],'sha256':sha(raw),'entries':len(m['files']),'mismatches':bad,'status':'PASS' if sha(raw)==pin['sha256'] and not bad else 'FAIL'})
chk('C10_H6015_16_4568',len(results)==16 and sum(x['entries'] for x in results)==4568 and all(x['status']=='PASS' for x in results),{'manifests':results,'runtimeSQL':False,'restored':False,'fourSuspendedJobs':'Documentary only, not queried or started'})
chk('C11_scope_and_sequence',all(E[k] for k in ['noFunctionalTests','noRuntimeSQL','noSourceWrites','noRemoteOperations']),{'noFreshFunctionalExecution':True,'noRuntimeSQL':True,'noSourceWrites':True,'noRemoteOperations':True,'noH6016Start':True,'acceptanceFollowsCorePASS':True,'H6':'IN_PROGRESS','H6015Quarantine':True})
r={'schema':'h6-007-independent-core-custody-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','counts':dict(collections.Counter(x['status'] for x in checks)),'checks':checks,'failed':[x['id'] for x in checks if x['status']=='FAIL'],'expectedSHA256':h(B/'core-baseline-expected-v1.json'),'identityExpectedSHA256':h(IDENTITY),'instrumentSHA256':h(Path(__file__)),'coreManifestSHA256':I['manifestSHA256'],'coreSealSHA256':I['sealSHA256'],'scope':'Technical capsule identity/custody only. Functional conclusions belong to execution and independent functional auditor. Acceptance/overlays are a subsequent separate capsule.','sourceWrites':False,'runtimeSQL':False,'functionalTests':False,'remoteOperations':False};output.write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':r['status'],'counts':r['counts'],'failed':r['failed'],'resultSHA256':h(output)},indent=2))
