from pathlib import Path
import json,hashlib,datetime,gzip,tarfile,collections,stat
B=Path('/tmp/h6-007-custody-audit');N=Path('/Users/andres/.codex/worktrees/h6-007-local/crm-huescaventura-os');E=json.loads((B/'core-lossless-expected-v1.json').read_bytes());R=Path(E['originalReceipts']);A=Path(E['independentOriginals']);checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def streamhash(f):
 digest=hashlib.sha256();size=0
 while True:
  b=f.read(1024*1024)
  if not b:break
  digest.update(b);size+=len(b)
 return digest.hexdigest(),size
def hp(p):
 with p.open('rb') as f:return streamhash(f)
def h(p):return hp(p)[0]
def j(p):return json.loads(p.read_bytes())
def safe(p):return bool(p) and not Path(p).is_absolute() and '..' not in Path(p).parts
def chk(id,ok,detail):checks.append({'id':id,'status':'PASS' if ok else 'FAIL','detail':detail})
def strings(x):
 if isinstance(x,str):yield x
 elif isinstance(x,list):
  for v in x:yield from strings(v)
 elif isinstance(x,dict):
  for v in x.values():yield from strings(v)
core=N/'tests/fixtures/h6-007/delivery-manifest-v1.json';cm=j(core);inventory={x['path']:x for x in cm['files']};pins=[E['captureIndex'],E['archive'],E['independentManifest'],E['independentSeal']];pinbad=[r['path'] for r in pins if inventory.get(r['path'])!=r or hp(N/r['path'])!=(r['sha256'],r['bytes'])];chk('L01_core_bound_artifacts',h(core)==E['coreManifestSHA256'] and not pinbad and h(N/E['archive']['path'])==E['archiveSHA256'],{'artifacts':4,'mismatches':pinbad,'archiveSHA256':h(N/E['archive']['path'])})
index=j(N/E['captureIndex']['path']);captures=[]
for row in index['files']:
 assert safe(row['path']) and safe(row['source'])
 stored=N/row['path'];raw=R/row['source'];assert stored.is_file() and not stored.is_symlink() and raw.is_file() and not raw.is_symlink()
 if row['encoding']=='gzip':
  with gzip.open(stored,'rb') as f:recovered=streamhash(f)
 elif row['encoding']=='identity':recovered=hp(stored)
 else:raise ValueError('Unsupported declared encoding')
 original=hp(raw);storedIdentity=hp(stored);expectedRaw=(row['rawSHA256'],row['rawBytes']);ok=recovered==original==expectedRaw and storedIdentity==(row['sha256'],row['bytes']);captures.append({'source':row['source'],'path':row['path'],'encoding':row['encoding'],'rawSHA256':recovered[0],'rawBytes':recovered[1],'storedSHA256':storedIdentity[0],'storedBytes':storedIdentity[1],'status':'PASS' if ok else 'FAIL'})
chk('L02_82_captures_lossless',len(captures)==E['captureFiles'] and len({x['source'] for x in captures})==82 and all(x['status']=='PASS' for x in captures),{'files':len(captures),'encodingCounts':dict(collections.Counter(x['encoding'] for x in captures)),'rawBytes':sum(x['rawBytes'] for x in captures),'storedBytes':sum(x['storedBytes'] for x in captures),'mismatches':[x for x in captures if x['status']!='PASS'],'originalsRoot':str(R)})
m=j(N/E['independentManifest']['path']);s=j(N/E['independentSeal']['path']);originalRows=[]
for row in m['files']:
 assert safe(row['path']);p=A/row['path'];declared=int(row['mode'],8);actualMode=stat.S_IMODE(p.stat().st_mode);ok=p.is_file() and not p.is_symlink() and hp(p)==(row['sha256'],row['bytes']) and actualMode==declared;originalRows.append({'path':row['path'],'sha256':row['sha256'],'bytes':row['bytes'],'expectedMode':row['mode'],'actualMode':format(actualMode,'04o'),'status':'PASS' if ok else 'FAIL'})
chk('L03_independent258_originals',len(originalRows)==m['payloadCount']==258 and sum(x['bytes'] for x in originalRows)==m['payloadBytes']==E['independentPayloadBytes'] and all(x['status']=='PASS' for x in originalRows),{'payloads':len(originalRows),'bytes':sum(x['bytes'] for x in originalRows),'modeCounts':dict(collections.Counter(x['actualMode'] for x in originalRows)),'mismatches':[x for x in originalRows if x['status']!='PASS']})
manifestName='delivery-manifest-v1.json';sealName='delivery-seal-v1.json';envelopes=[]
for rel,pin in [(manifestName,E['independentManifestSHA256']),(sealName,E['independentSealSHA256'])]:
 p=A/rel;copy=N/Path(E['independentManifest']['path']).parent/rel;envelopes.append({'path':rel,'sha256':h(p),'bytes':p.stat().st_size,'mode':format(stat.S_IMODE(p.stat().st_mode),'04o'),'status':'PASS' if h(p)==pin==h(copy) and p.is_file() and not p.is_symlink() else 'FAIL'})
chk('L04_independent_envelopes_binding',all(x['status']=='PASS' for x in envelopes) and s['manifestSHA256']==E['independentManifestSHA256']==cm['independentAuditManifestSHA256'] and s['manifestBytes']==(A/manifestName).stat().st_size and s['manifestMode']==format(stat.S_IMODE((A/manifestName).stat().st_mode),'04o') and s['payloadCount']==258 and s['payloadBytes']==236776341,{'envelopes':envelopes,'coreBindsIndependentManifest':True})
expected={x['path']:{'sha256':x['sha256'],'bytes':x['bytes'],'mode':x['mode']} for x in m['files']};expected.update({x['path']:{'sha256':x['sha256'],'bytes':x['bytes'],'mode':x['mode']} for x in envelopes});archive=[];issues=[]
with tarfile.open(N/E['archive']['path'],'r:gz') as t:
 members=t.getmembers();names=[x.name for x in members]
 if len(names)!=len(set(names)) or set(names)!=set(expected):issues.append('Manifest set mismatch or duplicate archive member')
 for item in members:
  if not safe(item.name) or not item.isfile() or item.name not in expected:issues.append('Unsafe or foreign member '+item.name);continue
  with t.extractfile(item) as f:raw=streamhash(f)
  x=expected[item.name];ok=raw==(x['sha256'],x['bytes']) and item.size==x['bytes'] and item.mode==int(x['mode'],8);archive.append({'path':item.name,'sha256':raw[0],'bytes':raw[1],'mode':format(item.mode,'04o'),'status':'PASS' if ok else 'FAIL'})
chk('L05_archive260_exact_set_bytes_modes',len(archive)==len(expected)==E['archiveMembers'] and not issues and all(x['status']=='PASS' for x in archive),{'members':len(archive),'bytes':sum(x['bytes'] for x in archive),'issues':issues,'mismatches':[x for x in archive if x['status']!='PASS'],'extracted':False,'method':'tar stream read only; every member checked against sealed manifest and persistent original, no links or foreign paths allowed'})
result={'schema':'h6-007-core-lossless-independent-package-readback-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','counts':dict(collections.Counter(x['status'] for x in checks)),'checks':checks,'captures':captures,'independentOriginals':originalRows,'archiveMembers':archive,'expectedSHA256':h(B/'core-lossless-expected-v1.json'),'instrumentSHA256':h(Path(__file__)),'failed':[x['id'] for x in checks if x['status']=='FAIL'],'functionalTests':False,'runtimeSQL':False,'sourceWrites':False,'remoteOperations':False};out=B/'core-lossless-readback-v1.json';assert not out.exists();out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':result['status'],'counts':result['counts'],'failed':result['failed'],'resultSHA256':h(out)},indent=2))
