from pathlib import Path
import json,hashlib,subprocess,datetime,collections
B=Path('/tmp/h6-007-custody-audit');W=Path('/Users/andres/.codex/worktrees');P=Path('/Users/andres/Developer/crm-huescaventura-os');N=W/'h6-007-local/crm-huescaventura-os';OLD=W/'h6-prepublication/crm-huescaventura-os';E=json.loads((B/'expected-v1.json').read_bytes());checks=[];env={'PATH':'/usr/bin:/bin','GIT_OPTIONAL_LOCKS':'0'}
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def j(p):return json.loads(p.read_bytes())
def git(*args,root=N):return subprocess.check_output(['git',*args],cwd=root,env=env)
def mode(p):return '100755' if p.stat().st_mode&0o111 else '100644'
def chk(id,ok,detail):checks.append({'id':id,'status':'PASS' if ok else 'FAIL','detail':detail})
def write(name,data):
 p=B/name
 if p.exists():raise RuntimeError('Refuse overwrite '+name)
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def validate(root,rows):
 bad=[]
 for x in rows:
  p=root/x['path'];safe=not Path(x['path']).is_absolute() and '..' not in Path(x['path']).parts
  if not safe or not p.is_file() or p.is_symlink() or h(p)!=x['sha256'] or p.stat().st_size!=x['bytes'] or ('gitMode' in x and mode(p)!=x['gitMode']):bad.append(x['path'])
 return bad
prior=Path('/Users/andres/.codex/worktrees/h6-004-publication/receipts/independent-custody/primary-historical-hashes-v1.json');H=j(prior);paths=[x.decode() for x in git('ls-files','--others','--exclude-standard','-z',root=P).split(b'\0') if x];current=[]
for rel in sorted(paths):
 p=P/rel
 if not p.is_file() or p.is_symlink():raise RuntimeError('Nonregular historical file '+rel)
 current.append({'path':rel,'bytes':p.stat().st_size,'sha256':h(p),'gitMode':mode(p)})
expected={x['path']:x for x in H['files']};bad=[x['path'] for x in current if expected.get(x['path'])!=x];same=set(paths)==set(expected) and not bad
snapshot={'schema':'h6-007-independent-primary-baseline-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(P),'head':git('rev-parse','HEAD',root=P).decode().strip(),'paths':len(current),'bytes':sum(x['bytes'] for x in current),'previousSnapshotSHA256':h(prior),'previousSnapshotAt':H['at'],'previousHashIdentity':'PASS' if same else 'FAIL','files':current};write('primary-baseline-v1.json',snapshot)
chk('I01_primary14954_hashes',h(prior)==E['previousPrimarySnapshotSHA256'] and same and len(current)==E['primaryPaths'] and snapshot['bytes']==E['primaryBytes'],{'paths':len(current),'bytes':snapshot['bytes'],'mismatches':bad,'pathSetExact':set(paths)==set(expected),'newBaselineSHA256':h(B/'primary-baseline-v1.json')})
state={'head':git('rev-parse','HEAD',root=P).decode().strip(),'branch':git('symbolic-ref','HEAD',root=P).decode().strip(),'indexEmpty':not git('diff','--cached','--name-only','-z',root=P),'trackedClean':not git('diff','HEAD','--name-only','-z',root=P)};chk('I02_primary_git',state['head']==E['primaryHead'] and state['branch']=='refs/heads/main' and state['indexEmpty'] and state['trackedClean'],state)
for task,inventory,root,pin,count in [('H6-001',OLD/'tests/fixtures/h6-prepublication/protected-h6-001-source-v1.json',W/'h6-001-local/crm-huescaventura-os',E['H6001InventorySHA256'],E['H6001Paths']),('H6-004',Path('/Users/andres/.codex/worktrees/h6-004-prepublication/receipts/independent-final/original-inputs-v1.json'),W/'h6-004-local/crm-huescaventura-os',E['H6004InventorySHA256'],E['H6004Paths'])]:
 m=j(inventory);bad=validate(root,m['files']);dest=B/'protected-inputs'/f'{task}-inventory.json';dest.parent.mkdir(exist_ok=True);dest.write_bytes(inventory.read_bytes());chk('I03_'+task,h(inventory)==pin and len(m['files'])==count and not bad and not git('diff','--cached','--name-only','-z',root=root),{'source':str(root),'inventory':str(inventory),'inventorySHA256':h(inventory),'paths':count,'bytes':sum(x['bytes'] for x in m['files']),'mismatches':bad,'indexEmpty':not git('diff','--cached','--name-only','-z',root=root)})
prepath=OLD/'tests/fixtures/h6-prepublication/preflight-v1.json';pre=j(prepath);source_cache={}
def getsource(source,path):
 key=(source,path)
 if key not in source_cache:
  if source.startswith('snapshot:'):source_cache[key]=git('show',source.split(':',1)[1]+':'+path,root=OLD)
  else:
   p=W/source/'crm-huescaventura-os'/path
   if not p.is_file() or p.is_symlink():raise RuntimeError('Invalid H6-015 documentary member')
   source_cache[key]=p.read_bytes()
 return source_cache[key]
manifestresults=[]
for r in pre['protectedH6015Manifests']:
 raw=getsource(r['source'],r['manifest']);m=json.loads(raw);bad=[]
 for row in m['files']:
  d=getsource(r['source'],row['path'])
  if sha(d)!=row['sha256'] or len(d)!=row['bytes']:bad.append(row['path'])
 manifestresults.append({'source':r['source'],'manifest':r['manifest'],'sha256':sha(raw),'expectedSHA256':r['sha256'],'entries':len(m['files']),'mismatches':bad,'status':'PASS' if sha(raw)==r['sha256'] and not bad else 'FAIL'})
write('H6015-documentary-baseline-v1.json',{'manifestPins':pre['protectedH6015Manifests'],'results':manifestresults,'runtimeSQL':False,'restoration':False,'fourSuspendedJobs':'Documentary scope only; not queried or started'})
chk('I04_H6015_16_4568',h(prepath)==E['H6015PreflightSHA256'] and len(manifestresults)==16 and sum(x['entries'] for x in manifestresults)==4568 and all(x['status']=='PASS' for x in manifestresults),{'manifests':16,'entries':4568,'mismatches':[x for x in manifestresults if x['status']!='PASS'],'baselineSHA256':h(B/'H6015-documentary-baseline-v1.json')})
files=[]
for row in git('ls-tree','-rz',E['base'],'src','supabase/migrations').split(b'\0'):
 if not row:continue
 meta,path=row.split(b'\t',1);md,typ,oid=meta.split();path=path.decode();p=N/path;raw=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest();files.append({'path':path,'bytes':len(raw),'sha256':sha(raw),'gitMode':md.decode(),'baseBlob':oid.decode(),'status':'PASS' if actual==oid.decode() and mode(p)==md.decode() and typ==b'blob' else 'FAIL'})
write('product-migration-baseline-v1.json',{'base':E['base'],'tree':E['tree'],'files':files});chk('I05_product_and_migrations',len(files)==178 and sum(x['path'].startswith('supabase/migrations/') for x in files)==68 and all(x['status']=='PASS' for x in files),{'product':110,'migrations':68,'mismatches':[x for x in files if x['status']!='PASS']})
ns={'head':git('rev-parse','HEAD').decode().strip(),'tree':git('rev-parse','HEAD^{tree}').decode().strip(),'indexEmpty':not git('diff','--cached','--name-only','-z'),'trackedDelta':git('diff','HEAD','--name-only').decode().splitlines()};chk('I06_H6007_base',ns['head']==E['base'] and ns['tree']==E['tree'] and ns['indexEmpty'],ns)
source_paths=['specs/001-core-crm/tasks.md','specs/001-core-crm/spec.md','specs/001-core-crm/plan.md','docs/architecture.md','docs/state-machines.md','specs/001-core-crm/acceptance-TSK-H5-019.md','specs/001-core-crm/acceptance-TSK-H6-013.md','specs/001-core-crm/acceptance-TSK-H6-001-local.md','specs/001-core-crm/acceptance-TSK-H6-004.md','specs/001-core-crm/acceptance-TSK-H6-006-local.md'];sources=[]
for path in source_paths:
 raw=git('show',E['base']+':'+path);live=(N/path).read_bytes();dest=B/'normative-sources-v1'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);sources.append({'path':path,'snapshot':str(dest.relative_to(B)),'sha256':sha(raw),'bytes':len(raw),'currentBytesExact':raw==live})
write('normative-source-baseline-v1.json',{'base':E['base'],'files':sources});chk('I07_direct_source_snapshot',len(sources)==10 and all(x['currentBytesExact'] for x in sources),{'sources':sources})
result={'schema':'h6-007-independent-initial-custody-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'counts':dict(collections.Counter(x['status'] for x in checks)),'failed':[x['id'] for x in checks if x['status']=='FAIL'],'expectedSHA256':h(B/'expected-v1.json'),'instrumentSHA256':h(Path(__file__)),'sourceWrites':False,'runtimeSQL':False,'remoteOperations':False,'functionalTests':False,'H6016Started':False};write('initial-custody-v2.json',result);print(json.dumps({'status':result['status'],'counts':result['counts'],'failed':result['failed'],'baselineSHA256':h(B/'primary-baseline-v1.json'),'resultSHA256':h(B/'initial-custody-v2.json')},indent=2))
