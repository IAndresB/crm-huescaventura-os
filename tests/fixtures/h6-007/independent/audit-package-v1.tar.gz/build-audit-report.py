from pathlib import Path
import datetime,hashlib,json,re
B=Path(__file__).resolve().parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
readback=json.loads((B/'source-and-evidence-verification-v2.json').read_text())
assert readback['status']=='PASS'
allruns=[]
for p in sorted((B/'runs').glob('*/result.json')):
 r=json.loads(p.read_text());log=p.parent/'stdout.log';cases=[]
 for n,line in enumerate(log.read_text().splitlines(),1):
  m=re.match(r'^(ok|not ok) \d+ - (.*)$',line)
  if m:cases.append({'title':m[2],'result':'PASS' if m[1]=='ok' else 'FAIL','line':n})
 assert H(log)==r['stdoutSHA256']
 allruns.append({'id':p.parent.name,'suite':r['suite'],'status':r['status'],'counts':r['counts'],'cases':cases,'log':str(log.relative_to(B)),'stdoutSHA256':H(log),'result':str(p.relative_to(B))})
final={s:[r for r in allruns if r['suite']==s and r['status']=='PASS'][-1] for s in ['candidate','history','independent']}
assert [final[s]['counts']['tests'] for s in ['candidate','history','independent']]==[32,1,10]
refs=[]
def appendref(group,run,case):
 row={'id':group+'-'+str(len([x for x in refs if x['group']==group])+1).zfill(2),'group':group,'title':case['title'],'log':run['log'],'line':case['line'],'stdoutSHA256':run['stdoutSHA256'],'result':case['result']}
 refs.append(row)
for s,group in [('candidate','C'),('history','H'),('independent','Q')]:
 for c in final[s]['cases']:appendref(group,final[s],c)
reg=[x for x in readback['runs'] if x['run']=='regression-02'][0]
for c in reg['cases']:
 if c['title'].startswith('H6-007 H01 '):continue
 appendref('R',{'log':'author-evidence-frozen-v1/regression-02/stdout.log','stdoutSHA256':reg['stdoutSHA256']},c)
assert len(refs)==91 and all(x['result']=='PASS' for x in refs)
def pick(group,token):
 selected=[x['id'] for x in refs if x['group']==group and token in x['title']]
 assert selected,(group,token)
 return selected
def cs(*ids): return sum((pick('C','H6-007 '+x+' ') for x in ids),[])
def qs(*ids): return sum((pick('Q','IA-'+x+' ') for x in ids),[])
def rs(*tokens): return sum((pick('R',x) for x in tokens),[])
m={
 'IA01':[], 'IA02':cs('P01')+qs('Q02'), 'IA03':cs('P01')+rs('P04/P05'), 'IA04':cs('P01')+qs('Q02'),
 'IA05':cs('A01')+qs('Q02'), 'IA06':cs('A01')+qs('Q02'), 'IA07':cs('A01','F12')+qs('Q02'),
 'IA08':cs('A03')+qs('Q02'), 'IA09':cs('A02')+qs('Q03'), 'IA10':cs('F11')+qs('Q02'),
 'IA11':cs('B01','B02')+qs('Q01'), 'IA12':cs('D01')+qs('Q01'), 'IA13':cs('C03'),
 'IA14':cs('C01')+qs('Q03'), 'IA15':cs('P01','A02')+qs('Q03')+rs('J01/J06'),
 'IA16':cs('C02')+qs('Q03')+rs('J06 concurrent'), 'IA17':cs('D02')+qs('Q04'),
 'IA18':cs('D03')+qs('Q04'), 'IA19':cs('D04')+qs('Q04')+rs('N01/N05','N05: JSON null'),
 'IA20':cs('D05','F10')+qs('Q07'), 'IA21':cs('E01')+qs('Q08')+rs('S02 unauthenticated'),
 'IA22':cs('E01')+qs('Q08')+rs('S05 signed'), 'IA23':cs('E04')+qs('Q08')+rs('S01 all new'),
 'IA24':cs('E04')+qs('Q08'), 'IA25':cs('E03')+qs('Q08')+rs('S01 all new'),
 'IA26':cs('F01','F05'), 'IA27':cs('F02','F03','F06')+qs('Q05'),
 'IA28':cs('F04','F07')+qs('Q05'), 'IA29':cs('F08')+qs('Q06'),
 'IA30':cs('F09','F10')+qs('Q07'), 'IA31':cs('F12')+qs('Q07'),
 'IA32':cs('A04','E04')+pick('H','H01'), 'IA33':cs('X01','P01')+pick('H','H01')+rs('N02: actual supplier'),
 'IA34':[], 'IA35':[], 'IA36':[]}
notes={
'IA01':'21 fuentes normativas/dependencia y 185 inputs previos cotejados. H5-019 satisfecho documentalmente en la base publicada; no se cuenta como ejecución nueva.',
'IA02':'Cadena creada por adaptadores publicados. Rama interna y prestación excepcional revisada AC-063 declaradas; no se acredita start/perform/finish ordinario en el focal.',
'IA23':'Roles PostgreSQL ordinarios anon/authenticated/runtime y actor inhabilitado probados; no se introduce una política de roles de negocio nueva.',
'IA26':'Fallos reales antes de INSERT de revisión/reapertura; el hecho/evaluación, historia y resultado se comparan tras rollback.',
'IA31':'F12 repetido independientemente prueba un nuevo cierre de otra Booking mientras espera la raíz objetivo. Q07 propio prueba lectura de la otra Booking con tercera sesión auténtica; no se confunden esas dos coberturas.',
'IA33':'AC-046: X01 más H5-013 N02; pago sin factura, resolución documental y discrepancia, sin venta externa íntegra cerrada. AC-062: H01 recupera contexto archivado/códigos/historial, sin nueva API de archivo Booking; creación de expediente anual y no reutilización no se atribuyen a H01. AC-063: ejecución excepcional con revisión; no aprobación retroactiva. Antecedentes de identidad deben incorporarse por identidad o quedar como límite.',
'IA34':'Producto, 68 migraciones, nueve fuentes candidatas y normas cotejados; Git tracked sin delta al momento funcional. Los manifiestos del cierre y custodia final todavía requieren recepción documental posterior.',
'IA35':'Fuentes y resultados exactos, 19 FAIL del autor y 3 FAIL funcionales del instrumento independiente conservados con sucesor. Setup y fallos de verificación estática separados. La matriz es compuesta; no se afirma una primera ejecución completa limpia ni regresión global nueva.',
'IA36':'Solo PostgreSQL/Storage locales y datos/sesión sintéticos. No runtime H6-015/S11, datos reales, commit/push/Drive/despliegue. Este dictamen técnico no modifica estados; cierre local requiere paquete documental y custodia final, H6 global IN PROGRESS.'}
controls=[]
for line in (B/'expected-v1.md').read_text().splitlines():
 if not line.startswith('| IA'):continue
 bits=[x.strip() for x in line.strip('|').split('|')];key=bits[0];assert key in m
 controls.append({'id':key,'scenario':bits[1],'expected':bits[2],'status':'PASS','references':m[key],'note':notes.get(key,'Aserciones y resultados persistidos según referencias exactas.'),'documentaryEvidence':['preflight-sources-v1.json','source-and-evidence-verification-v2.json'] if key in ['IA01','IA34','IA35','IA36'] else []})
assert len(controls)==36
reconciliation=[]
for run in readback['runs']:
 for case in run['cases']:
  if case['result']!='FAIL':continue
  successor=final['candidate'] if run['run'].startswith('focal') else {'id':'regression-02','cases':reg['cases'],'log':'author-evidence-frozen-v1/regression-02/stdout.log','stdoutSHA256':reg['stdoutSHA256']}
  target=[x for x in successor['cases'] if x['title']==case['title'] and x['result']=='PASS'];assert len(target)==1
  reconciliation.append({'origin':'author','failedRun':run['run'],'title':case['title'],'failedLine':case['line'],'failureLogSHA256':run['stdoutSHA256'],'successor':successor['id'],'successorLine':target[0]['line'],'successorLogSHA256':successor['stdoutSHA256']})
for run in allruns:
 for case in run['cases']:
  if case['result']!='FAIL':continue
  target=[x for x in final['independent']['cases'] if x['title']==case['title'] and x['result']=='PASS'];assert len(target)==1
  reconciliation.append({'origin':'independent','failedRun':run['id'],'title':case['title'],'failedLine':case['line'],'failureLogSHA256':run['stdoutSHA256'],'successor':final['independent']['id'],'successorLine':target[0]['line'],'successorLogSHA256':final['independent']['stdoutSHA256']})
assert sum(x['origin']=='author' for x in reconciliation)==19
assert sum(x['origin']=='independent' for x in reconciliation)==3
snaps=[]
for p in (B/'author-evidence-frozen-v1/source-snapshots').glob('*/manifest.json'):
 d=json.loads(p.read_text())
 for f in d['files']:
  q=p.parent/f['path']; assert H(q)==f['sha256']; assert 'bytes' not in f or q.stat().st_size==f['bytes'];snaps.append({'manifest':str(p.relative_to(B)),**f,'observedBytes':q.stat().st_size,'sizeDeclared':'bytes' in f})
mat={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','expectedSHA256':H(B/'expected-v1.md'),'controlCount':36,'controls':controls,'executedReferences':refs,'uniqueFunctionalCases':91,'composition':{'authorFocal':32,'history':1,'authorTargetedRegressionsExcludingHistory':48,'newIndependentCounterexamples':10},'independentlyExecuted':43,'independentCounterexampleFamilies':8,'scope':'composite case coverage; 48 historical assertion cases freshly executed by author and independently read, not rerun by auditor','finalDocumentaryReception':'PENDING','limitations':list(notes.values())}
(B/'coverage-matrix-independent-v1.json').write_text(json.dumps(mat,ensure_ascii=False,indent=2)+'\n')
ledger={'status':'PASS','rawRuns':allruns,'authorRuns':readback['runs'],'reconciledFailedCaseRecords':22,'reconciliation':reconciliation,'sourceSnapshotsVerified':snaps,'setupFailures':['author-evidence-frozen-v1/focal-01/result.json','runs/independent-2026-10-24T01-32-30.634575+00-00/result.json'],'instrumentalReadbackFailure':'source-and-evidence-verification-v1.json retained; v2 counts each FAIL once and retains diagnostic repetition lines','staticChecks':'static-check-attempts-v1.json retained; final typecheck PASS; no persistence claim from static checks'}
(B/'attempt-ledger-independent-v1.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
verdict={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'TSK-H6-007','status':'PASS_TECHNICAL_LOCAL_ISOLATED','materialFindingsOpen':0,'findingResolved':{'id':'H6007-AUD-01','description':'discrepancy date reused pre-close fixture time','resolution':'fresh at re-attested; candidate A01 and own Q02 independently pass chronology'},'directAssignments':['SPEC-FR-CLOSE-004','AC-061','PT-10','E2E-07','SM G5'],'controlCount':36,'controlsPass':36,'candidateRepeat':32,'historyRepeat':1,'ownCounterexampleTests':10,'ownCounterexampleFamilies':8,'authorTargetedRegressionsRead':49,'authorQualityRead':{'unitTests':212,'typecheck':'PASS','lint':'PASS','build':'PASS'},'uniqueFunctionalCoverage':91,'failureHistory':{'authorFailedCaseRecords':19,'ownFailedCaseRecords':3,'ownPriorAttempt':'7 PASS / 3 FAIL; retained','setupFailures':2,'allFailedCaseRecordsHaveExactTitleSuccessor':True,'additionalStaticInstrumentFailures':'preserved separately'},'independence':'separate same-model agent; own expected frozen before candidate, own instrument/assertions, process and database; published fixtures reused by identity; not human or institutional external audit','closureGate':'functional technical gate satisfied; written closure and final custody manifests await subsequent independent documentary reception','stateChangesPerformed':False,'H6Global':'IN PROGRESS','matrixSHA256':H(B/'coverage-matrix-independent-v1.json'),'ledgerSHA256':H(B/'attempt-ledger-independent-v1.json'),'limitations':notes['IA33']+' '+notes['IA36']}
(B/'functional-verdict-v1.json').write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'verdict':verdict['status'],'controls':36,'uniqueCoverage':91,'independentExecuted':43,'failuresReconciled':22,'sourceSnapshots':len(snaps),'verdictSHA256':H(B/'functional-verdict-v1.json')},indent=2))
