# TSK-H6-007 — Expected independiente previo al candidato

Base normativa y de producto: `9c15e6d143822f7fcc84f29744194554630f4ac4`, árbol `fe7cabb05e44462121c70ad52405765e2c94fcd2`. Las fuentes publicadas se copiaron por identidad a `normative-source/`; su inventario y los 185 inputs de producto/migraciones/helpers están en `preflight-sources-v1.json` (SHA-256 `b1cb314ceecf7417535cb7748baffba9a87b7d04cd0c6991b0ee8411e20b7e83`). No se ha recibido ni leído implementación nueva H6-007 ni ejecutado una batería funcional.

## Alcance y dependencia

Tasks §4.7, líneas 2379–2393, exige cierre conjunto seguido de evidencia económica contradictoria y reapertura fundada: solo la evaluación afectada vuelve a Pendiente, se retira cierre conjunto actual, se conserva fundamento/cierre histórico y causa, y permanecen Acceptance, ejecución y contrato. B01–B10, C01–C06 y T09/T10 indican componentes y fronteras, no autorización para añadir funciones.

Las cinco asignaciones directas de Tasks §6 son exactamente:

| ID | Fuente y obligación |
|---|---|
| SPEC-FR-CLOSE-004 | SPEC §10.10, línea 266; reapertura material limitada con fundamento anterior y causa conservados. |
| AC-061 | SPEC §24.3, línea 549; discrepancia material de pago posterior al cierre reabre economía, retira cierre conjunto y conserva las otras dimensiones. |
| PT-10 | Plan §10.2, línea 403; tres cierres, excepciones acotadas y reapertura fundada, en el alcance integrado H6-007. |
| E2E-07 | SPEC §9, línea 134; evidencia/documento nuevo que invalida criterio, cierre histórico y operación preservados. Referencias principales AC-046, AC-061–063. |
| G5 de SM | SM §2.1, línea 32 y §16; solo dependencias aprobadas pueden provocar reevaluación, sin satisfacer guardas de otra dimensión por arrastre. |

H5-019 es la única dependencia formal de la ficha. Su satisfacción documental local/aislada se acredita por Tasks 2259–2270, acceptance-TSK-H5-019.md (D01–D03 y sellos identificados), cierre consolidado, matriz 26 AC/25 locales satisfactorios y reconciliación H5-013/015. Son antecedentes publicados por identidad; no nuevas pruebas H6-007 ni validación Hosted/Production. Las menciones históricas H6 NOT STARTED o publicación pendiente se conservan con su fecha; no sustituyen el mandato actual. AC-061 y E2E-07 mantienen necesidad de evidencia propia.

Normas transversales: Tasks §§2.2–2.3 V-DOM/V-DAT/V-AT/V-SM/V-NEG/V-EVI, V-MIG solo ante cambio persistente; Plan §§7.1–7.3 y 10.1; SPEC §§11/17/18, AC-058–063 en sus cláusulas pertinentes; SM G1–G6, SM-CL-01–05, §16 y §18; Constitución P05–P08/P10–P15/P18–P20. La norma prevalece sobre los helpers y la salida del código.

## Escenarios A–F autorizados

- A. Evidencia económica contradictoria: Booking previamente cerrada recibe evidencia posterior que invalida cierre económico; solo dimensión afectada reabre, preservando cierre histórico y causa.
- B. Evidencia posterior no contradictoria: no modifica condiciones del cierre; no produce reapertura injustificada.
- C. Evidencia duplicada: repetición de registro/procesamiento no duplica efectos ni transiciones.
- D. Evidencia insuficiente: intento de modificar cierre sin fundamento verificable se rechaza o conserva pendiente conforme al contrato; no fabricar datos suficientes.
- E. Permisos y guardas: actor sin autorización no puede provocar modificación indebida.
- F. Fallos y recuperación: fallos controlados antes/durante/después de límites pertinentes prueban atomicidad, recuperación, historia y ausencia de estados parciales incompatibles.

## Matriz independiente de 36 controles

Cada control requiere aserciones sobre resultados persistidos y referencias recuperables. Las condiciones esperadas son previas al candidato; esta matriz no atribuye PASS por nombre de prueba o mención de suite.

| Control | Caso | Expected verificable |
|---|---|---|
| IA01 | Base | SHA base, fuentes y H5-019 satisfechos en ámbito documental local; producto heredado identificado. |
| IA02 | Base/PT-10 | Crear expediente por contratos de aplicación: cadena comercial/Acceptance, servicios, pago y conciliación/asignación pertinentes, prestación real y economía propia. No INSERT/UPDATE de negocio para satisfacer guardas. |
| IA03 | Base/PT-10 | Abrir/evaluar por separado comercial, operacional y económico con criterios/evidencias aplicables; No aplica tiene fundamento. Las tres resueltas aún no equivalen a cierre conjunto. |
| IA04 | Base/PT-10 | Cierre conjunto explícito persistido; actor, momento declarado/registrado, evidencia, criterios/revisiones e identificador reconstruibles. No estado arbitrario sembrado. |
| IA05 | A/AC-061 | Nueva discrepancia de pago verificada, vinculada a la misma Booking/movimiento y posterior al cierre en registro/instante pertinente; importe y alcance verificables. |
| IA06 | A/CLOSE-004 | Cambiar insumo retira vigencia del cierre actual y hace Pendiente la economía; distingue evaluación histórica Resuelto de currentStatus Pendiente y reapertura explícita posterior. |
| IA07 | A/G5 | Comercial y operacional, Acceptance/versiones, ejecución, servicios/cantidades/noches, otros movimientos y Booking ajena preservados; no contrato nuevo ni efecto externo. |
| IA08 | A/P07 | Cierre previo idéntico, invalidación enlazada con tabla/registro causante, operación/actor/evidencia cuando disponibles, fundamento anterior/actual y causa de reapertura. |
| IA09 | A | Reopen explícito de economía después de invalidación crea nueva evaluación Pendiente; no vuelve a ejecutar ni reescribe origen; repetir efectos con identidad estable es replay autorizado. |
| IA10 | A/B | Corregir/restaurar después el fundamento no reactiva silenciosamente el cierre anterior; reevaluar y cerrar de nuevo son actos explícitos, con historial previo intacto. |
| IA11 | B | Registrar evidencia nueva no contradictoria, materialmente ajena a fundamentos de cierre, conserva tres estados vigentes, invalidaciones y cierre. |
| IA12 | B/D | Intentar reapertura explícita sin criterio invalidado se rechaza; razón/evidencia genérica no sustituye fundamento. |
| IA13 | C/T09 | Recibir/registrar la misma evidencia con identidad estable no añade un segundo hecho canónico ni duplica historia/efecto. Recepción y aplicación siguen distintas. |
| IA14 | C/G6 | Repetir comando de discrepancia produce el resultado previo autorizado y exactamente una mutación/invalidación; no recupera cierre ni crea hechos nuevos. |
| IA15 | C/G6 | Repetir reapertura o cierre por la misma identidad reconoce resultado anterior; intento distinto incompatible no duplica transición. |
| IA16 | C/E2 | Misma clave con material/Booking/razón distinta es conflicto; no reutilización ciega ni escritura parcial. |
| IA17 | D/G2 | Evidencia inexistente, no verificada o no vinculada al alcance no justifica reapertura. El rechazo conserva estado, historia y operación durable. |
| IA18 | D/G2 | Evidencia de otra Booking/otra porción o instante/contexto inválidos no se traslada a la raíz objetivo. |
| IA19 | D/G4 | Falta de razón, fuente, revisión o fundamento material obligatorio no crea cierre/reapertura; pendientes legítimos no se convierten en cero o satisfechos. |
| IA20 | A/D | Versión/material anterior a la discrepancia no autoriza un cierre posterior obsoleto; conflicto preserva hecho concurrente. |
| IA21 | E/G1 | Sin contexto autenticado válido se deniega la operación sensible y su lectura sin divulgar datos. |
| IA22 | E/G1 | Contexto/actor/rol falsificados por solicitante se rechazan con persistencia intacta. |
| IA23 | E/G1 | Actor inhabilitado y rol ordinario sin facultad no pueden reabrir ni leer resultados protegidos. |
| IA24 | E/G6 | Reautorizar replay: un resultado anteriormente committed no se entrega a contexto revocado/no autorizado. |
| IA25 | E/V-DAT | Escritura directa runtime no puede forzar cierre, evaluación, invalidación o historia; no tratar propietario/migración/BYPASSRLS como actor ordinario. |
| IA26 | F/V-AT | Fallo previo a escritura sensible: estado/historia/resultado/intención aplicables sin efecto; reintento posterior válido una sola vez. |
| IA27 | F/V-AT | Fallo real durante cambio causante o inserción de invalidación revierte ambos, historia y resultado; comprobar filas reales y no solo excepción. |
| IA28 | F/V-AT | Fallo diferido durante COMMIT: evidencia de haber alcanzado frontera y rollback de toda unidad, no confundir con rechazo de admisión. |
| IA29 | F/G6 | Respuesta perdida tras COMMIT real: efecto durable una vez; consulta/reintento misma identidad recupera resultado sin nueva mutación. La simulación de transporte no sustituye PostgreSQL. |
| IA30 | F/T10 | Cierre frente a cambio económico: ambos órdenes y solapamiento real sobre la raíz Booking; ningún cierre vigente fundado en material obsoleto. |
| IA31 | F/T10 | Operación sobre otra Booking progresa mientras se espera la raíz afectada; snapshot ajeno intacto. |
| IA32 | E/G4 | Lectura canónica/proyección refleja estado vigente e historia con permisos actuales; una proyección no es autoridad alternativa ni fuente de cambio. |
| IA33 | E2E-07 | AC-046 y AC-062/063 se desglosan por cláusulas cubiertas/reutilizadas/límites. Caso interno no acredita factura externa/suplido; no inventar API de archivo de expediente. |
| IA34 | Integridad | Preservar bytes de fuentes/heredados protegidos, normas y paquetes anteriores. Si hay cambio de producto, identificar delta y verificar únicamente regresiones pertinentes. |
| IA35 | V-EVI | Fuentes de prueba exactas, inputs, versiones reales, comandos, logs crudos, resultados, expected/observed y FAIL/sucesores conservados. No sumar repeticiones como cobertura única ni afirmar clean global. |
| IA36 | Límites | Solo datos sintéticos y PostgreSQL aislado propio. Sin credenciales/datos reales, efecto negocio externo, H6-015 runtime/S11, commit/push/Drive/Production. Cierre local condicionado al mandato actual; H6 global IN PROGRESS. |

## Contrapruebas propias previstas

Ocho familias, con subcasos cuando sea materialmente necesario; no es un compromiso de inflar el recuento mediante repeticiones:

1. **Q01 / B–D:** evidencia posterior no material sobre Booking cerrada, intento de reopen infundado y comparación de todos los estados/filas pertinentes.
2. **Q02 / A:** ciclo contradicción real → invalidación económica → corrección que restaura insumos. Comprobar que no resucita cierre; reapertura/reevaluación/nuevo cierre explícitos e historia intacta.
3. **Q03 / C–E:** duplicado exacto y colisión de identidad con contenido/Booking distinto, más replay sin autorización vigente. Contar cambios/operaciones reales.
4. **Q04 / D:** fundamento ausente, no verificado o de otra raíz; rechazo sin parcialidad ni divulgación.
5. **Q05 / F:** fallo real en invalidación y fallo diferido COMMIT con señal independiente de alcance, rollback de origen+historia+resultado y reintento posterior.
6. **Q06 / F:** pérdida de respuesta posterior al commit PostgreSQL, recuperación durable por identidad y ausencia de duplicación.
7. **Q07 / F:** intercalación real cierre/cambio de pago en ambos órdenes con observación de locks; Booking ajena continúa.
8. **Q08 / E:** actor inhabilitado/contexto falsificado y escrituras directas denegadas sobre evaluación/cierre/invalidación/historia, incluyendo acceso a resultado previo.

## Reutilización y límites de independencia

Se pueden reutilizar por identidad los helpers publicados `fifthDatabase` (cadena 68), `jointFixture`, `jointCommands`, `closureCommands` y preparación de pagos/economía; oráculos y aserciones serán propios. `jointFixture` acredita prestación excepcional revisada mediante API (`exceptional:true`), no start/perform/finish ordinario; se debe etiquetar AC-063 y preservar su revisión, sin aprobación retroactiva. Sus documentos manuales reference_only no prueban conservación de binario Storage. El caso interno no requiere inventar suplido, factura o fianza; sus criterios No aplica quedan explícitos. La contradicción principal sí debe ser material de pago conforme AC-061, no solo una marca cosmética.

Los permisos se comprobarán con las fronteras reales vigentes y sesión sintética autorizada; no se modificará la seguridad ni se activará Auth/Hosted real. PostgreSQL real acredita persistencia/rollback/locks. El usuario permite dobles de canales externos, no mocks de base de datos. Los fallos instrumentales de transporte o fixtures se distinguirán de fallos de producto. Triggers de fallo locales y lecturas de observador no siembran estados de negocio ni conceden facultades ordinarias.

No se ejecutan pruebas hasta aviso del integrador. La réplica y sus recursos serán propios, bajo `/tmp/h6-007-independent`, con nombres/puertos dinámicos y sin compartir escrituras con el implementador. Toda evidencia recibida posteriormente se identificará antes de leer/copiar. Auditor separado del mismo modelo; no auditor humano ni auditoría externa institucional. La auditoría no decide normativa nueva.
