import {before,after,test} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID as uid,createHash} from 'node:crypto';
import {createServer} from 'node:net';
import {mkdir,writeFile} from 'node:fs/promises';
import {join} from 'node:path';
import {fifthDatabase,read,write} from './replica/tests/support/h5-018-fifth-isolated.ts';
import {jointFixture,conclusions} from './replica/tests/support/h5-joint-closure-fixtures.ts';
import {secondWorkActor} from './replica/tests/support/h5-work-isolated.ts';
import {H5013ClosureAdapter} from './replica/src/infrastructure/postgres/h5-closure-adapter.ts';
import {H3003PaymentAdapter,type PaymentCommand} from './replica/src/infrastructure/postgres/h3-payment-adapter.ts';
import {verifyAuth} from './replica/src/application/verified-auth.ts';

type H=Awaited<ReturnType<typeof fifthDatabase>>;
type F=Awaited<ReturnType<typeof jointFixture>>;
let h:H;
const observations:{case:string;point:string;value:unknown}[]=[];
const note=(name:string,point:string,value:unknown)=>observations.push({case:name,point,value});
const hash=(x:unknown)=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
async function availablePort():Promise<number>{
 const s=createServer();await new Promise<void>((resolve,reject)=>{s.once('error',reject);s.listen(0,'127.0.0.1',resolve);});
 const address=s.address();assert.ok(address&&typeof address==='object');const port=address.port;
 await new Promise<void>((resolve,reject)=>s.close(e=>e?reject(e):resolve()));return port;
}
before(async()=>{
 const port=await availablePort(),label='h6007audit_'+uid().replaceAll('-','').slice(0,12);
 h=await fifthDatabase(label,port);
 note('SETUP','real PostgreSQL',Array.from(await h.observer`select version() version,current_database() database,pg_backend_pid() backend`));
 note('SETUP','isolation',{label,port,temporary:h.temporary,session:'synthetic authorized Auth evidence; existing PostgreSQL F1/F2 contracts',businessFixture:'published jointFixture; reviewed exceptional operational reality, not normal start/finish',storage:'manual reference_only, no binary Storage claim'});
});
after(async()=>{
 try{await h?.close();}finally{
  const dir=process.env.H6007_AUDIT_CAPTURE;if(!dir)throw new Error('H6007_AUDIT_CAPTURE_REQUIRED');
  await mkdir(dir,{recursive:true});await writeFile(join(dir,'independent-observed.json'),JSON.stringify(observations,null,2)+'\n');
 }
});
async function now(){return new Date(String((await h.observer`select clock_timestamp()::text at`)[0]!.at)).toISOString();}
async function paymentView(f:F){const v=await h.payments.read(await h.auth(),read,f.payment.paymentId);assert.ok(v);return v;}
async function closed(name:string){
 const f=await jointFixture(h),before=await f.j.c.view();
 for(const d of ['commercial','operational','economic'] as const)assert.equal(before.assessments[d]!.currentStatus,'Resuelto');
 assert.equal(before.jointClosure.current,false);
 const q=await f.j.command({at:await now()}),r=await f.j.run(q),view=await f.j.c.view();
 assert.equal(r.replayed,false);assert.equal(view.jointClosure.current,true);assert.equal(view.jointClosure.history.length,1);
 note(name,'closed from application facts',{bookingId:f.bookingId,paymentId:f.payment.paymentId,command:q,view});
 return f;
}
async function discrepancy(f:F){
 const pv=await paymentView(f),q=await f.payment.discrepancy(pv.current.revision,'0.00','100.00');
 return f.payment.attest({...q,at:await now(),sourceRef:'SYNTHETIC independent later contradictory statement',reason:'SYNTHETIC independently verified doubt over first 100.00 of paid portion'});
}
async function immutableBusiness(){
 const tables=await h.observer`select tablename from pg_tables where schemaname='crm_private' and (tablename like 'b03_%' or tablename like 'b04_%') order by tablename`;
 const result:Record<string,unknown>={};
 for(const row of tables){const name=String(row.tablename);assert.match(name,/^b0[34]_[a-z0-9_]+$/);result[name]=Array.from(await h.observer.unsafe(`select to_jsonb(x) row from crm_private.${name} x order by to_jsonb(x)::text`));}
 return result;
}
async function closeRows(f:F){
 const result:Record<string,unknown>={};
 for(const table of ['b06_closure_assessments','b06_closure_operations','b06_joint_closures','b06_closure_invalidations'])result[table]=Array.from(await h.observer.unsafe(`select to_jsonb(x) row from crm_private.${table} x where booking_id=$1 order by to_jsonb(x)::text`,[f.bookingId]));
 return result;
}
async function opCount(table:'b05_payment_operations'|'b06_closure_operations',id:string){return Number((await h.observer.unsafe(`select count(*)::int n from crm_private.${table} where operation_id=$1`,[id]))[0]!.n);}
function assertOnlyEconomic(before:any,after:any){
 assert.equal(after.jointClosure.current,false);assert.equal(after.assessments.economic.currentStatus,'Pendiente');
 for(const d of ['commercial','operational'])assert.deepEqual(after.assessments[d],before.assessments[d]);
 assert.deepEqual(after.jointClosure.history,before.jointClosure.history);
}

test('IA-Q01 B/D: nonmaterial later evidence preserves closed state and unfounded reopen is rejected',async()=>{
 const f=await closed('Q01'),before=await f.j.c.view(),rows=await closeRows(f),business=await immutableBusiness();
 const q=h.req('evidence',{claim:'SYNTHETIC note confirms already recorded context without changing any criterion',coverage:f.bookingId,certainty:'reviewed',source_kind:'manual'},f.bookingId,'other');
 await h.evidence.apply(await h.auth(),write,{...q,occurredAt:await now(),coverage:f.bookingId});
 assert.deepEqual(await f.j.c.view(),before);assert.deepEqual(await closeRows(f),rows);
 const reopen=await f.j.c.command('economic',{}, {action:'reopen',serviceApplicability:await f.j.flags()});
 await assert.rejects(f.j.c.run(reopen),/REOPEN_UNFOUNDED/);
 assert.deepEqual(await f.j.c.view(),before);assert.deepEqual(await immutableBusiness(),business);
 note('Q01','noncontradictory registered; failed explicit reopen without effect',{evidenceId:q.targetId,reopen,rowsSHA256:hash(rows),view:await f.j.c.view()});
});

test('IA-Q02 A: payment contradiction and resolution do not resurrect prior joint closure',async()=>{
 const f=await closed('Q02'),before=await f.j.c.view(),business=await immutableBusiness(),paymentBefore=await paymentView(f),q=await discrepancy(f);
 const closedAt=Date.parse(String((before.jointClosure.history[0] as any).state?.at??(before.jointClosure.history[0] as any).at??before.jointClosure.latestClose!.at));
 assert.ok(Date.parse(q.at)>=closedAt,'contradiction chronology must follow joint closure');
 await h.payments.apply(await h.auth(),write,q);const invalid=await f.j.c.view();assertOnlyEconomic(before,invalid);
 assert.deepEqual(await immutableBusiness(),business);assert.ok(invalid.invalidations.length>0);
 assert.deepEqual((await paymentView(f)).receipts,paymentBefore.receipts);
 const resolve=await f.payment.attest({action:'resolve',operationId:uid(),paymentId:f.payment.paymentId,expectedRevision:(await paymentView(f)).current.revision,sourceRef:'SYNTHETIC independent subsequent bank contrast',reason:'SYNTHETIC verified original 100.00 portion after discrepancy',at:await now(),evidenceId:uid(),incidentId:q.incidentId,sourceEvidenceId:f.payment.sourceEvidenceId});
 await h.payments.apply(await h.auth(),write,resolve);const restored=await f.j.c.view();assertOnlyEconomic(before,restored);
 assert.equal((await paymentView(f)).current.incidents.find(x=>x.id===q.incidentId)?.resolved,true);
 const reopen=await f.j.c.command('economic',{}, {action:'reopen',serviceApplicability:await f.j.flags()});await f.j.c.run(reopen);
 assert.equal((await f.j.c.view()).assessments.economic!.status,'Pendiente');
 await f.j.c.run(await f.j.c.command('economic',conclusions.economic,{action:'evaluate',serviceApplicability:await f.j.flags()}));
 assert.equal((await f.j.c.view()).jointClosure.current,false);
 await f.j.run(await f.j.command());const final=await f.j.c.view();assert.equal(final.jointClosure.current,true);assert.equal(final.jointClosure.history.length,2);assert.deepEqual(final.jointClosure.history.slice(0,1),before.jointClosure.history);
 assert.deepEqual(await immutableBusiness(),business);
 note('Q02','sticky invalidation and explicit new closure',{contradiction:q,resolution:resolve,invalid,restored,final});
});

test('IA-Q03 C: exact payment and reopen retries are durable while changed identity material conflicts',async()=>{
 const f=await closed('Q03'),q=await discrepancy(f);await h.payments.apply(await h.auth(),write,q);
 const pv=await paymentView(f),cv=await f.j.c.view();assert.equal((await h.payments.apply(await h.auth(),write,q)).replayed,true);
 assert.deepEqual(await paymentView(f),pv);assert.deepEqual(await f.j.c.view(),cv);assert.equal(await opCount('b05_payment_operations',q.operationId),1);
 const changed=await f.payment.attest({...q,reason:'SYNTHETIC incompatible revised claim under same identity'});await assert.rejects(h.payments.apply(await h.auth(),write,changed),/REPLAY_CONFLICT/);
 const reopen=await f.j.c.command('economic',{}, {action:'reopen',serviceApplicability:await f.j.flags()});await f.j.c.run(reopen);
 const after=await closeRows(f);assert.equal((await f.j.c.run(reopen)).replayed,true);assert.deepEqual(await closeRows(f),after);
 const other=await closed('Q03-other'),wrong=await other.j.c.proof({...reopen,bookingId:other.bookingId});await assert.rejects(other.j.c.run(wrong),/REPLAY_CONFLICT/);
 assert.equal((await other.j.c.view()).jointClosure.current,true);assert.equal(await opCount('b06_closure_operations',reopen.operationId),1);
 note('Q03','duplicates and identity conflicts',{paymentOperation:q.operationId,reopenOperation:reopen.operationId,rows:after,payment:await paymentView(f)});
});

test('IA-Q04 D: absent, foreign and candidate evidence cannot justify founded reopen',async()=>{
 const f=await closed('Q04'),q=await discrepancy(f);await h.payments.apply(await h.auth(),write,q);
 const good=await f.j.c.command('economic',{}, {action:'reopen',serviceApplicability:await f.j.flags()}),other=await closed('Q04-other');
 const foreign=await other.j.c.command('economic',{}, {action:'reopen',serviceApplicability:await other.j.flags()});
 const material=Object.fromEntries(Object.entries(good).filter(([key])=>!['operationId','evidenceId'].includes(key)));
 const e=h.req('evidence',{claim:'closure:'+await f.j.hash(material),coverage:f.bookingId,certainty:'candidate',source_kind:'communication'},f.bookingId,'other');
 await h.evidence.apply(await h.auth(),write,{...e,occurredAt:good.at,coverage:f.bookingId});
 const before=await closeRows(f),view=await f.j.c.view();
 for(const evidenceId of [uid(),foreign.evidenceId,e.targetId]){
  const bad={...good,evidenceId};await assert.rejects(f.j.c.run(bad));assert.deepEqual(await closeRows(f),before);assert.deepEqual(await f.j.c.view(),view);
 }
 const absent={...good,reason:''};await assert.rejects(f.j.c.run(absent));assert.deepEqual(await closeRows(f),before);
 assert.equal(await opCount('b06_closure_operations',good.operationId),0);assert.equal((await other.j.c.view()).jointClosure.current,true);
 note('Q04','rejected insufficient support',{bookingId:f.bookingId,absent:good.operationId,foreignEvidenceId:foreign.evidenceId,candidateEvidenceId:e.targetId,preservedRowsSHA256:hash(before)});
});

for(const phase of ['invalidation-write','deferred-commit'] as const)test(`IA-Q05 F: real ${phase} fault rolls back cause and invalidation then allows one retry`,async()=>{
 const f=await closed('Q05-'+phase),q=await discrepancy(f),before=await f.j.c.view(),pv=await paymentView(f),rows=await closeRows(f);
 const table=phase==='invalidation-write'?'b06_closure_invalidations':'b05_payment_revisions';
 await h.admin.unsafe("create sequence crm_private.h6007_audit_marker; grant usage on sequence crm_private.h6007_audit_marker to crm_h0_f2_executor; create function crm_private.h6007_audit_fault() returns trigger language plpgsql security definer set search_path=pg_catalog,pg_temp as $$ begin perform nextval('crm_private.h6007_audit_marker'); raise exception 'H6007_AUDIT_INJECTED'; end $$");
 await h.admin.unsafe(phase==='deferred-commit'?`create constraint trigger h6007_audit_fault after insert on crm_private.${table} deferrable initially deferred for each row execute function crm_private.h6007_audit_fault()`:`create trigger h6007_audit_fault before insert on crm_private.${table} for each row execute function crm_private.h6007_audit_fault()`);
 let marker=false;
 try{
  await assert.rejects(h.payments.apply(await h.auth(),write,q));marker=Boolean((await h.admin`select is_called from crm_private.h6007_audit_marker`)[0]!.is_called);assert.equal(marker,true);
  assert.deepEqual(await f.j.c.view(),before);assert.deepEqual(await paymentView(f),pv);assert.deepEqual(await closeRows(f),rows);assert.equal(await opCount('b05_payment_operations',q.operationId),0);
 }finally{await h.admin.unsafe(`drop trigger h6007_audit_fault on crm_private.${table}; drop function crm_private.h6007_audit_fault(); drop sequence crm_private.h6007_audit_marker`);}
 assert.equal((await h.payments.apply(await h.auth(),write,q)).replayed,false);const applied=await f.j.c.view();assertOnlyEconomic(before,applied);
 assert.equal((await h.payments.apply(await h.auth(),write,q)).replayed,true);assert.equal(await opCount('b05_payment_operations',q.operationId),1);
 note('Q05','fault, observed real boundary, rollback and one retry',{phase,marker,operationId:q.operationId,priorRowsSHA256:hash(rows),after:applied});
});

test('IA-Q06 F: post-COMMIT response loss recovers a single durable payment effect',async()=>{
 const f=await closed('Q06'),q=await discrepancy(f),before=await f.j.c.view();let committed=false,lost=false;
 const transport={begin:async(options:any,work:any)=>{const result=await h.runtime.begin(options,work);committed=true;if(!lost){lost=true;throw new Error('SYNTHETIC_RESPONSE_LOST_AFTER_REAL_COMMIT');}return result;}};
 const adapter=new H3003PaymentAdapter(transport as any,h.f1,h.f2);
 await assert.rejects(adapter.apply(await h.auth(),write,q));assert.equal(committed,true);assert.equal(lost,true);assert.equal(await opCount('b05_payment_operations',q.operationId),1);
 const after=await f.j.c.view(),pv=await paymentView(f);assertOnlyEconomic(before,after);
 const replay=await h.payments.apply(await h.auth(),write,q);assert.equal(replay.replayed,true);assert.equal(await opCount('b05_payment_operations',q.operationId),1);assert.deepEqual(await f.j.c.view(),after);assert.deepEqual(await paymentView(f),pv);
 note('Q06','response transport fault only; PostgreSQL commit completed',{operationId:q.operationId,committed,lost,replay,after});
});

async function waitUntil(check:()=>Promise<boolean>){const until=Date.now()+15000;while(Date.now()<until){if(await check())return;await new Promise(r=>setTimeout(r,15));}throw new Error('AUDIT_REAL_LOCK_WAIT_NOT_OBSERVED');}
for(const first of ['close','writer'] as const)test(`IA-Q07 F: ${first} first under real Booking overlap preserves independent progress`,async()=>{
 const f=await jointFixture(h),other=await closed('Q07-unrelated-'+first),unrelated=await other.j.c.view(),q=await f.j.command(),change=await discrepancy(f);
 const session=await secondWorkActor(h),unrelatedSession=await secondWorkActor(h),unrelatedRuntime=h.connect('crm_h0_runtime'),unrelatedAdapter=new H5013ClosureAdapter(unrelatedRuntime,h.f1,h.f2),runtime=h.connect('crm_h0_runtime'),adapter=new H5013ClosureAdapter(runtime,h.f1,h.f2),guard=h.connect('crm_h0_migration'),monitor=h.connect('crm_h0_migration');
 let release!:()=>void,ready!:()=>void,pid=0;const held=new Promise<void>(r=>release=r),acquired=new Promise<void>(r=>ready=r);
 const gate=guard.begin(async tx=>{pid=Number((await tx`select pg_backend_pid() pid`)[0]!.pid);await tx`select crm_private.booking_preparation_lock(${f.bookingId}::uuid)`;ready();await held;});await acquired;
 const close=()=>session.auth().then(a=>adapter.close(a,write,q)),writer=()=>h.auth().then(a=>h.payments.apply(a,write,change));
 let one:Promise<unknown>|undefined,two:Promise<unknown>|undefined,locks:unknown;
 const waiters=async()=>Number((await monitor`select count(*) n from pg_locks w join pg_locks g on w.locktype=g.locktype and w.classid=g.classid and w.objid=g.objid where g.pid=${pid} and g.locktype='advisory' and g.granted and not w.granted`)[0]!.n);
 try{
  one=(first==='close'?close:writer)();one.catch(()=>{});await waitUntil(async()=>await waiters()===1);
  two=(first==='close'?writer:close)();two.catch(()=>{});await waitUntil(async()=>await waiters()===2);
  await unrelatedRuntime.unsafe("set statement_timeout='12000ms'");
  assert.deepEqual(await unrelatedAdapter.read(await unrelatedSession.auth(),read,other.bookingId),unrelated);
  locks=Array.from(await monitor`select pid,locktype,classid,objid,granted,pg_blocking_pids(pid) blockers from pg_locks where locktype='advisory' order by pid,granted`);
 }finally{release();await gate;}
 try{
  const results=await Promise.allSettled([one!,two!]);assert.equal(results[0]!.status,'fulfilled');
  if(first==='close')assert.equal(results[1]!.status,'fulfilled');else{assert.equal(results[1]!.status,'rejected');assert.match(String((results[1] as PromiseRejectedResult).reason),/MATERIAL_CONFLICT/);}
  const view=await f.j.c.view();assert.equal(view.jointClosure.current,false);assert.equal(view.jointClosure.history.length,first==='close'?1:0);assert.equal(view.assessments.economic!.currentStatus,'Pendiente');assert.deepEqual(await other.j.c.view(),unrelated);
  note('Q07','real root wait and outcome',{first,bookingId:f.bookingId,unrelatedBookingId:other.bookingId,locks,results:results.map(x=>x.status==='fulfilled'?{status:x.status}:{status:x.status,reason:String(x.reason)}),view});
 }finally{await Promise.allSettled([runtime.end({timeout:1}),unrelatedRuntime.end({timeout:1}),guard.end({timeout:1}),monitor.end({timeout:1})]);}
});

test('IA-Q08 E: forged access, direct writes and disabled replay cannot alter closure',async()=>{
 const f=await closed('Q08'),q=await discrepancy(f);await h.payments.apply(await h.auth(),write,q);
 const reopen=await f.j.c.command('economic',{}, {action:'reopen',serviceApplicability:await f.j.flags()}),before=await closeRows(f),auth=await h.auth();
 await assert.rejects(h.closures.apply({...auth} as typeof auth,write,reopen));
 const foreign=await verifyAuth({verify:async()=>({subject:uid(),sessionId:auth.sessionId,passwordVerified:true,mfaVerified:true})},uid());await assert.rejects(h.closures.apply(foreign,write,reopen));
 for(const table of ['b06_closure_assessments','b06_joint_closures','b06_closure_invalidations'])await assert.rejects(h.runtime.unsafe(`delete from crm_private.${table} where booking_id=$1`,[f.bookingId]));
 assert.deepEqual(await closeRows(f),before);await f.j.c.run(reopen);const persisted=await closeRows(f),verified=await h.auth();
 await h.migration`select crm_api.set_actor_enabled(${h.actorId}::uuid,false,'ready')`;
 try{
  await assert.rejects(h.closures.apply(verified,write,reopen));await assert.rejects(h.closures.read(verified,read,f.bookingId));await assert.rejects(h.payments.apply(verified,write,q));assert.deepEqual(await closeRows(f),persisted);
 }finally{await h.migration`select crm_api.set_actor_enabled(${h.actorId}::uuid,true,'ready')`;}
 h.auth=(await secondWorkActor(h)).auth;
 assert.equal((await f.j.c.view()).assessments.economic!.status,'Pendiente');assert.equal(await opCount('b06_closure_operations',reopen.operationId),1);
 note('Q08','authorization and reauthorization preserve durable result',{bookingId:f.bookingId,reopenOperation:reopen.operationId,persistedSHA256:hash(persisted)});
});
