// Independent execution wrapper. Uses pinned published Storage software and own ephemeral resources.
// No cache downloads and no source mutation. Functional invocation requires integrator-ready notice.
import {spawn,spawnSync} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {mkdtemp,mkdir,writeFile,rm,access} from 'node:fs/promises';
import {createServer} from 'node:net';
import {once} from 'node:events';
import {join,resolve} from 'node:path';
const B=resolve(import.meta.dirname),root=join(B,'replica'),rt=join(B,'rt');
const bin='/Users/andres/Applications/Postgres.app/Contents/Versions/17/bin';
const storageCommit='5def1dfc15ab7f08fe271c7d1e70542424524e4e',cache=join(rt,'crm-supabase-storage-'+storageCommit);
const out=process.env.H6007_AUDIT_CAPTURE;if(!out||!resolve(out).startsWith(B+'/runs/'))throw new Error('AUDIT_CAPTURE_OUTSIDE_ALLOWED_ROOT');
const selected=process.argv.slice(2).map(x=>resolve(x));
if(!selected.length||selected.some(x=>!x.startsWith(B+'/')||!x.endsWith('.test.ts')))throw new Error('AUDIT_TEST_SELECTION_REQUIRED');
const env={PATH:process.env.PATH,LANG:'C',LC_ALL:'C',TMPDIR:rt,POSTGRES_H0_BIN:bin,H6007_AUDIT_CAPTURE:out,H6007_OUTPUT:out,H4014_CAPTURE_DIR:out};
const native=[];
function run(command,args,cwd=root){
 const p=spawnSync(command,args,{cwd,encoding:'utf8',env});native.push({command,args,cwd,exitCode:p.status,stdout:p.stdout,stderr:p.stderr});
 if(p.status!==0)throw new Error('AUDIT_NATIVE_SETUP_FAILED:'+command);return p.stdout.trim();
}
async function port(){const s=createServer();s.listen(0,'127.0.0.1');await once(s,'listening');const n=s.address().port;await new Promise(r=>s.close(r));return n;}
let temporary,storage,pgStarted=false;
try{
 await access(join(cache,'dist/start/server.js'));if(run('git',['rev-parse','HEAD'],cache)!==storageCommit)throw new Error('AUDIT_STORAGE_IDENTITY');run('git',['diff','--quiet'],cache);
 temporary=await mkdtemp(join(rt,'storage-'));await mkdir(join(temporary,'socket'),{mode:0o700});
 const dbPort=await port(),httpPort=await port(),adminPort=await port();
 run(join(bin,'initdb'),['-D',join(temporary,'data'),'--username=postgres','--auth-local=trust','--auth-host=trust','--no-locale','--encoding=UTF8']);
 run(join(bin,'pg_ctl'),['-D',join(temporary,'data'),'-l',join(temporary,'postgres.log'),'-o',`-k '${join(temporary,'socket')}' -h 127.0.0.1 -p ${dbPort}`,'-w','start']);pgStarted=true;
 const config={SERVER_HOST:'127.0.0.1',SERVER_PORT:String(httpPort),SERVER_ADMIN_PORT:String(adminPort),DATABASE_URL:`postgresql://postgres@127.0.0.1:${dbPort}/postgres`,DB_INSTALL_ROLES:'true',AUTH_JWT_SECRET:randomBytes(32).toString('hex'),AUTH_ENCRYPTION_KEY:randomBytes(16).toString('hex'),STORAGE_BACKEND:'file',STORAGE_FILE_BACKEND_PATH:join(temporary,'objects'),STORAGE_S3_BUCKET:'synthetic-private',STORAGE_S3_REGION:'local',SERVER_REGION:'local',PG_QUEUE_ENABLE:'false',S3_PROTOCOL_ENABLED:'false',VECTOR_ENABLED:'false',ICEBERG_ENABLED:'false',IMAGE_TRANSFORMATION_ENABLED:'false',LOG_LEVEL:'silent'};
 const configPath=join(temporary,'runtime.env');await writeFile(configPath,Object.entries(config).map(([k,v])=>`${k}=${v}`).join('\n'),{mode:0o600});
 storage=spawn(process.execPath,['dist/start/server.js'],{cwd:cache,env:{...env,...config,NODE_ENV:'production'},stdio:'ignore'});
 const endpoint=`http://127.0.0.1:${httpPort}`;let ready=false;
 for(let i=0;i<100;i++){if(storage.exitCode!==null)throw new Error('AUDIT_STORAGE_EXITED');try{ready=(await fetch(endpoint+'/status')).ok;}catch{}if(ready)break;await new Promise(r=>setTimeout(r,100));}
 if(!ready)throw new Error('AUDIT_STORAGE_NOT_READY');
 await writeFile(join(out,'runtime-identity.json'),JSON.stringify({postgres:run(join(bin,'postgres'),['--version']),node:process.version,storageCommit,ports:{dbPort,httpPort,adminPort},environment:'own ephemeral PostgreSQL and Storage, loopback only',selected,credentials:'synthetic generated privately; not recorded in evidence'},null,2)+'\n');
 const child=spawn(process.execPath,['--test','--test-concurrency=1','--test-reporter=tap','--experimental-strip-types',...selected],{cwd:root,env:{...env,STORAGE_H1_RUNTIME:cache,STORAGE_H1_CONFIG:configPath,STORAGE_H1_ENDPOINT:endpoint},stdio:'inherit'});
 const [code]=await once(child,'exit');process.exitCode=code??1;
}finally{
 if(storage&&storage.exitCode===null){const stopped=once(storage,'exit');storage.kill('SIGTERM');await Promise.race([stopped,new Promise(r=>setTimeout(r,5000))]);if(storage.exitCode===null){storage.kill('SIGKILL');await stopped;}}
 if(pgStarted)run(join(bin,'pg_ctl'),['-D',join(temporary,'data'),'-m','fast','-w','stop']);
 if(temporary)await rm(temporary,{recursive:true,force:true});
 await writeFile(join(out,'native-bootstrap.json'),JSON.stringify(native,null,2)+'\n');
}
