from pathlib import Path
import datetime,hashlib,json,subprocess
B=Path(__file__).resolve().parent;R=Path('/Users/andres/.codex/worktrees/h6-007-local/crm-huescaventura-os');D=B/'documentary-readback-v1';D.mkdir(exist_ok=False)
H=lambda x:hashlib.sha256(x).hexdigest()
base='9c15e6d143822f7fcc84f29744194554630f4ac4'; rows=[]
paths=['specs/001-core-crm/evidence-TSK-H6-007.md','specs/001-core-crm/matrix-TSK-H6-007.md','tests/fixtures/h6-007/H5-dependency-readback-v1.json']
manifest=json.loads((R/paths[-1]).read_text())
for f in manifest['files']:
 x=(R/f['path']).read_bytes();assert len(x)==f['bytes'] and H(x)==f['sha256'];assert subprocess.check_output(['git','show',base+':'+f['path']],cwd=R)==x
 paths.append(f['path'])
paths += ['tests/fixtures/h5-012/f03-20261015/final-focal.json','tests/fixtures/h5-012/f03-20261015/final-focal.log','tests/integration/postgres-h5-012-candidate61.test.ts']
for path in paths:
 p=R/path;x=p.read_bytes();dest=D/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(x);dest.chmod(0o444);rows.append({'path':path,'bytes':len(x),'sha256':H(x)})
rr=json.loads((R/'tests/fixtures/h5-012/f03-20261015/final-focal.json').read_text());log=R/'tests/fixtures/h5-012/f03-20261015/final-focal.log';assert H(log.read_bytes())==rr['log_sha256']
lines=[{'line':i,'text':x} for i,x in enumerate(log.read_text().splitlines(),1) if any('H5-012 '+key+' ' in x for key in ['H06','H07','H08'])]
assert len(lines)==3 and all(x['text'].startswith('✔') for x in lines)
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_DOCUMENTARY_COHERENCE','documents':rows,'dependencyFilesVerifiedAgainstPublishedBase':len(manifest['files']),'inheritedAC062':{'source':'H5-012 candidate61 H06-H08','logSHA256':H(log.read_bytes()),'cases':lines,'newExecution':False,'scope':'archive recovery without closure; human identity merge preserves distinct Bookings; distinct codes after cancellation/new case and code reuse rejection'},'review':['Five direct assignments and A-F match frozen independent expected.','32 focal + 49 regression includes H01 once; 32+1 independent repetitions not added to unique count.','10 new independent counterexample tests in 8 families; 36 controls are a composite audit matrix, not 36 new functional tests.','19 author failed cases and own historical failures retained; no first-run/global clean claim.','AC046 external documentary adjunct; AC062 inherited clauses explicitly separated; AC063 exceptional reviewed performance, no retroactive approval.','Local technical PASS only; acceptance act and final custody are subsequent, H6 global IN PROGRESS.'],'unexecuted':'No new functional tests; no formal closure mutation; final core/acceptance manifest not yet present.'}
p=D/'result.json';p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');p.chmod(0o444);print(json.dumps({'status':record['status'],'files':len(rows),'sha256':H(p.read_bytes())}))
