from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
B=Path(__file__).resolve().parent
suite=sys.argv[1]
assert suite in ('independent','candidate','history')
selected=[B/'independent-e2e07.test.ts'] if suite=='independent' else [B/'replica/tests/integration'/('postgres-h6-007-history.test.ts' if suite=='history' else 'postgres-h6-007.test.ts')]
assert all(p.exists() for p in selected)
stamp=datetime.datetime.now(datetime.timezone.utc).isoformat().replace(':','-')
out=B/'runs'/(suite+'-'+stamp);out.mkdir(parents=True)
sources=out/'sources';sources.mkdir()
records=[]
paths=[B/'run-audit.py',B/'run-isolated-audit.mjs',*selected]
if suite in ('candidate','history'): paths.append(B/'replica/tests/support/h6-007-fixtures.ts')
for p in paths:
    data=p.read_bytes();name=str(p.relative_to(B));dest=sources/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    records.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
inputs=[]
for root in ['src','supabase/migrations','tests/support']:
    for p in sorted((B/'replica'/root).rglob('*')):
        if p.is_file():inputs.append({'path':str(p.relative_to(B/'replica')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(out/'inputs-before.json').write_text(json.dumps({'base':'9c15e6d143822f7fcc84f29744194554630f4ac4','files':inputs,'sources':records},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL']};env['H6007_AUDIT_CAPTURE']=str(out)
args=['node',str(B/'run-isolated-audit.mjs'),*map(str,selected)]
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
    p=subprocess.run(args,cwd=B/'replica',env=env,stdout=stdout,stderr=stderr)
changed=[]
for x in inputs:
    pth=B/'replica'/x['path']
    if not pth.exists() or hashlib.sha256(pth.read_bytes()).hexdigest()!=x['sha256']:changed.append(x['path'])
log=(out/'stdout.log').read_text(errors='replace')
counts={}
for line in log.splitlines():
    if line.startswith('# '):
        bits=line[2:].split()
        if len(bits)==2 and bits[0] in ('tests','suites','pass','fail','cancelled','skipped','todo'):
            try:counts[bits[0]]=int(bits[1])
            except ValueError:pass
r={'suite':suite,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':args,'exitCode':p.returncode,'counts':counts,'unchangedInputs':not changed,'changedInputs':changed,'status':'PASS' if p.returncode==0 and not changed and counts.get('fail')==0 and counts.get('cancelled')==0 and counts.get('skipped')==0 else 'FAIL','stdoutSHA256':hashlib.sha256((out/'stdout.log').read_bytes()).hexdigest(),'stderrSHA256':hashlib.sha256((out/'stderr.log').read_bytes()).hexdigest(),'sources':records,'newIndependentCounterexamples':suite=='independent','sameModelSeparateAgent':True}
(out/'result.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'directory':str(out),**{k:v for k,v in r.items() if k!='sources'}},indent=2))
sys.exit(0 if r['status']=='PASS' else 1)
