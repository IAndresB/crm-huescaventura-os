from pathlib import Path
import datetime,hashlib,json,os,shutil,stat
B=Path(__file__).resolve().parent
D=B/'delivery';assert not D.exists();D.mkdir()
excluded={'replica','rt','delivery'}
files=[]
for top in sorted(B.iterdir()):
 if top.name in excluded:continue
 if top.is_file():files.append(top)
 elif top.is_dir():files.extend(sorted(p for p in top.rglob('*') if p.is_file()))
assert not any(p.is_symlink() for p in files)
rows=[]
for p in files:
 rel=p.relative_to(B);q=D/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q);q.chmod(0o444);raw=q.read_bytes();assert raw==p.read_bytes()
 rows.append({'path':str(rel),'bytes':len(raw),'mode':'0444','sha256':hashlib.sha256(raw).hexdigest()})
manifest={'schema':'h6-007-independent-selective-delivery-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task':'TSK-H6-007','base':'9c15e6d143822f7fcc84f29744194554630f4ac4','status':'PASS_TECHNICAL_LOCAL_ISOLATED','payloadCount':len(rows),'payloadBytes':sum(x['bytes'] for x in rows),'exclusions':['replica root','node_modules','rt','PostgreSQL data/config/sockets','software cache','real credentials','other sealed packages'],'files':rows}
p=D/'delivery-manifest-v1.json';p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');p.chmod(0o444)
seal={'schema':'h6-007-independent-selective-seal-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest':'delivery-manifest-v1.json','manifestSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'manifestBytes':p.stat().st_size,'manifestMode':'0444','payloadCount':len(rows),'payloadBytes':manifest['payloadBytes'],'selfExcluded':True,'integrityOnly':'SHA-256 identity, not a director signature; final acceptance custody is a separate later operation'}
s=D/'delivery-seal-v1.json';s.write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n');s.chmod(0o444)
for x in rows:
 q=D/x['path'];assert hashlib.sha256(q.read_bytes()).hexdigest()==x['sha256'] and q.stat().st_size==x['bytes'] and stat.S_IMODE(q.stat().st_mode)==int(x['mode'],8)
actual={str(p.relative_to(D)) for p in D.rglob('*') if p.is_file()};assert actual=={x['path'] for x in rows}|{'delivery-manifest-v1.json','delivery-seal-v1.json'}
for d in sorted([p for p in D.rglob('*') if p.is_dir()],reverse=True):d.chmod(0o555)
D.chmod(0o555)
print(json.dumps({'path':str(D),'status':'PASS','payloadCount':len(rows),'payloadBytes':manifest['payloadBytes'],'manifestSHA256':seal['manifestSHA256'],'sealSHA256':hashlib.sha256(s.read_bytes()).hexdigest()},indent=2))
