from pathlib import Path
import datetime,hashlib,json
B=Path(__file__).resolve().parent
old=B/'source-and-evidence-verification-v1.json';prior=json.loads(old.read_text())
expected={'focal-02':(17,15),'focal-03':(31,1),'focal-04':(32,0),'regression-01':(46,3),'regression-02':(49,0)}
checks=[x for x in prior['checks'] if not x['name'].endswith('-exact-case-counts')]
runs=[];superseded=[]
for item in prior['runs']:
 unique={};diagnostics=[]
 for case in item['cases']:
  if case['title'] not in unique:unique[case['title']]={**case,'diagnosticRepeatLines':[]}
  else:
   first=unique[case['title']];assert first['result']==case['result']=='FAIL'
   first['diagnosticRepeatLines'].append(case['line']);diagnostics.append(case)
 rows=list(unique.values());passed=sum(x['result']=='PASS' for x in rows);failed=sum(x['result']=='FAIL' for x in rows)
 checks.append({'name':item['run']+'-exact-case-counts','status':'PASS' if (passed,failed)==expected[item['run']] else 'FAIL','details':{'pass':passed,'fail':failed,'expected':expected[item['run']],'additionalFailureDiagnosticLines':len(diagnostics),'rule':'first unique complete test title is execution result; repeated failing title in final diagnostic is retained separately'}})
 runs.append({**item,'cases':rows,'pass':passed,'fail':failed,'duplicateFailureDiagnosticLines':diagnostics})
 if diagnostics:superseded.append(item['run'])
report={**prior,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'priorReportSHA256':hashlib.sha256(old.read_bytes()).hexdigest(),'correction':'Node spec reporter repeats each FAIL title in final diagnostics. Count exact unique test titles once; retain both locations. No test result altered.','supersededInstrumentCounts':superseded,'checks':checks,'runs':runs,'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL'}
p=B/'source-and-evidence-verification-v2.json';p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':report['status'],'checks':len(checks),'runCounts':{x['run']:{'pass':x['pass'],'fail':x['fail']} for x in runs},'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2))
