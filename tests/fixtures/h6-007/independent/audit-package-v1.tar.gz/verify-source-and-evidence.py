from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess
B=Path(__file__).resolve().parent
R=Path('/Users/andres/.codex/worktrees/h6-007-local/crm-huescaventura-os')
A=R.parent/'receipts'
OUT=B/'author-evidence-frozen-v1'
OUT.mkdir(exist_ok=False)
H=lambda x:hashlib.sha256(x).hexdigest()
checks=[]
def check(name,ok,details): checks.append({'name':name,'status':'PASS' if ok else 'FAIL','details':details})
pre=json.loads((B/'preflight-sources-v1.json').read_text())
for key in ['normativeSources','baselineInputs']:
 rows=[]
 for x in pre[key]:
  p=R/x['path']; raw=p.read_bytes();rows.append({'path':x['path'],'same':H(raw)==x['sha256'],'sha256':H(raw)})
 check(key,all(x['same'] for x in rows),rows)
candidate=json.loads((B/'candidate-final-frozen-v1/identity.json').read_text())['files']
check('candidate-nine-files',all(H((R/x['path']).read_bytes())==x['sha256'] for x in candidate),candidate)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
index=subprocess.check_output(['git','write-tree'],cwd=R,text=True).strip()
# write-tree only derives object identity from existing index; no refs, index entries or commit mutation.
changes=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R,text=True).splitlines()
check('base-and-index',head==pre['base'] and index==pre['tree'],{'head':head,'indexTree':index,'trackedChanges':changes})
check('published-tracked-bytes-no-diff',not changes,{'trackedChanges':changes,'scope':'Git tracked product, prior protected packages and norms; complete final custody belongs to later receipt'})
records=[]
for folder in ['focal-01','focal-02','focal-03','focal-04','regression-01','regression-02','quality-02-quality','source-snapshots']:
 root=A/folder
 for p in sorted(root.rglob('*')):
  if not p.is_file() or 'observations' in p.parts:continue
  rel=p.relative_to(A);dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);raw=p.read_bytes();dest.write_bytes(raw);dest.chmod(0o444)
  records.append({'path':str(rel),'bytes':len(raw),'sha256':H(raw)})
for name in ['candidate-test-inputs-v1.json','focal-02-analysis.json','focal-03-analysis.json','focal-03-lock-inspection-v2.csv','focal-03-monitor-recovery.csv','regression-01-analysis.json','run-integration-v1.py','run-integration.py','run-quality.py']:
 p=A/name;raw=p.read_bytes();(OUT/name).write_bytes(raw);(OUT/name).chmod(0o444);records.append({'path':name,'bytes':len(raw),'sha256':H(raw)})
allruns=[]
for run,counts in [('focal-02',(17,15)),('focal-03',(31,1)),('focal-04',(32,0)),('regression-01',(46,3)),('regression-02',(49,0))]:
 rr=OUT/run; result=json.loads((rr/'result.json').read_text());raw=(rr/'stdout.log').read_bytes();errors=(rr/'stderr.log').read_bytes(); rows=[]
 for n,line in enumerate(raw.decode().splitlines(),1):
  m=re.match(r'([✔✖]) (.*?) \([\d.]+ms\)$',line)
  if m: rows.append({'title':m[2],'result':'PASS' if m[1]=='✔' else 'FAIL','line':n})
 passed=sum(x['result']=='PASS' for x in rows);failed=sum(x['result']=='FAIL' for x in rows)
 check(run+'-hashes',H(raw)==result['stdoutSHA256'] and H(errors)==result['stderrSHA256'],{'stdoutSHA256':H(raw),'stderrSHA256':H(errors)})
 check(run+'-exact-case-counts',(passed,failed)==counts,{'pass':passed,'fail':failed,'expected':counts})
 inputs=json.loads((rr/'inputs.json').read_text()); final=run in ['focal-04','regression-02']; mismatches=[]
 if final:
  for x in inputs:
   p=R/x['path']
   if not p.exists() or H(p.read_bytes())!=x['sha256']:mismatches.append(x['path'])
  check(run+'-inputs-identity',not mismatches,{'count':len(inputs),'mismatches':mismatches})
 allruns.append({'run':run,'stdoutSHA256':H(raw),'cases':rows,'pass':passed,'fail':failed,'inputsSHA256':H((rr/'inputs.json').read_bytes())})
# Some Node reporters print a failing title twice: once in suite output and once in failure diagnostics.
# Keep each observed line. Any count mismatch remains FAIL and requires an explicit successor instrument.
quality=json.loads((OUT/'quality-02-quality/result.json').read_text())
for step in quality['results']:
 name=step['command'][1];raw=(OUT/'quality-02-quality'/(name+'.stdout.log')).read_bytes();err=(OUT/'quality-02-quality'/(name+'.stderr.log')).read_bytes()
 check('quality-'+name,step['exitCode']==0 and H(raw)==step['stdoutSHA256'] and H(err)==step['stderrSHA256'],{'command':step['command'],'stdoutSHA256':H(raw),'stderrSHA256':H(err)})
report={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':pre['base'],'checks':checks,'runs':allruns,'source':'independent read of author raw sources and results, not a new execution of 49 regressions or quality','status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL'}
(B/'source-and-evidence-verification-v1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'manifest.json').write_text(json.dumps({'files':records},indent=2)+'\n');(OUT/'manifest.json').chmod(0o444)
print(json.dumps({'status':report['status'],'checks':len(checks),'failures':[x for x in checks if x['status']=='FAIL'],'copiedFiles':len(records)},ensure_ascii=False,indent=2))
