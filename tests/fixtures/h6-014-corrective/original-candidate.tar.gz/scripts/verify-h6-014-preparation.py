#!/usr/bin/env python3
"""H6-014: read-only validation; optional append-only history in one new report.

No database, Storage, network, package installation or application imports.
P/N identifiers are preparation checks, never new normative requirements.
"""
import argparse
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
DOC = "specs/001-core-crm/"
FIX = "tests/fixtures/h6-014/"
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def read_json(path):
    return json.loads((ROOT / path).read_bytes())


def git(*args):
    # Callers use only literal, read-only Git subcommands below; no shell.
    return subprocess.check_output(["git", *args], cwd=ROOT, env=ENV).decode().strip()


def safe_path(value):
    if not isinstance(value, str) or not value or "\\" in value:
        return False
    p = Path(value)
    return not p.is_absolute() and ".." not in p.parts and (ROOT / p).resolve().is_relative_to(ROOT)


def protected(paths):
    accumulator = hashlib.sha256()
    total = 0
    for name in sorted(paths):
        path = ROOT / name
        data = path.read_bytes()
        mode = oct(stat.S_IMODE(path.stat().st_mode))
        total += len(data)
        row = [name, mode, len(data), digest(data)]
        accumulator.update(json.dumps(row, ensure_ascii=False, separators=(",", ":")).encode() + b"\n")
    return {"count": len(paths), "bytes": total, "descriptor_set_sha256": accumulator.hexdigest()}


def secret_errors(text):
    # Reports record rule identifiers only; never echo a matched value.
    patterns = {
        "jwt": r"\beyJ[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\b",
        "private-key": r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        "dsn-password": r"postgres(?:ql)?://[^\s/@:]+:[^\s/@]+@",
        "bearer": r"(?i)\bBearer\s+[A-Za-z0-9_.-]{24,}",
        "temporary-url": r"(?i)https?://[^\s<>\"']+[?&](?:token|signature|sig|x-amz-signature|access_token)=",
        "serialized-secret": r'(?i)"(?:secret|password|private_key|service_role_key)"\s*:\s*"[A-Za-z0-9_+/=-]{24,}"',
    }
    return ["SECRET:" + name for name, pattern in patterns.items() if re.search(pattern, text)]


def procedure_control(text):
    found = re.search(r"```json\n(.*?)\n```", text, re.S)
    if not found:
        raise ValueError("PROCEDURE_CONTROL_ABSENT")
    return json.loads(found.group(1))


def document_checks(text, outputs):
    errors = []
    parsed_blocks = 0
    checked_links = 0
    checked_imports = 0
    for target in re.findall(r"\[[^\]]+\]\(([^)]+)\)", text):
        url = urlsplit(target)
        if url.scheme in {"https", "http"}:
            continue
        destination = (ROOT / DOC / unquote(url.path)).resolve()
        if not destination.is_relative_to(ROOT):
            errors.append("REFERENCES")
            continue
        name = str(destination.relative_to(ROOT))
        if not destination.is_file():
            if name not in outputs:  # The evidence report is written after results.
                errors.append("REFERENCES")
            continue
        checked_links += 1
        if url.fragment and destination.suffix == ".md":
            content = destination.read_text()
            anchors = set(re.findall(r'<a id="([^"]+)"', content))
            for heading in re.findall(r"^#+\s+(.*)$", content, re.M):
                anchors.add(re.sub(r"[^\w\- ]", "", heading.lower()).replace(" ", "-"))
            if unquote(url.fragment) not in anchors:
                errors.append("REFERENCES")
    for block in re.findall(r"```sh\n(.*?)\n```", text, re.S):
        result = subprocess.run(["/bin/bash", "--noprofile", "--norc", "-n"], input=block,
                                text=True, capture_output=True,
                                env={"PATH": "/usr/bin:/bin", "BASH_ENV": "/dev/null"})
        parsed_blocks += 1
        if result.returncode:
            errors.append("PROCEDURE_CONCRETENESS")
    for names, target in re.findall(r"import \{([^}]+)\} from ['\"]([^'\"]+)['\"]", text):
        destination = (ROOT / DOC / target).resolve()
        if not destination.is_relative_to(ROOT) or not destination.is_file():
            errors.append("REFERENCES")
            continue
        content = destination.read_text()
        for name in names.split(","):
            if not re.search(r"export (?:async )?(?:function|class|const|type|interface) " + re.escape(name.strip()) + r"\b", content):
                errors.append("PROCEDURE_CONCRETENESS")
            checked_imports += 1
    return {"errors": sorted(set(errors)), "shell_blocks_parsed_not_executed": parsed_blocks,
            "relative_links_checked": checked_links, "existing_exports_checked": checked_imports}


def descriptor_errors(data, descriptor):
    return [] if descriptor.get("sha256") == digest(data) and descriptor.get("bytes") == len(data) else ["MANIFEST"]


def validate(e, inv, control, matrix, sources, expected_bytes, seal, procedure_text):
    errors = []

    def require(condition, code):
        if not condition:
            errors.append(code)

    require(digest(expected_bytes) == seal["sha256"], "EXPECTED_SEAL")
    require(e["base_commit"] == "07808f7d441452a8a2f251306824de3f8520b490", "SOURCE_IDENTITY")
    for record in e["sources"].values():
        data = sources.get(record["path"], b"")
        excerpt = "\n".join(data.decode().splitlines()[record["start"] - 1:record["end"]]) + "\n"
        require(digest(data) == record["file_sha256"] and digest(excerpt.encode()) == record["excerpt_sha256"], "SOURCE_IDENTITY")
    rows = inv.get("resources", [])
    ids = [row.get("id") for row in rows]
    require(len(ids) == len(set(ids)) and set(ids) == set(e["resources"]), "INVENTORY_COVERAGE")
    for row in rows:
        require(all(row.get(key) for key in e["required_inventory_fields"]), "INVENTORY_FIELDS")
        require(row.get("name") == e["resources"].get(row.get("id")), "INVENTORY_COVERAGE")
        require(row.get("availability") in e["availability_labels"], "AVAILABILITY")
        for asset in row.get("assets", []):
            require(asset.get("availability") in e["availability_labels"] and bool(asset.get("evidence")) and bool(asset.get("limitation")), "AVAILABILITY")
            # No new operational backup is accredited by this preparation.
            if row.get("id") in {"R01", "R03", "R07", "R13"}:
                require(not (asset.get("kind") == "operational-backup" and asset.get("availability") == "DISPONIBLE Y ACREDITADO"), "AVAILABILITY")
        require(set(row.get("procedure_steps", [])) <= set(e["steps"]), "PROCEDURE_ORDER")
        require(set(row.get("dependencies", [])) <= set(e["resources"]), "REFERENCES")
        for reference in row.get("references", []):
            path = reference.get("path")
            if not safe_path(path):
                errors.append("REFERENCES")
                continue
            file = ROOT / path
            require(file.is_file(), "REFERENCES")
            if file.is_file():
                data = file.read_bytes()
                require(digest(data) == reference.get("sha256"), "REFERENCES")
                require(isinstance(reference.get("line"), int) and 0 < reference["line"] <= len(data.splitlines()), "REFERENCES")

    steps = control.get("steps", [])
    require([s.get("id") for s in steps] == e["steps"], "PROCEDURE_ORDER")
    require([s.get("establishes") for s in steps] == e["required_gates"], "PROCEDURE_ORDER")
    established = set()
    for step in steps:
        require(set(step.get("requires", [])) <= established, "PROCEDURE_ORDER")
        require(set(step.get("resources", [])) <= set(e["resources"]), "REFERENCES")
        require(step.get("executed") is False, "SCOPE")
        established.add(step.get("establishes"))
        match = re.search(r"^## " + re.escape(step.get("id", "")) + r" — (.*?)(?=^## |\Z)", procedure_text, re.M | re.S)
        require(bool(match) and all(word in match.group(0) for word in ["Entrada:", "Salida observable:", "Parada:"]), "PROCEDURE_CONCRETENESS")
    for row in rows:
        require(all(row["id"] in next((s.get("resources", []) for s in steps if s.get("id") == step_id), []) for step_id in row.get("procedure_steps", [])), "PROCEDURE_ORDER")

    q = control.get("quarantine", {})
    require(q.get("sensitive_effects_suspended") is True and q.get("workers_started") is False and q.get("automatic_resume") is False, "QUARANTINE")
    cut = control.get("source_cut", {})
    require(all(cut.get(k) is True for k in ["all_writers_frozen", "multi_database_cut", "objects_separate", "witness_outside_restore"]), "SOURCE_CUT")
    require(all(control.get("protected_copy", {}).get(k) is True for k in ["raw_backup_is_sensitive", "omit_role_passwords", "preserve_owner_acl", "separate_protected_escrow"]), "PROTECTED_COPY")
    session = control.get("sessions", {})
    require(session.get("global_revocation_contract") == "H0013GlobalAccessRevocationAdapter.revokeAll" and all(session.get(k) is True for k in ["fresh_identification", "require_completed_and_auth_revoked", "deny_old_read_mutation_replay_objects", "disabled_actor_stays_disabled", "failure_keeps_quarantine"]), "SESSION_SAFETY")
    require(all(control.get("objects", {}).get(k) is True for k in ["recover_separately", "check_digest_size_media", "missing_is_not_recovered", "reauthorize_download"]), "OBJECT_SAFETY")
    ext = control.get("external", {})
    require(ext.get("automatic_resume") is False and all(ext.get(k) is True for k in ["provider_outside_rollback", "uncertain_keeps_reservation", "retry_requires_verified_prior_effect", "incomplete_source_does_not_prove_no_effect", "historical_approval_does_not_reapprove"]), "EXTERNAL_SAFETY")
    measure = control.get("measurement", {})
    require(bool(measure.get("loss_method")) and bool(measure.get("duration_method")) and all(measure.get(k) is None for k in ["rpo_target", "rto_target", "production_frequency", "production_cost", "live_measurements"]), "MEASUREMENT")
    for payload in [inv, control]:
        require(payload.get("claims") == e["forbidden_credit"], "SCOPE")
        require(payload.get("pending", {}).get("ARCH-PENDING-002") == "OPEN/PENDING" and payload.get("pending", {}).get("DM-PENDING-005") == "OPEN", "PENDING")
    require(control.get("prepared_only") is True and control.get("controls_are_required_future_conditions_not_observed_execution") is True, "SCOPE")
    require(inv.get("responsible_human") == "Andrés" and inv.get("technical_executor") == "ChatGPT Work", "INVENTORY_FIELDS")

    expected_ids = [a["id"] for a in e["assignments"]]
    mrows = matrix.get("rows", [])
    require(len(mrows) == 6 and [r.get("requirement") for r in mrows] == expected_ids, "NORMATIVE_MATRIX")
    check_ids = {c["id"] for c in e["positive_checks"]}
    for row, assignment in zip(mrows, e["assignments"]):
        require(row.get("task_assignment") == assignment, "NORMATIVE_MATRIX")
        require(set(row.get("source_ids", [])) <= set(e["sources"]), "NORMATIVE_MATRIX")
        require(bool(row.get("source_ids")) and bool(row.get("preparation_expected")) and bool(row.get("future_verification")), "NORMATIVE_MATRIX")
        require(set(row.get("resources", [])) <= set(e["resources"]) and set(row.get("procedure_steps", [])) <= set(e["steps"]) and set(row.get("local_checks", [])) <= check_ids, "NORMATIVE_MATRIX")
        require(row.get("global_requirement_satisfied") is False and row.get("integrated_verification_state") == "NO EJECUTADA", "SCOPE")
        require(assignment["literal"] in sources[assignment["path"]].decode().splitlines(), "SOURCE_IDENTITY")
    for payload in [inv, control, matrix]:
        errors.extend(x.split(":")[0] for x in secret_errors(json.dumps(payload, ensure_ascii=False)))
    return sorted(set(errors))


def counterexamples(e, inv, control, matrix, sources, expected_bytes, seal, text):
    observations = []
    for case in e["negative_cases"]:
        i, c, m, s, b = copy.deepcopy(inv), copy.deepcopy(control), copy.deepcopy(matrix), dict(sources), expected_bytes
        name = case["mutation"]
        if name == "omit-resource":
            i["resources"] = [r for r in i["resources"] if r["id"] != "R05"]
        elif name == "duplicate-resource":
            i["resources"].append(copy.deepcopy(i["resources"][0]))
        elif name == "unknown-availability":
            i["resources"][0]["availability"] = "ASSUMED"
        elif name == "unproved-backup":
            i["resources"][0]["assets"].append({"kind": "operational-backup", "availability": "DISPONIBLE Y ACREDITADO", "evidence": "not-observed", "limitation": "counterexample"})
        elif name == "missing-revocation-gate":
            c["sessions"]["require_completed_and_auth_revoked"] = False
        elif name == "automatic-resume":
            c["external"]["automatic_resume"] = True
        elif name == "lost-uncertainty":
            c["external"]["uncertain_keeps_reservation"] = False
        elif name == "source-tamper":
            path = next(iter(e["sources"].values()))["path"]
            s[path] = s[path] + b"\nchanged\n"
        elif name == "normative-row-tamper":
            m["rows"][0]["task_assignment"]["literal"] += " changed"
        elif name == "path-traversal":
            i["resources"][0]["references"][0]["path"] = "../outside-allowed-root"
        elif name == "integrated-credit":
            c["claims"]["AC-073_global"] = True
        elif name == "invented-rpo":
            c["measurement"]["rpo_target"] = 1
        elif name == "storage-omission":
            c["objects"]["recover_separately"] = False
        elif name == "jwt-material":
            i["resources"][0]["risks"].append("eyJ" + "a" * 25 + "." + "b" * 25 + "." + "c" * 25)
        elif name == "private-key-material":
            i["resources"][0]["risks"].append("-----BEGIN " + "PRIVATE KEY-----")
        elif name == "dsn-password":
            i["resources"][0]["risks"].append("postgresql://" + "synthetic:never-a-real-password@127.0.0.1/test")
        elif name == "expected-tamper":
            b += b"\n"
        elif name == "manifest-tamper":
            observed = descriptor_errors(b"synthetic-nonsecret-payload", {"bytes": 0, "sha256": "0" * 64})
        else:
            raise ValueError("UNKNOWN_COUNTEREXAMPLE")
        if name != "manifest-tamper":
            observed = validate(e, i, c, m, s, b, seal, text)
        observations.append({"id": case["id"], "mutation": name, "expected_error": case["expected_error"], "observed_errors": observed, "result": "PASS" if case["expected_error"] in observed else "FAIL", "in_memory_only": True})
    return observations


def manifest_check(e):
    manifest = read_json(FIX + "manifest.json")
    files = manifest.get("files", {})
    expected_paths = set(e["outputs"]) - {FIX + "manifest.json"}
    errors = []
    if set(files) != expected_paths or manifest.get("base_commit") != e["base_commit"]:
        errors.append("MANIFEST")
    for path, desc in files.items():
        if path not in expected_paths or not safe_path(path):
            errors.append("MANIFEST")
            continue
        file = ROOT / path
        if not file.is_file():
            errors.append("MANIFEST")
            continue
        errors.extend(descriptor_errors(file.read_bytes(), desc))
        if desc.get("mode") != oct(stat.S_IMODE(file.stat().st_mode)):
            errors.append("MANIFEST")
    return {"result": "PASS" if not errors else "FAIL", "files_checked": len(files), "errors": sorted(set(errors)), "manifest_sha256": digest((ROOT / (FIX + "manifest.json")).read_bytes()), "self_excluded": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", action="store_true", help="Append a run to the single controlled H6-014 results.json")
    parser.add_argument("--check-manifest", action="store_true", help="Read-only final integrity check; never rewrite a sealed report")
    args = parser.parse_args()
    if args.output and args.check_manifest:
        parser.error("manifest verification cannot write results")
    expected_bytes = (ROOT / (DOC + "expected-TSK-H6-014.json")).read_bytes()
    e = json.loads(expected_bytes)
    seal = read_json(FIX + "expected-seal.json")
    inv = read_json(DOC + "inventory-TSK-H6-014.json")
    text = (ROOT / (DOC + "procedure-TSK-H6-014.md")).read_text()
    control = procedure_control(text)
    matrix = read_json(DOC + "matrix-TSK-H6-014.json")
    pre = read_json(FIX + "preflight.json")
    sources = {row["path"]: (ROOT / row["path"]).read_bytes() for row in e["sources"].values()}
    errors = validate(e, inv, control, matrix, sources, expected_bytes, seal, text)
    negatives = counterexamples(e, inv, control, matrix, sources, expected_bytes, seal, text)
    document = document_checks(text, e["outputs"])
    errors.extend(document["errors"])

    tracked = [p for p in git("ls-files", "-z").split("\0") if p]
    excluded = read_json("tests/fixtures/h6-013-closure/publication-inventory.json")["excludedAccepted"]
    tracked_now = protected(tracked)
    excluded_now = protected(list(excluded))
    preserve = all(all(now[k] == prior[k] for k in now) for now, prior in [(tracked_now, pre["tracked_protection"]), (excluded_now, pre["historical_excluded_protection"])])
    preserve = preserve and digest((ROOT / ".git/index").read_bytes()) == pre["index_sha256"] and not git("status", "--porcelain=v2", "--untracked-files=no")
    preserve = preserve and git("rev-parse", "HEAD") == e["base_commit"] and git("rev-parse", "HEAD^{tree}") == e["base_tree"]
    others = {p for p in git("ls-files", "--others", "--exclude-standard", "-z").split("\0") if p}
    unexpected_new = others - set(excluded) - set(e["outputs"])
    preserve = preserve and not unexpected_new and set(excluded) <= others
    migrations = read_json("tests/fixtures/h6-013/migrations.json")["migrations"]
    preserve = preserve and len(migrations) == 68 and all(digest((ROOT / row["path"]).read_bytes()) == row["sha256"] for row in migrations)
    if not preserve:
        errors.append("PRESERVATION")
    if digest((ROOT / (FIX + "authorization.txt")).read_bytes()) != e["authority"]["authorization_sha256"]:
        errors.append("EXPECTED_SEAL")
    if not seal.get("before_deliverables") or datetime.datetime.fromisoformat(seal["sealed_utc"]) > datetime.datetime.fromisoformat(pre["checked_utc"]):
        errors.append("EXPECTED_SEAL")
    capabilities = pre.get("tools", {})
    if not all("17.11" in capabilities.get(name, {}).get("version", "") for name in ["postgres", "psql", "pg_dump", "pg_restore", "pg_dumpall"]):
        errors.append("CAPABILITIES")
    for block in re.findall(r"```sh\n(.*?)\n```", text, re.S):
        for command in block.splitlines():
            match = re.search(r'/((?:pg_dumpall|pg_dump|pg_restore|psql|createdb|initdb|pg_ctl))" (.*)', command)
            if match:
                flags = set(re.findall(r"--[a-z][a-z-]*", match.group(2)))
                if not flags <= set(capabilities.get(match.group(1), {}).get("cli_flags", [])):
                    errors.append("CAPABILITIES")
    for path in e["outputs"]:
        file = ROOT / path
        if file.is_file():
            errors.extend(x.split(":")[0] for x in secret_errors(file.read_text()))
    if not all(n["result"] == "PASS" for n in negatives):
        errors.append("COUNTEREXAMPLES")

    # Explicit check-to-error coverage: failures are never presented as 22 PASS.
    codes = {
        "P01": {"SOURCE_IDENTITY"}, "P02": {"INVENTORY_COVERAGE"}, "P03": {"INVENTORY_FIELDS"},
        "P04": {"AVAILABILITY"}, "P05": {"REFERENCES"}, "P06": {"PROCEDURE_ORDER"},
        "P07": {"QUARANTINE"}, "P08": {"SOURCE_CUT"}, "P09": {"PROTECTED_COPY"},
        "P10": {"SESSION_SAFETY"}, "P11": {"OBJECT_SAFETY"}, "P12": {"EXTERNAL_SAFETY"},
        "P13": {"MEASUREMENT"}, "P14": {"NORMATIVE_MATRIX"}, "P15": {"SCOPE"},
        "P16": {"SECRET"}, "P17": {"PRESERVATION"}, "P18": {"EXPECTED_SEAL"},
        "P19": {"CAPABILITIES"}, "P20": {"COUNTEREXAMPLES"}, "P21": {"PROCEDURE_CONCRETENESS"}, "P22": {"PENDING"},
    }
    checks = [{"id": c["id"], "expected": c["expected"], "result": "FAIL" if codes[c["id"]] & set(errors) else "PASS"} for c in e["positive_checks"]]
    report = {
        "schema": "h6-014-verification-v1", "task": "TSK-H6-014", "checked_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "base_commit": git("rev-parse", "HEAD"), "base_tree": git("rev-parse", "HEAD^{tree}"),
        "verifier_sha256": digest(Path(__file__).read_bytes()), "expected_sha256": digest(expected_bytes),
        "positive_checks": checks, "counterexamples": negatives, "errors": sorted(set(errors)),
        "document_checks": document,
        "protected": {"tracked": tracked_now, "historical_excluded": excluded_now, "index_sha256": digest((ROOT / ".git/index").read_bytes()), "unchanged": preserve, "unexpected_new_paths": sorted(unexpected_new), "migrations": len(migrations)},
        "result": "PASS" if not errors else "FAIL", "claims": e["forbidden_credit"],
        "limits": e["limitations"] + ["Estructura, referencias y reglas explícitas; no prueba semántica completa del lenguaje natural ni ejecución de comandos del procedimiento."]
    }
    if args.check_manifest:
        report["manifest"] = manifest_check(e)
        if report["manifest"]["result"] != "PASS":
            report["result"] = "FAIL"
    if args.output:
        path = ROOT / (FIX + "results.json")
        previous = path.read_bytes() if path.is_file() else None
        old = json.loads(previous) if previous else {"schema": "h6-014-run-history-v1", "runs": []}
        if old.get("schema") != "h6-014-run-history-v1":
            raise ValueError("UNEXPECTED_REPORT_FORMAT")
        report["previous_report_sha256"] = digest(previous) if previous else None
        old["runs"].append(report)
        path.write_bytes(encoded(old))
    print(json.dumps({"result": report["result"], "positive": {"pass": sum(c["result"] == "PASS" for c in checks), "total": len(checks)}, "negative": {"pass": sum(c["result"] == "PASS" for c in negatives), "total": len(negatives)}, "errors": report["errors"], "protected_unchanged": preserve, "manifest": report.get("manifest"), "report_written": args.output}, ensure_ascii=False))
    return 0 if report["result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
