# TSK-H6-014 — Procedimiento preparado de restauración aislada

Estado del entregable: PREPARADO PARA REVISIÓN DEL DIRECTOR. Responsable humano: Andrés. Ejecutor de la preparación: ChatGPT Work. Base: `07808f7d441452a8a2f251306824de3f8520b490`.

Este documento contiene instrucciones para una ejecución futura específicamente autorizada. Ningún paso S01–S13 se ha ejecutado como restauración en H6-014. Los controles del bloque JSON son condiciones que deberá cumplir el futuro ensayo, no observados de funcionamiento. R/S/P/N son identificadores instrumentales de este paquete, sin valor de nuevos requisitos normativos.

Fuentes: [Tasks H6-014](tasks.md#tsk-h6-014), [Tasks H6-015](tasks.md#tsk-h6-015), [Plan §11.3](plan.md#113-recuperación), [Architecture §15](../../docs/architecture.md#15-backup-y-recuperación), [AC-073/074](spec.md#244-controles-técnicos-y-fronteras), [P12/P13](../../docs/constitution.md#p12-secretos-fuera-de-git). Asignaciones y hashes exactos: [expected](expected-TSK-H6-014.json). Recursos y capacidades: [inventario](inventory-TSK-H6-014.json). Comprobaciones y evidencia: [matriz](matrix-TSK-H6-014.json) e [informe](evidence-TSK-H6-014.md).

## Controles legibles por el verificador

```json
{
  "task": "TSK-H6-014",
  "prepared_only": true,
  "controls_are_required_future_conditions_not_observed_execution": true,
  "steps": [
    {
      "id": "S01",
      "title": "Autoridad e inputs",
      "resources": [
        "R06",
        "R07",
        "R12",
        "R14",
        "R15"
      ],
      "requires": [],
      "establishes": "authorization",
      "executed": false
    },
    {
      "id": "S02",
      "title": "Cuarentena del destino",
      "resources": [
        "R06",
        "R11"
      ],
      "requires": [
        "authorization"
      ],
      "establishes": "quarantine",
      "executed": false
    },
    {
      "id": "S03",
      "title": "Corte y testigo independiente",
      "resources": [
        "R01",
        "R03",
        "R04",
        "R05",
        "R13"
      ],
      "requires": [
        "quarantine"
      ],
      "establishes": "source_cut",
      "executed": false
    },
    {
      "id": "S04",
      "title": "Copias e integridad",
      "resources": [
        "R01",
        "R02",
        "R03",
        "R07",
        "R12",
        "R13",
        "R14",
        "R15"
      ],
      "requires": [
        "source_cut"
      ],
      "establishes": "copy_integrity",
      "executed": false
    },
    {
      "id": "S05",
      "title": "Restauración de roles y bases",
      "resources": [
        "R01",
        "R02",
        "R08",
        "R09",
        "R10",
        "R11",
        "R12",
        "R15"
      ],
      "requires": [
        "copy_integrity"
      ],
      "establishes": "privileges",
      "executed": false
    },
    {
      "id": "S06",
      "title": "Configuración y secretos",
      "resources": [
        "R04",
        "R06",
        "R07"
      ],
      "requires": [
        "privileges"
      ],
      "establishes": "protected_secrets",
      "executed": false
    },
    {
      "id": "S07",
      "title": "Identificación y revocación",
      "resources": [
        "R04",
        "R05",
        "R07",
        "R13"
      ],
      "requires": [
        "protected_secrets"
      ],
      "establishes": "revoked_sessions_denied",
      "executed": false
    },
    {
      "id": "S08",
      "title": "Objetos y metadata",
      "resources": [
        "R03",
        "R08"
      ],
      "requires": [
        "revoked_sessions_denied"
      ],
      "establishes": "objects_coherent",
      "executed": false
    },
    {
      "id": "S09",
      "title": "Integridad y permisos",
      "resources": [
        "R01",
        "R02",
        "R03",
        "R05",
        "R08",
        "R09",
        "R10",
        "R11",
        "R12"
      ],
      "requires": [
        "objects_coherent"
      ],
      "establishes": "data_coherent",
      "executed": false
    },
    {
      "id": "S10",
      "title": "Conciliación de efectos",
      "resources": [
        "R03",
        "R09",
        "R10",
        "R11",
        "R13"
      ],
      "requires": [
        "data_coherent"
      ],
      "establishes": "external_reconciled",
      "executed": false
    },
    {
      "id": "S11",
      "title": "Decisión de reentrada",
      "resources": [
        "R04",
        "R05",
        "R06",
        "R09",
        "R10",
        "R11"
      ],
      "requires": [
        "external_reconciled"
      ],
      "establishes": "explicit_reentry",
      "executed": false
    },
    {
      "id": "S12",
      "title": "Medición observada",
      "resources": [
        "R13"
      ],
      "requires": [
        "explicit_reentry"
      ],
      "establishes": "observed_measurement",
      "executed": false
    },
    {
      "id": "S13",
      "title": "Evidencia y STOP",
      "resources": [
        "R14",
        "R15"
      ],
      "requires": [
        "observed_measurement"
      ],
      "establishes": "evidence_stop",
      "executed": false
    }
  ],
  "quarantine": {
    "sensitive_effects_suspended": true,
    "workers_started": false,
    "automatic_resume": false,
    "isolation": "unix-socket-only Core; Storage loopback y sin conectores; mismos datos/secretos solo del ensayo"
  },
  "source_cut": {
    "all_writers_frozen": true,
    "multi_database_cut": true,
    "objects_separate": true,
    "witness_outside_restore": true
  },
  "protected_copy": {
    "raw_backup_is_sensitive": true,
    "omit_role_passwords": true,
    "preserve_owner_acl": true,
    "separate_protected_escrow": true
  },
  "sessions": {
    "fresh_identification": true,
    "global_revocation_contract": "H0013GlobalAccessRevocationAdapter.revokeAll",
    "require_completed_and_auth_revoked": true,
    "deny_old_read_mutation_replay_objects": true,
    "disabled_actor_stays_disabled": true,
    "failure_keeps_quarantine": true
  },
  "objects": {
    "recover_separately": true,
    "check_digest_size_media": true,
    "missing_is_not_recovered": true,
    "reauthorize_download": true
  },
  "external": {
    "provider_outside_rollback": true,
    "uncertain_keeps_reservation": true,
    "retry_requires_verified_prior_effect": true,
    "incomplete_source_does_not_prove_no_effect": true,
    "historical_approval_does_not_reapprove": true,
    "automatic_resume": false
  },
  "measurement": {
    "loss_method": "Diferencia de hechos/IDs entre corte coherente, testigo posterior completo y destino; importes por moneda sin doble conteo; desconocido si cobertura insuficiente.",
    "duration_method": "Reloj monotónico inicio/fin por fase y total, con UTC de corte/observación; no incluir pausas sin declararlas.",
    "rpo_target": null,
    "rto_target": null,
    "production_frequency": null,
    "production_cost": null,
    "live_measurements": null
  },
  "claims": {
    "integrated_restore": false,
    "AC-073_global": false,
    "hosted": false,
    "production": false,
    "task_closed": false,
    "independent_audit": false
  },
  "pending": {
    "ARCH-PENDING-002": "OPEN/PENDING",
    "DM-PENDING-005": "OPEN"
  }
}
```

## S01 — Autoridad e inputs

**Entrada:** autorización de H6-015; H5-019, H6-014, H6-006 y H6-008 satisfechas en sus ámbitos; responsable humano y técnico designados; inventario R01–R15 y copias del punto elegido identificadas. H6-006/008 y cierre de H6-014 siguen pendientes al preparar este documento. No avanzar desde este paso por el PASS de la preparación.

El tercero autorizado debe fijar en un recibo nuevo: commit/árbol y 68 migraciones, identidad de origen y destino, versión real de motor/cliente/Storage, dueño del recurso, configuración de red, corte, archivos, hashes, tamaño y referencias protegidas. Leer `tests/fixtures/h6-014/preflight.json` solo acredita herramientas de preparación, no crea ese recibo futuro.

Separar responsabilidades: Andrés autoriza recursos y acepta límites; técnico ejecuta; verificador distinto revisa evidencias cuando su auditoría esté autorizada; el custodio de secretos entrega únicamente el material del ensayo por canal protegido. No trasladar a Git, Drive o contexto IA datos del vault, contraseñas, F1/F2, QR/TOTP, JWT o enlaces temporales. No copiar Production.

**Salida observable:** recibo de inputs completo, no secreto, con todos los recursos y autoridades. **Parada:** falta un input material, dependencia, permiso o copia; mantener pendiente solo la parte dependiente y conservar lo investigado. No inventar endpoints, helpers ni recursos.

## S02 — Cuarentena del destino

**Entrada:** autorización e identidad de destino nuevo, exclusivo y vacío. La restauración de este procedimiento es lógica local, no un restore in-place ni replay sobre una base en uso.

Antes de cargar datos, el destino no tiene UI, listener público, workers, scheduler, handlers de eventos ni conectores con efectos. PostgreSQL debe ser accesible solo mediante socket Unix en directorio privado del ensayo; Storage solo loopback y sin egress hacia proveedores. El usuario local del cluster y su directorio deben ser exclusivos del ensayo. La infraestructura de ensayo debe aportar evidencia de esa configuración; una etiqueta `development` no basta. No se cambia la política de seguridad del producto para conseguir aislamiento.

Durante captura/restauración de payload sensible, tanto el origen exclusivo como el destino deben impedir logs de valores: servidor sin persistencia de stdout/stderr de datos, ningún echo SQL/parámetro/cuerpo, cliente sin xtrace ni captura cruda. El harness conserva únicamente fase, tiempos, exit code y comprobaciones redactadas. Si no se garantiza esa configuración, parar antes de manejar claves. El logfile de arranque del destino del ejemplo es /dev/null; la evidencia de proceso la genera el harness sin texto SQL ni errores crudos. No asumir que un log privado permite incluir secretos.

La suspensión preventiva es de procesos/red/canales del ensayo, no se presume un interruptor global CRM inexistente. `pause/stop` de B08 son controles por trabajo; no sustituyen la cuarentena. No se arrancan ejecutores de negocio para validar un restore. Los adaptadores se invocan únicamente desde el harness local autorizado y con destinatarios simulados.

**Salida observable:** conexiones y procesos inventariados; canal sensible suspendido; endpoints ajenos inaccesibles según prueba futura. **Parada:** destino compartido, conexión externa no autorizada o imposibilidad de mantener la suspensión. No liberar la cuarentena por timeout o por restauración exitosa del archivo.

## S03 — Corte y testigo independiente

**Entrada:** origen exclusivamente sintético, fuentes disponibles y cuarentena activa. El operador detiene todos los escritores del origen: Core, puertos Auth de prueba, Storage y dobles que formen parte del corte, sin borrar estados.

Fijar `t0` como corte coherente. La base Core y el Storage local pueden tener PostgreSQL distintos, tal como muestra `scripts/test-postgres.mjs`; no existe una transacción única que haga atómicos ambos motores y sus bytes. Mantener escritores detenidos mientras se capturan todas las bases, sus objetos y configuración. Registrar inicio/fin UTC y reloj monotónico del corte, sin presentar un intervalo de captura como instante exacto si no lo es. Si no puede congelarse todo, rediseñar el ensayo autorizado o documentar la inconsistencia y parar el restore.

Construir antes del rollback un testigo independiente `t1` fuera del destino restaurado. Debe conservar IDs de sesiones y revocaciones posteriores a t0, subject/actor/generación sin tokens, e identidad de efecto, operación, intento, destinatario simulado, versión, importe/moneda cuando corresponda, momentos y evidencia de pago/envío ejecutado o incierto. Debe indicar cobertura, fuente, versión y completitud; un registro vacío incompleto no acredita que no ocurrió un efecto.

El doble externo conserva su estado t1 mientras Core se restaura a t0. No restaurar ambos a t0. El testigo es material sintético protegido, con hash y copia separada. Los fixtures históricos W41 orientan el caso pero no son un nuevo testigo temporal ni un restore real.

**Salida observable:** identidad de corte coherente y testigo fuera del rollback. **Parada:** corte inconsistente, testigo perdido o sin cobertura suficiente; desconocido sigue desconocido.

## S04 — Copias e integridad

**Entrada:** corte con escritores detenidos y directorio protegido nuevo del ensayo fuera del repositorio y fuera de carpetas de evidencia compartida. Modo privado y control de acceso son necesarios; no equivalen por sí solos a cifrado o disponibilidad futura.

Los nombres `H6015_*` de los bloques siguientes son parámetros del futuro ensayo: se rellenan desde el recibo S01, no son configuración existente. `H6015_BIN` se comprueba contra Postgres.app 17.11 y versión del origen. `H6015_SOURCE_SOCKET/PORT/BOOTSTRAP` identifican el cluster exclusivo; los parámetros de destino deben ser distintos. No contienen contraseñas. Para herramientas que las requieran, el custodio prepara un mecanismo libpq protegido; nunca un DSN con contraseña en argumentos, documentos o logs.

Los bloques son Bash con parada ante el primer error y salidas crudas descartadas. El harness autorizado registra solo fase/exit code/tiempo; no activa xtrace ni almacena stderr SQL. No continuar manualmente después de un código no cero.

**Bloque de captura futuro, no ejecutado en H6-014:**

```sh
set +x
set -euo pipefail
umask 077
: "${H6015_BIN:?ruta PostgreSQL comprobada}"
: "${H6015_PRIVATE_DIR:?directorio privado nuevo}"
: "${H6015_SOURCE_SOCKET:?socket Unix del origen sintético}"
: "${H6015_SOURCE_PORT:?puerto del origen}"
: "${H6015_SOURCE_BOOTSTRAP:?autoridad de copia autorizada}"
: "${H6015_SOURCE_DB:?base exacta del recibo}"
test ! -e "$H6015_PRIVATE_DIR/roles.sql"
test ! -e "$H6015_PRIVATE_DIR/database.dump"
"$H6015_BIN/pg_dumpall" --host="$H6015_SOURCE_SOCKET" --port="$H6015_SOURCE_PORT" --username="$H6015_SOURCE_BOOTSTRAP" --no-password --roles-only --no-role-passwords --file="$H6015_PRIVATE_DIR/roles.sql" >/dev/null 2>&1
"$H6015_BIN/pg_dump" --host="$H6015_SOURCE_SOCKET" --port="$H6015_SOURCE_PORT" --username="$H6015_SOURCE_BOOTSTRAP" --no-password --dbname="$H6015_SOURCE_DB" --format=custom --no-publications --no-subscriptions --file="$H6015_PRIVATE_DIR/database.dump" >/dev/null 2>&1
```

Repetir la captura de base con archivo distinto por cada base independiente, incluido Storage cuando corresponda. No sobrescribir una captura anterior. Publications/subscriptions quedan fuera del dump para evitar activaciones de red: inventariar previamente sus nombres/definiciones no secretas, declarar ausencia si es real y conservar configuración protegida separada si existen. La reactivación queda prohibida en este procedimiento. No ejecutar SQL que exporte `pg_authid`, secretos ni `subconninfo` hacia evidencia.

El volcado completo incluye `crm_f1.keys.secret` y `crm_f2.keys.secret`. **El archivo entero es sensible** y solo puede residir en custodia protegida del ensayo. `--no-role-passwords` no elimina los secretos de tablas ni toda configuración sensible de roles. `roles.sql` y la configuración también se mantienen protegidos. Los logs nunca guardan valores secretos: las salidas crudas de herramientas se descartan y el harness registra solo metadatos de fase y códigos de salida; no se copian errores de COPY, parámetros o sentencias a evidencias. No listar datos del archivo en consola ni copiar payloads a Git/Drive.

Antes de restaurar, calcular SHA-256 y tamaño de todos los archivos por lectura de bytes, registrar tipo y orden; comparar con el recibo de captura independiente. `pg_restore --list archivo` permite inspeccionar la TOC sin conectar; su salida se revisa dentro del área protegida y solo se exporta una síntesis mínima. El tercero debe comprobar que los schemas CRM, Auth/Storage metadata del origen real, extensiones, constraints, funciones y grants necesarios están incluidos. Un dump schema-only de H6-013 no vale como copia de datos.

Copiar bytes del backend de archivos de Storage, con escritores detenidos, junto con manifest privado de referencias/digest/tamaño/media; no modificar metadatos a mano. El backend de archivo y su metadata propia deben apuntar al mismo corte. Configuración y escrow de claves quedan en archivos protegidos separados, con inventario sin valores. **No se crean estas copias durante H6-014.**

**Salida observable:** manifest privado de copias y testigo, integridad verificada, compatibilidad y cobertura explícitas. **Parada:** cualquier hash, tamaño, formato, versión, corte o cobertura discordantes. No regenerar la copia o el esperado a partir del destino para obtener igualdad.

## S05 — Restauración de roles y bases

**Entrada:** destino nuevo, vacío y en cuarentena, con PostgreSQL compatible, locale/encoding/extensiones documentados y bootstrap del destino distinto de todos los roles del origen capturado. La preparación del cluster corresponde al harness H6-015 autorizado: directorio privado propio, `listen_addresses` vacío y socket exclusivo. Si no existe ese recurso, no apuntar a una base compartida por conveniencia. El bloque de aprovisionamiento que sigue se ejecuta solo en esa fase autorizada, antes del bloque de restauración.

Inspeccionar `roles.sql` en área protegida. Solo contiene roles del origen sintético autorizado; no importar roles de otros proyectos o de un cluster compartido. Crear/restaurar atributos y memberships antes de objetos que los referencian. El bootstrap temporal distinto evita colisión con el rol bootstrap del origen; ninguna colisión se resuelve borrando un rol o ignorando errores. Owners, ACL y FORCE RLS deben conservarse. No usar `--no-owner`, `--no-privileges`, `--clean`, `--disable-triggers`, filtros de tabla o modo de continuar con errores para que el restore pase.

**Aprovisionamiento futuro del cluster exclusivo, no ejecutado en H6-014:**

Elegir directorios nuevos dentro del área privada propia. El recibo exige paths absolutos sin comillas/apóstrofos ni caracteres de control, bootstrap con identificador SQL simple y puerto válido; nombres distintos de cualquier recurso/origen existente. La configuración locale-provider/encoding/collation debe corresponder al origen; si es ICU o builtin, aportar además sus parámetros específicos documentados o parar por incompatibilidad, sin convertirlo silenciosamente a libc. Este bloque solo aplica al origen local libc/C de los fixtures cuando esa compatibilidad se haya comprobado.

```sh
set +x
set -euo pipefail
: "${H6015_DEST_DATA:?directorio de datos nuevo}"
: "${H6015_DEST_SOCKET:?socket nuevo en directorio privado ya creado}"
: "${H6015_DEST_BOOTSTRAP:?rol temporal distinto de todos los roles del origen}"
: "${H6015_DEST_PORT:?puerto identificado en recibo}"
: "${H6015_ENCODING:?encoding comprobado}"
: "${H6015_LC_COLLATE:?collation comprobada}"
: "${H6015_LC_CTYPE:?ctype comprobado}"
test ! -e "$H6015_DEST_DATA"
"$H6015_BIN/initdb" --pgdata="$H6015_DEST_DATA" --username="$H6015_DEST_BOOTSTRAP" --auth=trust --encoding="$H6015_ENCODING" --locale-provider=libc --lc-collate="$H6015_LC_COLLATE" --lc-ctype="$H6015_LC_CTYPE" >/dev/null 2>&1
"$H6015_BIN/pg_ctl" -D "$H6015_DEST_DATA" -l /dev/null -o "-k '$H6015_DEST_SOCKET' -h '' -p $H6015_DEST_PORT" -w start >/dev/null 2>&1
```

El trust local reproduce únicamente el mecanismo del cluster efímero privado de los fixtures: sin listener TCP, directorio socket con acceso exclusivo del usuario del ensayo y ningún servicio de aplicación expuesto. Si esos límites no se acreditan, detener el proceso propio antes de cargar datos; no trasladar esta configuración a otro entorno. Tras terminar el ensayo se detendrá solo este cluster por su identidad y directorio; no borrar sus archivos/logs hasta la autorización de disposición de evidencia.

**Bloque de restauración futuro, no ejecutado en H6-014:**

```sh
set +x
set -euo pipefail
: "${H6015_DEST_SOCKET:?socket Unix del destino exclusivo}"
: "${H6015_DEST_PORT:?puerto del destino}"
: "${H6015_DEST_BOOTSTRAP:?bootstrap temporal exclusivo}"
: "${H6015_DEST_DB:?nombre único de base nueva identificado}"
: "${H6015_DEST_OWNER:?owner original presente en roles.sql}"
"$H6015_BIN/psql" -X --host="$H6015_DEST_SOCKET" --port="$H6015_DEST_PORT" --username="$H6015_DEST_BOOTSTRAP" --no-password --dbname=postgres --set=ON_ERROR_STOP=1 --single-transaction --file="$H6015_PRIVATE_DIR/roles.sql" >/dev/null 2>&1
"$H6015_BIN/createdb" --host="$H6015_DEST_SOCKET" --port="$H6015_DEST_PORT" --username="$H6015_DEST_BOOTSTRAP" --no-password --owner="$H6015_DEST_OWNER" --encoding="$H6015_ENCODING" --locale-provider=libc --lc-collate="$H6015_LC_COLLATE" --lc-ctype="$H6015_LC_CTYPE" --template=template0 "$H6015_DEST_DB" >/dev/null 2>&1
"$H6015_BIN/pg_restore" --host="$H6015_DEST_SOCKET" --port="$H6015_DEST_PORT" --username="$H6015_DEST_BOOTSTRAP" --no-password --dbname="$H6015_DEST_DB" --exit-on-error --single-transaction "$H6015_PRIVATE_DIR/database.dump" >/dev/null 2>&1
```

El comando createdb crea la base después de restaurar los roles, con owner/encoding/locale identificados en S01; no se improvisa un owner diferente ni se ignora la procedencia de esa configuración. Repetir por base Storage en su destino propio. Verificar antes la ausencia de colisiones con roles o extensiones preinstalados; una variante Hosted no se aplica aquí. `pgcrypto` conserva versión y schema; no mover ni reinstalar por conveniencia.

La restauración reproduce definiciones capturadas y ligadas a SQL versionado. No reaplicar las 68 migraciones sobre una base que ya contiene su estructura ni ejecutar DDL correctivo manual. Una diferencia del esquema aprobado exige diagnóstico y autorización/migración correspondiente bajo P13. Tras error, preservar copia/log y descartar para uso el recurso fallido; una nueva tentativa usa destino nuevo, sin limpiar evidencia histórica.

**Salida observable:** código de proceso y transacción satisfactorios en cada base, seguido de verificación de contenido/ACL; no éxito de negocio por `pg_restore` exit 0. **Parada:** conflicto de rol, owner, extensión, constraint o cualquier error. Ninguna reparación por borrado de datos.

## S06 — Configuración y secretos protegidos

**Entrada:** bases restauradas y configuración del mismo corte disponible mediante custodio. Mantener servicios suspendidos.

Recuperar configuración no secreta y versiones de aplicación/lockfile, reglas, automatismos y contratos por separado. Usar runtime y pool TTE privados ya existentes; no otorgar DML/DDL general al rol ordinario. Credenciales de roles, claves F1/F2 y secretos de Storage/Auth son recursos separados: no se deducen del código ni del éxito de un dump. Recuperar material del ensayo por canal protegido y cargarlo en memoria/archivo privado mediante composición del servidor. No usar SELECT a tablas de claves desde runtime; el custodio no exporta valores a contexto IA ni evidencia.

Comprobar keyId/audience/generation/purposes y correspondencia del material con la tabla restaurada, separación F1/F2, login y entorno. Solo registrar resultado de la comprobación e identificadores mínimos; no hashes individuales de secretos como sustituto de custodia ni valores. No rotar claves ni alterar grants para superar una incompatibilidad; un medio ausente bloquea su uso dependiente. Una copia antigua de contraseña de rol o de configuración no acredita la credencial vigente.

Para Storage local, verificar el commit fijado por `scripts/test-postgres.mjs`, configuración `file`, backend restaurado y base/puertos propios. La posterior invocación del servicio se hará con la configuración protegida y loopback del harness; no copiar el ambiente de producción ni activar colas, S3 o conectores no necesarios. El runner completo de integración tiene escrituras y no se usa para comprobar H6-014.

La recuperación del usuario real, email, cuenta propietaria y TOTP/papel se mantiene en D025/D027/D031 y H6-009/010/011. El Auth sintético de este ensayo no acredita esos medios.

**Salida observable:** configuración compatible y comprobación redactada de medios protegidos; ningún servicio sensible habilitado. **Parada:** credencial ausente, configuración ambigua o autoridad insuficiente.

## S07 — Identificación nueva y revocación

**Entrada:** cuarentena activa, actor/subject del origen legítimo, medios protegidos coherentes y Auth de prueba independiente del rollback.

No autorizar ninguna petición con una sesión recuperada. La composición local crea una identificación nueva de control con `verifyAuth` y `H0005PostgresAdapter.establish`, sin `sessionId` previo y con password/MFA comprobadas por el puerto sintético de ensayo. `establish` genera sessionId/epoch nuevos. Con esa autoridad llamar a `H0013GlobalAccessRevocationAdapter.revokeAll`, cuyo contrato incrementa la generación del Core y coordina Auth. Debe resultar `status=completed` y `auth=revoked`; incluye la sesión emisora. Cualquier estado partial/pending/failed/uncertain mantiene la cuarentena.

La forma de composición usa únicamente contratos existentes (fragmento futuro para harness, no ejecutado):

```ts
import {verifyAuth} from '../../src/application/verified-auth.ts';
import {H0005PostgresAdapter} from '../../src/infrastructure/postgres/h0-005-adapter.ts';
import {H0013GlobalAccessRevocationAdapter} from '../../src/infrastructure/postgres/h0-013-adapter.ts';
import {createSyntheticAuthVerifier} from '../../tests/integration/synthetic-auth-fixture.ts';
// Solo harness sintético: runtimeSql, f1/f2, subject y authRevocation se reciben
// de su composición protegida. authRevocation implementa AuthGlobalRevocationPort
// con estado del doble independiente del rollback; no se afirma Auth real.
const synthetic = createSyntheticAuthVerifier();
const access = new H0005PostgresAdapter(runtimeSql, f1, f2);
const revoke = new H0013GlobalAccessRevocationAdapter(runtimeSql, f1, f2, authRevocation);
const identified = await verifyAuth(synthetic.port, synthetic.register({subject, passwordVerified: true, mfaVerified: true}));
const established = await access.establish(identified);
const active = await verifyAuth(synthetic.port, synthetic.register({subject, sessionId: established.sessionId, passwordVerified: true, mfaVerified: true}));
const result = await revoke.revokeAll(active);
if (result.status !== 'completed' || result.auth !== 'revoked') throw new Error('RESTORE_QUARANTINE_REQUIRED');
```

El fragmento usa los exports y firmas existentes; `createSyntheticAuthVerifier.register` produce pruebas exclusivamente sintéticas como los tests H0-014. Los flags password/MFA del fixture no acreditan contraseña/TOTP reales. El puerto de revocación debe conservar y comprobar el estado independiente del doble; un callback que solo devuelve revoked no prueba por sí solo esa revocación. La implementación real de Auth sigue sin acreditarse. No registrar proofs o el objeto auth.

Aplicar el procedimiento al único Administrador habilitado de V1 y enumerar cualquier otro actor presente: un actor deshabilitado o con recuperación incompleta permanece denegado, no se habilita para ejecutar esta operación. Si el contrato no puede obtener autoridad legítima, parar la apertura; no usar UPDATE de generaciones/sesiones como atajo. No basta comparar un contador restaurado contra un máximo supuesto: probar denegación efectiva.

Contrastar todas las sesiones t0 y del testigo t1, incluida la emisora de la revocación: lecturas, mutaciones, resultados previos, proyecciones y objetos pertinentes deben denegar sin filtración. El registro Core y el estado de Auth se comprueban por separado; JWT vigente y URL emitida pueden tener límites técnicos propios. Para acceder a las comprobaciones positivas, hacer una segunda identificación completa nueva, diferente de todas las anteriores, sin revivir epochs ni reutilizar sessionId.

**Salida observable:** revocación coordinada y pruebas negativas por superficie; nuevas operaciones de seguridad se añaden a historia, no reescriben hechos de negocio. **Parada:** cualquier sesión previa admitida, Auth incierto o medio faltante. No abrir UI ni automatismos.

## S08 — Objetos y metadata independientes

**Entrada:** denegación de sesiones previas comprobada y Storage local recuperable identificado.

Recuperar su propia base/metadata y backend de bytes conservando el corte S03. No asumir que el dump Core contiene los objetos o que `storage.objects` del proveedor vive en la misma base del runner. Arrancar solo el servicio Storage aislado imprescindible para las verificaciones de bytes; ningún worker de negocio.

Comparar cada objeto por referencia privada, digest SHA-256, tamaño y media, con versiones y vínculos Core. Usar `PrivateStorage.inventory/get` y `H1015ObjectAdapter.metadata/reconcile/download` con nueva autoridad F2 verificada. `reconcile` es una operación autorizada que registra la observación real y preserva historia; no simula atomicidad externa. La descarga reautoriza antes y después. No publicar signed URLs.

Para el caso AC-073, dejar identificado un objeto que sigue ausente: debe constar missing/incompleto y su descarga debe fallar. La corrupción o media distinta también falla integridad. Un blob sin metadata se conserva como huérfano/revisión sin inventar owner, borrar bytes o afirmar original recuperado. La reparación posterior queda explícita y trazada; una referencia conocida no concede acceso.

**Salida observable:** lista de presentes/ausentes/corruptos/huérfanos y sus vínculos, resultados de acceso y comprobación. **Parada:** diferencia inexplicada o declaración de conservación que contradice los bytes. No ocultar ausencia para pasar el ensayo.

## S09 — Integridad de datos y restricciones

**Entrada:** bases y objetos en estado conocido, sesiones previas denegadas y acceso de prueba nuevo.

Comparar todos los datos canónicos/identidades/relaciones/versiones/snapshots/historia/porciones y resultados del corte. Reutilizar `tests/support/h6-013-preservation.ts` para esquemas CRM con su semántica exacta de tipos, decimal, bigint, SQL NULL, arrays y multiplicidad. No usar IEEE754 Number para normalizar importes o IDs. Para Auth, metadata Storage, globals y configuración construir cobertura explícita adicional en el futuro harness; el filtro `crm%` no los incluye.

Verificar constraints validadas, propietarios, índices, triggers, FORCE RLS, memberships, SECURITY DEFINER, firma y search_path de cada función pertinente. La identidad lógica/definición debe conservarse; OID y binding de backend/xid/postmaster pueden ser distintos en un cluster nuevo y no se comparan como identidad contractual. El rol ordinario no adquiere ownership, BYPASSRLS, DDL ni acceso a claves; migrador/administrador no se usa como actor normal de los casos funcionales.

Separar las diferencias deliberadas posteriores a la restauración (nueva identificación, revocación coordinada, observaciones de objetos y conciliación) del conjunto inmutable del corte. Enumerarlas por operación, autoridad y expected independiente; no aplicar exclusiones genéricas ni igualar la foto eliminando esa historia nueva. Reservas, decisiones y recibos no se liberan por el restore.

**Salida observable:** comparación por recurso y criterios, incluidas denegaciones y permisos legítimos. **Parada:** pérdida o mutación no prevista; ninguna reparación por borrar hechos o debilitar restricciones.

## S10 — Conciliación de efectos posteriores

**Entrada:** integridad conocida y testigo t1 íntegro fuera del rollback; efectos sensibles suspendidos.

Unir por identidad de operación/efecto/parte/intento, no por semejanza de importe o fecha. Para cada pago, envío u otro efecto posterior al corte, consultar la fuente simulada independiente con estado propio. Identificar: ejecutado acreditado, no ejecutado acreditado, incierto o cobertura insuficiente. Conservar destinatario/material/versión y evidencias pertinentes. Un timeout o un registro inexistente en Core restaurado no prueba fracaso externo.

Si la fuente acredita ejecución previa, reutilizar/conciliar su resultado por los contratos existentes, sin iniciar otro efecto. Si sigue incierto, mantener reserva, intento e intervención pendiente; no liberar por caducidad del lease, permiso manual o espera. Solo una ausencia de efecto acreditada, con aprobación exacta vigente e idempotencia segura, permite evaluar un intento posterior en el alcance autorizado. `WorkResultVerifier` y `verifyWorkEffect` niegan priorEffect distinto de none; conservar ese comportamiento.

Las aprobaciones retiradas, caducadas o con contenido cambiado siguen históricas y no reaparecen aplicables por `resume`. La respuesta tardía debe pertenecer a su intento; un ejecutor obsoleto no sobrescribe resultados. Usar las operaciones existentes de `createPersistedWorkExecutor` y la fachada de aprobación humana existente, sin UPDATE de partes, reservas o recibos. Si el intento posterior no existe en Core t0, no fabricar un intento ni una transición aplicada: conservar evidencia/revisión por C04 y mantener el efecto suspendido hasta disponer de una vía legítima. Si una combinación exige contrato nuevo o política no aprobada, detener la parte afectada y solicitar decisión; no escribirlo como capacidad ya disponible.

**Salida observable:** tabla efecto → estado restaurado → fuente t1 → discrepancia → decisión/operación trazada, y contador de contactos/efectos del doble que demuestra ausencia de duplicación. Un objeto ausente permanece pendiente y no altera hechos financieros. **Parada:** identidad ambigua, fuente incompleta o resultado incierto sin protección; mantener bloqueo dependiente y no declarar no-efecto.

## S11 — Decisión de reentrada

**Entrada:** cuarentena, integridad, permisos y revocaciones comprobados; conciliación completa para el efecto cuya continuación se estudie. Un objeto ausente o hecho incierto deja explícito qué parte no puede avanzar. No es necesario inventar una recuperación íntegra para permitir análisis independiente.

El técnico presenta resultados y límites; Andrés debe autorizar expresamente cualquier reentrada del ensayo en el alcance exacto y con las aprobaciones/guardas vigentes. Restaurar datos o pasar los checks no reanuda workers, libera reservas ni concede aprobación humana. La propuesta por defecto mantiene todos los efectos sensibles suspendidos. Si falta una condición, documentar la negativa y continuar únicamente con comprobaciones que no generen esos efectos.

Una eventual continuación solo usa dobles sintéticos dentro del ensayo y contratos actuales. No habilita acceso real, Hosted, Production, emails, pagos, canales ni un scheduler productivo. La aceptación/configuración definitiva de continuidad sigue ARCH-PENDING-002; el tratamiento de datos reales sigue DM-PENDING-005.

**Salida observable:** decisión explícita por alcance, o estado pendiente con cuarentena conservada. **Parada:** ninguna autorización o condición material insuficiente. El paquete H6-014 no contiene una autorización de reentrada.

## S12 — Medición observada

**Entrada:** corte t0, testigo t1 y destino observados con cobertura conocida. No se producen mediciones dinámicas en H6-014.

Medir pérdida por diferencia de conjuntos de hechos/IDs entre punto de corte, testigo posterior completo y destino. Separar hechos posteriores ausentes, presentes y conciliados, versiones, vínculos y efectos externos ya ejecutados. Para importes, sumar exactamente por moneda y porción sin doble conteo. Si la fuente es incompleta, pérdida queda NO DETERMINADA; cero no es el valor por defecto. Medir ventana temporal solo cuando los límites de commit/hecho son comprobables; no asumir que el timestamp de una fila sea orden de commit.

Medir duración con reloj monotónico del harness para cada fase y total, acompañado de UTC de inicio/fin, herramientas, volumen y pausas incluidas/excluidas. Diferenciar tiempo de restauración de base, recuperación de objetos, validación, conciliación y espera humana. No convertir una medición de laboratorio en garantía.

RPO objetivo, RTO objetivo, frecuencia/cadencia y coste de Production permanecen pendientes y sin cifras. La prueba periódica exigida por normativa sigue siendo obligación futura; este documento no fija su frecuencia ni acredita haberla cumplido.

**Salida observable:** mediciones observadas con unidades, método, cobertura y límites, o NO EJECUTADA/NO DETERMINADA según corresponda. **Parada:** dato no reproducible; conservar desconocido sin ajustar el expected.

## S13 — Evidencia y STOP

**Entrada:** observados anteriores identificados y estado de cada comprobación. Registrar en paquete nuevo por tarea: commit/árbol, versiones, recursos, casos, expected previo, observado, resultado, limitaciones y referencias recuperables. Conservar originales FAIL y correctivos en caso de repeticiones; no convertir el último PASS en una ejecución retroactiva.

Los backups, configuración protegida, proofs, tokens y datos sensibles nunca forman parte del paquete de evidencia. Solo descriptores, resultados mínimos y referencias bajo autoridad válida. El manifest de integridad excluye su propio hash y debe poder comprobarse por lectura externa; no prometer WORM ni reloj externo.

Para H6-014, conservar únicamente los once artefactos nuevos del expected: expected, inventario, procedimiento, matriz, informe, verificador, autorización, preflight, sello expected, resultados y manifest. No modificar Tasks/PROJECT-STATUS/NEXT-STEPS para cerrar o maquillar el desfase histórico de publicación. No ejecutar auditoría independiente antes de la revisión del director.

Custodia oficial futura: cuenta info@huescaventura.com, carpeta 02_AUDITORIAS `14xSnNfE7K4hUrMopJaPEab2ccxD_8Rrr`, con subcarpeta propia de tarea. En esta ejecución no se crea carpeta ni se sube ningún archivo. BAILO OS no es repositorio principal de evidencia técnica CRM.

**Salida observable:** candidato local verificable para el director y propuesta de revisión focal. **Parada:** terminar al entregar el candidato. **STOP obligatorio:** sin H6-015, restauración integrada, auditoría independiente, cierre formal, commits, push, despliegue o publicación.

## Límites y comprobaciones de capacidad

Las opciones de CLI de los bloques se contrastaron contra `--help` de los binarios 17.11; no se ejecutaron contra una base. El control puro comprueba estructura y coherencia documental; no demuestra que los comandos/puertos restauren correctamente ni que Auth, Storage o el rollback temporal funcionen. Ese es el ensayo H6-015 con sus dependencias.

Referencias técnicas públicas ya contrastadas en el análisis del 21/10/2026: [Supabase Database Backups](https://supabase.com/docs/guides/platform/backups) y [credenciales tras restauración física](https://supabase.com/changelog/restore-credential-resync). No sustituyen la normativa del commit ni prueban un plan contratado, backups/PITR o configuración Hosted. Este procedimiento elige una recuperación lógica sintética; no generalizarlo a restore físico de PGDATA, PITR o in-place.
