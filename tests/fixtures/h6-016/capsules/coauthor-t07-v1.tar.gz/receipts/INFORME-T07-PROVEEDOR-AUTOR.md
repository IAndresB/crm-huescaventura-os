# H6-016 · Suplemento del autor para PLAN-T07 · Pago a proveedor

PASS 9/9 en el primer pase de los nueve casos del suplemento; TypeScript y límites arquitectónicos PASS. Se añade únicamente `tests/integration/postgres-h6-016-t07-provider.test.ts`, SHA-256 `325b2e974a412442997603219cbf6836cc9fb5c0d7d8be4fbd5ec3cfc53efc81`, 12.952 bytes. No se modifican producto, migraciones, contratos, seguridad o normativa.

La expectativa se congeló antes de construir el ensayo en `expected-v1.json`, SHA-256 `5f57f97608aa9f55e13c47e483902e989535c5ec5d1bc7ab8b76b62535bb05f7`. Tasks, SPEC, Architecture, Plan y State Machines se leyeron directamente y sus identidades están ligadas a esa expectativa. Se preservan cuatro fuentes publicadas de referencia: fixture, adaptador, migración y matriz histórica H3-012. El nuevo archivo usa los fixtures publicados sin modificarlos y el bootstrap full68/TTE actual.

PLAN-T07 incluye Provider Payment, Refund y fianza. Este suplemento cubre el componente Provider Payment y sus porciones, identidad y atomicidad; no afirma que Refund por sí solo complete la fila ni que estos nueve casos acrediten la integración Refund/Deposit. El integrador conserva esos cruces en su matriz independiente.

| Casos | Resultado esperado y observado |
|---|---|
| PP-DUP-AB / PP-DUP-BA | Dos sesiones y conexiones reales, la misma identidad de movimiento y dos identidades de operación. Ambos órdenes muestran bloqueo real; antes no existe movimiento hijo. El primero registra y el segundo recupera el anterior, incluso con revisión anterior. Solo quedan un movimiento, una correspondencia y un consumo de 80 sobre 100; disponibles 20, incremento único de historia de proveedor y Suplido. |
| PP-CONFLICT-AB / PP-CONFLICT-BA | La misma referencia externa con material distinto admite el primero y rechaza exactamente el segundo con `PROVIDER_PAYMENT_MOVEMENT_CONFLICT:E2`. Se preserva el material ganador, con una sola salida y consumo. |
| PP-G-TTE | Programar directamente sin el TTE se rechaza con `PROVIDER_PAYMENT_TTE_REQUIRED`; no acredita pago ni consumo. |
| PP-G-MATERIAL | Sin referencia independiente de correspondencia de salida se rechaza con `PROVIDER_PAYMENT_MOVEMENT_REQUIRED`; se conservan las 14 tablas observadas. |
| PP-G-REVISION | La revisión de fondos obsoleta se rechaza con `PROVIDER_PAYMENT_FUNDS_REVISION_CONFLICT:E2`; exige reevaluación, sin cambios financieros. |
| PP-REAL-NO-RETRO | Un hecho externo íntegramente sintético, documentado por los fixtures, puede registrarse sin aprobación previa como Incidencia/unapproved_real. La aprobación del movimiento permanece null; insertar un campo de aprobación retroactiva se rechaza exactamente. El ensayo no ejecuta ninguna transferencia. |
| PP-ROLLBACK | Un trigger de prueba alcanzado, acreditado por una secuencia, falla al insertar la revisión tardía del proveedor. Movimiento, correspondencia, consumo, resultados, historia y reevaluación de Suplido revierten juntos en las 14 tablas. Repetir la misma identidad después de retirar el fallo registra una única salida de 80. |

Las carreras se solapan sobre la raíz de identidad de movimiento. Dos PIDs distintos con `pg_blocking_pids` y sesiones distintas se observan antes de liberar el lock. Se repiten los órdenes A/B y B/A y se reconsulta la misma identidad después del éxito. Los fixtures generan Booking, servicio externo, obligación, pago recibido, conciliación, asignación, Suplido y aprobación mediante contratos de aplicación. Las filas de Booking y servicios originales se conservan exactamente después de cada caso. No se siembra estado económico mediante SQL.

`run-01/result-v1.json` conserva el comando, las nueve comprobaciones, los hashes de inputs y los logs completos. No hubo FAIL en este suplemento. Los FAIL instrumentales de T08/T09 permanecen en su paquete anterior, que no se reescribe. La comprobación final `final-verification-v1.json` contrasta fuentes, resultados, intercalaciones y custodia. Este autor no ejecutó una nueva batería histórica completa ni atribuye a estos nueve casos un build o suite unitaria completa.

El ensayo utilizó exclusivamente una réplica nueva sin `.git` y un runtime nuevo `/tmp/crm-h6016-t07-author-runtime`. El runner publicado fijó la caché nueva de software Storage en `5def1dfc15ab7f08fe271c7d1e70542424524e4e`; su descarga de software es ajena a datos o efectos de negocio. La base propia se cerró y su directorio temporal fue eliminado por el bootstrap. No se copiaron entornos, bases, procesos, credenciales ni runtimes ajenos. No se heredaron variables H6015.

El paquete excluye réplica, node_modules, caché, datos de PostgreSQL, runtime.env y claves. No hubo escrituras de Git CRM, staging, índices alternos, commit, push, merge, Drive o despliegue. No hubo acceso al runtime de H6-015, S11 ni a los cuatro trabajos suspendidos. No se modificaron fuentes protegidas, la prepublicación H6-007 ni los archivos del integrador.

La entrega queda pendiente de la repetición y dictamen del auditor técnico independiente. Este informe es del coautor; los agentes separados usan el mismo modelo y no equivalen a revisión humana. No acepta H6-016, no modifica H6 global IN PROGRESS y no autoriza publicación.
