from pathlib import Path
import json,hashlib,shutil,stat,tarfile,gzip,io,re
A=Path(__file__).resolve().parent.parent;R=A/'replica';D=A/'delivery'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def out(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not D.exists();D.mkdir()
for sub in ['receipts','source']:shutil.copytree(A/sub,D/sub)
selected='tests/integration/postgres-h6-016-t07-provider.test.ts';dst=D/'candidate'/selected;dst.parent.mkdir(parents=True);shutil.copy2(R/selected,dst)
rows=[];matches=[]
patterns={'private-key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),'aws-access':re.compile(rb'\bAKIA[0-9A-Z]{16}\b'),'github-token':re.compile(rb'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}\b')}
for p in sorted(D.rglob('*')):
 if not p.is_file():continue
 assert not p.is_symlink();raw=p.read_bytes();relative=str(p.relative_to(D));assert not any(x in p.parts for x in ['node_modules','.git','runtime.env'])
 for name,pattern in patterns.items():
  if pattern.search(raw):matches.append({'path':relative,'category':name,'sha256':h(p)})
 rows.append({'path':relative,'type':'regular','mode':format(stat.S_IMODE(p.stat().st_mode),'04o'),'bytes':len(raw),'sha256':h(p)})
assert not matches,matches
m={'schema':'h6-016-t07-provider-author-selective-manifest-v1','status':'AUTHOR_PASS_PENDING_INDEPENDENT_AUDIT','base':'9c15e6d143822f7fcc84f29744194554630f4ac4','payloadCount':len(rows),'payloadBytes':sum(x['bytes']for x in rows),'files':rows,'candidateSourcePaths':['candidate/'+selected],'finalUniqueCases':9,'run':'receipts/run-01','historicalFAILs':[],'basicHighRiskPatternMatches':matches,'scanLimit':'Focused payload sanity check and synthetic-source provenance; not an independent security audit','excluded':['replica base copy','runtime and database files','node_modules','software caches','environment files','all keys','T08/T09 sealed delivery','H6-007 prepublication','other worktrees'],'newProductOrNormativeChanges':False,'publicationAuthorizedByThisPackage':False}
out(D/'delivery-manifest-v1.json',m);out(D/'delivery-seal-v1.json',{'schema':'h6-016-t07-provider-author-selective-seal-v1','manifest':'delivery-manifest-v1.json','manifestSHA256':h(D/'delivery-manifest-v1.json'),'payloadCount':m['payloadCount'],'payloadBytes':m['payloadBytes'],'authorVerified':True,'independentAuditSeparate':True})
for row in rows:assert h(D/row['path'])==row['sha256']and(D/row['path']).stat().st_size==row['bytes']
archive=A/'delivery-package-v1.tar.gz'
with archive.open('xb')as target:
 with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for p in sorted(D.rglob('*')):
    if not p.is_file():continue
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(D)));info.size=len(data);info.mode=stat.S_IMODE(p.stat().st_mode);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname='';tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz')as tar:
 members=tar.getmembers();assert len(members)==len(rows)+2
 for member in members:
  p=D/member.name;assert member.isfile()and tar.extractfile(member).read()==p.read_bytes()and member.mode==stat.S_IMODE(p.stat().st_mode)
identity={'status':'PASS','delivery':str(D),'manifestSHA256':h(D/'delivery-manifest-v1.json'),'sealSHA256':h(D/'delivery-seal-v1.json'),'payloadCount':len(rows),'payloadBytes':m['payloadBytes'],'archive':str(archive),'archiveSHA256':h(archive),'archiveBytes':archive.stat().st_size,'archiveMembers':len(rows)+2,'candidateSourcePaths':m['candidateSourcePaths'],'allCopiesAndTarMembersReadBack':True}
out(A/'delivery-package-identity-v1.json',identity);print(json.dumps(identity))
