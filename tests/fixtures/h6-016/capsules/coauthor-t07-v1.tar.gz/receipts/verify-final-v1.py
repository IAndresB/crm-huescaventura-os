from pathlib import Path
import json,hashlib,subprocess
A=Path(__file__).resolve().parent.parent;R=A/'replica';D=A/'receipts'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
checks=[]
def check(name,condition,detail):checks.append({'name':name,'status':'PASS'if condition else'FAIL','detail':detail})
expected=read(D/'expected-v1.json');wrong=[]
for row in expected['sourceFiles']:
 p=R/row['path']
 if not p.is_file()or p.is_symlink()or p.stat().st_size!=row['bytes']or sha(p)!=row['sha256']:wrong.append(row['path'])
check('Copied baseline unchanged',not wrong,{'files':len(expected['sourceFiles']),'mismatches':wrong})
products=[x for x in expected['sourceFiles']if x['path'].startswith('src/')];migrations=[x for x in expected['sourceFiles']if x['path'].startswith('supabase/migrations/')]
check('Product110 migrations68 exact',len(products)==110 and len(migrations)==68 and not any(x.startswith(('src/','supabase/migrations/'))for x in wrong),{'product':len(products),'migrations':len(migrations)})
actual=set()
for folder in ['src','supabase/migrations','tests/support','tests/integration','scripts']:actual.update(str(p.relative_to(R))for p in (R/folder).rglob('*')if p.is_file())
extra=sorted(actual-{x['path']for x in expected['sourceFiles']});path=expected['oneNewCandidateSource'];candidate=read(D/'candidate-input-v1.json')
check('Only selected new source',extra==[path]and sha(R/path)==candidate['sha256'],{'extra':extra,'sha256':sha(R/path),'bytes':(R/path).stat().st_size})
result=read(D/'run-01/result-v1.json');inputs=read(D/'run-01/inputs-v1.json');row=next(x for x in inputs if x['path']==path)
check('Run PASS9 bound to final source',result['status']=='PASS'and result['summary']=={'tests':9,'pass':9,'fail':0,'cancelled':0,'skipped':0}and row['sha256']==sha(R/path),{'summary':result['summary'],'resultSHA256':sha(D/'run-01/result-v1.json')})
check('Logs and inputs exact',all(sha(D/'run-01'/f)==result[k]for f,k in [('inputs-v1.json','inputManifestSHA256'),('stdout.log','stdoutSHA256'),('stderr.log','stderrSHA256')]),{'logs':'run-01','inputCount':len(inputs)})
ref=[]
for row in expected['referenceSources']:ref.append({'path':row['path'],'matches':sha(A/'source'/row['path'])==row['sha256']})
check('Published reference sources preserved',all(x['matches']for x in ref),ref)
observed=D/'run-01/observations';races=[]
for p in sorted(observed.glob('race-*.json')):
 x=read(p);races.append({'path':p.name,'distinctSessions':x['distinctSessions'],'distinctPIDs':len({y['pid']for y in x['locks']})==2,'initialMovementCount':x['initialMovementCount'],'finalMovements':len(x['movements']),'consumed':x['funds']['summary']['consumed'],'historyIncrement':x['historyIncrement'],'consumptionCount':x['consumptionCount']})
check('Four real race interleavings',len(races)==4 and all(x['distinctSessions']and x['distinctPIDs']and x['initialMovementCount']==0 and x['finalMovements']==1 and x['consumed']=='80.00'and x['historyIncrement']==1 and x['consumptionCount']==1 for x in races),races)
fault=read(observed/'rollback-late.json');noRetro=read(observed/'unapproved-no-retro.json')
check('Fault witness and no retroapproval',fault['faultReached']and fault['retrySameIdentity']=='PASS'and noRetro['state']['movements'][0]['approvalReservation']is None and noRetro['retroactiveRejected']=='PROVIDER_PAYMENT_INPUT_INVALID',{'fault':fault,'unapprovedStatus':noRetro['state']['status']})
runtime=read(observed/'runtime.json');temp=Path(runtime['temporary']);cache=Path(expected['runtime'])/'crm-supabase-storage-5def1dfc15ab7f08fe271c7d1e70542424524e4e';head=subprocess.run(['git','rev-parse','HEAD'],cwd=cache,capture_output=True,text=True);diff=subprocess.run(['git','diff','--quiet'],cwd=cache,capture_output=True)
check('Own runtime closed pinned software only',not temp.exists()and temp.parent==Path(expected['runtime'])and head.returncode==0 and head.stdout.strip()=='5def1dfc15ab7f08fe271c7d1e70542424524e4e'and diff.returncode==0 and not(R/'.git').exists(),{'runtime':runtime,'temporaryRemoved':not temp.exists(),'cacheHEAD':head.stdout.strip(),'CRMgitDirectory':False})
quality=read(D/'quality-v1/result-v1.json');check('Typecheck boundaries final source',quality['status']=='PASS'and quality['sourceSHA256']==sha(R/path),quality)
out={'schema':'h6-016-t07-provider-author-final-v1','status':'PASS'if all(x['status']=='PASS'for x in checks)else'FAIL','passed':sum(x['status']=='PASS'for x in checks),'total':len(checks),'checks':checks,'source':{'path':path,'sha256':sha(R/path),'bytes':(R/path).stat().st_size},'independentAudit':'Separate agent pending; this is author custody/self-verification','scope':'Supplier/provider payment supplement only, no full H6-016 closure'}
(D/'final-verification-v1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'status':out['status'],'passed':out['passed'],'total':out['total'],'sha256':sha(D/'final-verification-v1.json'),'source':out['source']}));raise SystemExit(0 if out['status']=='PASS'else 1)
