# H6-016 · Ensayos integrados T08/T09 del autor

Resultado técnico del alcance delegado: PASS en 19 casos distintos sobre PostgreSQL real aislado, datos sintéticos, los contratos de aplicación publicados, TTE actual y las 68 migraciones. Solo se incorporan tres archivos de ensayo. El código de producto y las migraciones conservan sus 178 identidades de la base `9c15e6d143822f7fcc84f29744194554630f4ac4`.

Este paquete es una entrega del coautor al integrador y al auditor técnico independiente. No constituye dictamen independiente sobre su propio código ni aceptación de H6-016. H6 global continúa IN PROGRESS. No incorpora el candidato de prepublicación H6-007 ni lo modifica.

## Fuentes finales para integración selectiva

| Ruta | SHA-256 |
|---|---|
| `tests/support/h6-016-t08-t09.ts` | `00321c57216561c7618dc80bd60e4127da44a4d484d6ac3177dea444030d4743` |
| `tests/integration/postgres-h6-016-t08-t09-work.test.ts` | `796d0e1c816818617b2e9ed5ff9c3cf060118ff507cfc0dba10f52267dbfa188` |
| `tests/integration/postgres-h6-016-t08-t09-events.test.ts` | `33aaf653af81c88f74b2af7d94c52f1c610ef504f69eca60670c7f75947bef5d` |

Cada fixture crea una Booking mediante `bookingFixture` y el adaptador de aplicación vigente. Comunicaciones, trabajo persistido y eventos se vinculan a esa Booking real del ensayo. Se comparan después sus filas de Booking y servicios con la instantánea previa. Los datos de negocio no se siembran mediante SQL. Las consultas administrativas se limitan a observar, retener locks y provocar fallos acotados en las bases nuevas propias.

Las derivaciones de H5-008 y H6-006, los tres ancestros literales y sus hashes están en `derivation-v1.json`, `source/` y las expectativas previas. Se sustituyen el bootstrap antiguo por full68, la vinculación sintética sin Booking por creación a través de aplicación y los recursos por nombres/puertos propios. Los correctivos posteriores refuerzan la atribución del fallo y la cobertura temporal; están declarados y conservan las fuentes anteriores.

## Cobertura efectiva

| Grupo | Casos | Evidencia final |
|---|---:|---|
| Dos workers y dos sesiones, intentos inicialmente ausentes, ambos órdenes de claim | 2 | `run-04/observations/claim-race-*.json`, perdedor exacto WORK_LEASE_HELD |
| Lease precontacto vencido naturalmente; generación nueva y fencing del anterior | 1 | `run-04/observations/fencing.json` y `natural-lease-*.json` |
| Lease postcontacto vencido naturalmente; incertidumbre y reserva conservadas sin reenvío | 1 | `run-04/observations/uncertain-recovery.json` |
| Replay de definición/claim y conflicto de identidad material | 1 | Log de run-04 |
| Pause/start con sesiones distintas, ambos órdenes | 2 | `run-04/observations/pause-start-race-*.json`, rechazo WORK_FENCED_OR_INAPPLICABLE en pause primero |
| Fallos de claim/start/result: resultado, historia, intención y HA/M02 revierten juntos | 3 | `run-04/observations/rollback-*.json`, error exacto WORK_INJECTED_ROLLBACK |
| Restricción diferida y finalizador obligatorio | 1 | `run-04/observations/deferred-rollback.json`, WORK_DEFERRED_COMMIT y WORK_ORIGINAL_RESERVE_FINAL_CHECK |
| Evidencia vigente al inicio vence durante espera diferida realmente alcanzada | 1 | `run-04/observations/expired-final-check.json`, testigo de secuencia y rollback completo |
| Pérdida real del ACK COMMIT de result, efecto ya durable y recuperación por identidad | 1 | `run-04/observations/commit-response-loss.json` |
| Start ya comprometido: replay tras vencer evidencia, sin refresco/reserva/efecto/historia/resultado duplicado y con reautorización | 1 | `run-04/observations/start-replay-expired-evidence.json` |
| Misma fachada max1, rechazos de sujeto/contexto/purpose y recuperación autorizada | 1 | `run-04/observations/pool-context.json` |
| Evento original, duplicado y conflicto E2, preservación de original canónico | 1 | Log de run-05 |
| Fallo en receipt B09 realmente alcanzado y rollback exacto de cinco tablas; retry de la misma identidad | 1 | `run-05/observations/event-rollback-witness.json` |
| Raíz común de evento con hijos ausentes, duplicado/conflicto y ambos órdenes | 2 | Cuatro capturas `run-05/observations/event-race-*.json` |

Son 15 casos work/T08-T09 y 4 casos de eventos. Las carreras observan sesiones PostgreSQL distintas, esperas reales y `pg_blocking_pids`; las cuatro variantes internas de eventos no se suman como cuatro casos Node adicionales.

D039 se comprueba en su ubicación real: `SET CONSTRAINTS ALL IMMEDIATE` ejecuta las restricciones diferidas antes de los finalizadores obligatorios; la validación final y COMMIT se emiten desde el executor servidor. No se afirma que una evidencia deba continuar vigente hasta el fin físico de la escritura de COMMIT. El fallo de ACK se provoca en el protocolo PostgreSQL, reteniendo el CommandComplete COMMIT auténtico, no mediante un `throw` después de recibir un éxito.

El replay de start admite el resultado ya comprometido con evidencia vencida sin volver al proveedor. Se exige un único llamado al proveedor y todos los campos de negocio exactos. La actividad humana de la sesión actualmente autorizada puede avanzar de forma monotónica conforme al contrato F2; las identidades y demás campos de épocas permanecen exactos. La revocación usa `H0005PostgresAdapter.revokeOne`, el replay de esa sesión se rechaza exactamente con `F2_DENIED` / `42501` y otra sesión conserva acceso al resultado.

## Ejecuciones y correctivos preservados

| Ejecución | Resultado original | Alcance y disposición |
|---|---|---|
| run-01 | PASS 18/18 | Primer alcance. Fuentes v1 conservadas. Sus dos expiraciones eran inyección temporal SQL, no vencimiento natural; no se usa como prueba final de esa propiedad. |
| run-02 | 18 PASS / 1 FAIL | Caso 19: oráculo demasiado amplio incluía el timestamp legítimo de actividad humana. FAIL, fuentes v2 y expectativa correctiva se conservan. |
| run-03 | 18 PASS / 1 FAIL | Caso 19: la denegación era correcta, pero se esperaba la capa WORK_DENIED en vez de la capa vigente F2_DENIED/42501. FAIL y fuentes v3 conservados. |
| run-04 | PASS 19/19 | Motivos exactos, expiración natural y caso 19 corregidos. Fuentes v4 conservadas. Acredita literalmente los 15 casos work finales. |
| run-05 | PASS 4/4 | Refuerzo final solo de eventos: testigo del trigger y comparación exacta de cinco tablas. Acredita literalmente los 4 casos events finales. |

El alcance final reúne 15 casos de run-04 y 4 de run-05 sobre sus hashes exactos; no se presenta run-04 como una nueva ejecución completa de la combinación posterior. Los 79 casos ejecutados acumulados incluyen repeticiones: 77 PASS y 2 FAIL instrumentales originales, no 79 escenarios distintos. No se ha ejecutado regresión histórica indiscriminada. El integrador y el auditor repetirán la composición congelada con sus propios recursos.

`quality-final-v2/result-v1.json` confirma PASS de TypeScript noEmit y límites arquitectónicos sobre las tres fuentes finales. No se atribuye a este coautor una nueva batería unitaria completa ni un build Next; esas verificaciones de composición pertenecen al integrador. `final-verification-v1.json` registra PASS 15/15, con 472 fuentes copiadas intactas, 110 archivos de producto, 68 migraciones, fuentes históricas y logs ligados por SHA-256.

## Custodia y límites

El runner publicado permanece literal. Creó una caché nueva de software Storage fijada en `5def1dfc15ab7f08fe271c7d1e70542424524e4e` dentro de TMPDIR propio. Esa descarga de software, permitida para el bootstrap, no es acceso a datos o efectos de negocio. Se usó entorno reducido y credenciales efímeras sintéticas generadas por el runner; no se heredaron variables H6015 ni configuración de otros entornos.

Los nueve directorios de base de los cinco ensayos ya no existen tras su cierre. Ningún runtime, node_modules, caché de software, runtime.env, clave o base de datos forma parte del paquete. Las pruebas se ejecutaron en la réplica sin `.git`; no hubo staging, índices alternos, escrituras de objetos CRM, commit, push, merge, Drive ni despliegue. No se accedió al runtime de H6-015, S11 ni a los cuatro trabajos suspendidos.

El control de pool propio acredita la misma fachada con configuración max1, no prueba por sí solo identidad física del PID. La contraprueba de reutilización física corresponde al auditor independiente. La independencia efectiva es de agentes separados del mismo modelo; no se atribuye auditoría humana. Este paquete cubre el subconjunto delegado T08/T09; no sustituye el resto de asignaciones de H6-016 ni concede autorización de publicación.
