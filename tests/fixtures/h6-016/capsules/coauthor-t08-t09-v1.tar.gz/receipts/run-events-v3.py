from pathlib import Path
import subprocess,json,hashlib,os,sys,datetime,re
A=Path(__file__).resolve().parent.parent;R=A/'replica';D=A/'receipts'/sys.argv[1];D.mkdir(exist_ok=False);runtime=Path('/tmp/crm-h6016-t08-t09-author-runtime');runtime.mkdir(mode=0o700,exist_ok=True)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for folder in ['src','supabase/migrations','tests/support','tests/integration','scripts']:
 for p in sorted((R/folder).rglob('*')):
  if p.is_file():files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':h(p)})
(D/'inputs-v1.json').write_text(json.dumps(files,indent=2)+'\n');(D/'observations').mkdir()
env={k:os.environ[k]for k in ['PATH','HOME']if k in os.environ};env.update({'TMPDIR':str(runtime),'LANG':'C','LC_ALL':'C','CI':'1','NODE_NO_WARNINGS':'1','POSTGRES_H0_BIN':'/Users/andres/Applications/Postgres.app/Contents/Versions/17/bin','H6016_T08_T09_OUTPUT':str(D/'observations')})
cmd=['node','scripts/test-postgres.mjs',*sys.argv[2:]];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (D/'stdout.log').open('xb')as out,(D/'stderr.log').open('xb')as err:q=subprocess.run(cmd,cwd=R,env=env,stdout=out,stderr=err)
stdout=(D/'stdout.log').read_text(errors='replace');summary={m.group(1):int(m.group(2))for m in re.finditer(r'^(?:#|ℹ) (tests|pass|fail|cancelled|skipped) (\d+)',stdout,re.M)}
result={'status':'PASS'if q.returncode==0 and summary.get('tests')==4 and summary.get('pass')==4 and summary.get('fail')==0 and summary.get('cancelled')==0 and summary.get('skipped')==0 else 'FAIL','exitCode':q.returncode,'expectedCases':4,'summary':summary,'startedAt':start,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'inputManifestSHA256':h(D/'inputs-v1.json'),'stdoutSHA256':h(D/'stdout.log'),'stderrSHA256':h(D/'stderr.log'),'runnerSHA256':h(Path(__file__)),'publishedRunnerSHA256':h(R/'scripts/test-postgres.mjs'),'ownRuntime':str(runtime),'environmentKeys':sorted(env),'H6015VariablesInherited':False,'realCredentials':False,'CRMgitWrites':False,'softwareOnlyNewCacheAllowed':True}
(D/'result-v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);sys.exit(0 if result['status']=='PASS'else 1)
