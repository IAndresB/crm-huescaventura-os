from pathlib import Path
import json,hashlib,shutil,stat,tarfile,gzip,io,re,datetime
A=Path(__file__).resolve().parent.parent;R=A/'replica';D=A/'delivery'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def out(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not D.exists();D.mkdir()
for sub in ['receipts','source']:
    shutil.copytree(A/sub,D/sub)
selected=['tests/support/h6-016-t08-t09.ts','tests/integration/postgres-h6-016-t08-t09-work.test.ts','tests/integration/postgres-h6-016-t08-t09-events.test.ts']
for path in selected:
    dst=D/'candidate'/path;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/path,dst)
rows=[];matches=[]
patterns={'private-key':re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),'aws-access':re.compile(rb'\bAKIA[0-9A-Z]{16}\b'),'github-token':re.compile(rb'\b(?:ghp_|github_pat_)[A-Za-z0-9_]{30,}\b')}
for p in sorted(D.rglob('*')):
    if not p.is_file():continue
    assert not p.is_symlink();raw=p.read_bytes();relative=str(p.relative_to(D))
    assert not any(x in p.parts for x in ['node_modules','.git','runtime.env'])
    for label,pattern in patterns.items():
        if pattern.search(raw):matches.append({'path':relative,'category':label,'sha256':h(p)})
    rows.append({'path':relative,'type':'regular','mode':format(stat.S_IMODE(p.stat().st_mode),'04o'),'bytes':len(raw),'sha256':h(p)})
assert not matches,matches
m={'schema':'h6-016-t08-t09-author-selective-manifest-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'AUTHOR_PASS_PENDING_INDEPENDENT_AUDIT','base':'9c15e6d143822f7fcc84f29744194554630f4ac4','payloadCount':len(rows),'payloadBytes':sum(x['bytes']for x in rows),'files':rows,'candidateSourcePaths':['candidate/'+x for x in selected],'finalUniqueCases':19,'finalCoverage':{'work':{'cases':15,'run':'receipts/run-04'},'events':{'cases':4,'run':'receipts/run-05'}},'historicalFAILs':['receipts/run-02/result-v1.json','receipts/run-03/result-v1.json'],'basicHighRiskPatternMatches':matches,'scanLimit':'Focused payload sanity check and synthetic-source provenance; not an independent security audit','excluded':['replica base copy','runtime and database files','node_modules','software caches','environment files','all keys','H6-007 prepublication','other worktrees'],'newProductOrNormativeChanges':False,'publicationAuthorizedByThisPackage':False}
out(D/'delivery-manifest-v1.json',m)
s={'schema':'h6-016-t08-t09-author-selective-seal-v1','manifest':'delivery-manifest-v1.json','manifestSHA256':h(D/'delivery-manifest-v1.json'),'payloadCount':m['payloadCount'],'payloadBytes':m['payloadBytes'],'authorVerified':True,'independentAuditSeparate':True}
out(D/'delivery-seal-v1.json',s)
for row in rows:assert h(D/row['path'])==row['sha256'] and (D/row['path']).stat().st_size==row['bytes']
tarpath=A/'delivery-package-v1.tar.gz'
with tarpath.open('xb')as target:
    with gzip.GzipFile(fileobj=target,mode='wb',filename='',mtime=0)as gz:
        with tarfile.open(fileobj=gz,mode='w')as tar:
            for p in sorted(D.rglob('*')):
                if not p.is_file():continue
                data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(D)));info.size=len(data);info.mode=stat.S_IMODE(p.stat().st_mode);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname='';tar.addfile(info,io.BytesIO(data))
with tarfile.open(tarpath,'r:gz')as tar:
    members=tar.getmembers();assert len(members)==len(rows)+2
    for item in members:
        p=D/item.name;assert item.isfile() and tar.extractfile(item).read()==p.read_bytes() and item.mode==stat.S_IMODE(p.stat().st_mode)
identity={'status':'PASS','delivery':str(D),'manifestSHA256':h(D/'delivery-manifest-v1.json'),'sealSHA256':h(D/'delivery-seal-v1.json'),'payloadCount':len(rows),'payloadBytes':m['payloadBytes'],'archive':str(tarpath),'archiveSHA256':h(tarpath),'archiveBytes':tarpath.stat().st_size,'archiveMembers':len(rows)+2,'candidateSourcePaths':m['candidateSourcePaths'],'allCopiesAndTarMembersReadBack':True}
out(A/'delivery-package-identity-v1.json',identity)
print(json.dumps(identity))
