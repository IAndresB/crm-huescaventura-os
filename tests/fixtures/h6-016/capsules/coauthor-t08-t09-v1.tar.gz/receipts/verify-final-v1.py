from pathlib import Path
import json, hashlib, subprocess, stat

A=Path(__file__).resolve().parent.parent
R=A/'replica'; D=A/'receipts'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
checks=[]
def check(name,condition,detail):
    checks.append({'name':name,'status':'PASS' if condition else 'FAIL','detail':detail})

expected=read(D/'expected-v1.json')
wrong=[]
for row in expected['sourceFiles']:
    p=R/row['path']
    if not p.is_file() or p.is_symlink() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:
        wrong.append(row['path'])
check('All copied base source identities preserved',not wrong,{'count':len(expected['sourceFiles']),'mismatches':wrong})
product=[r for r in expected['sourceFiles'] if r['path'].startswith('src/')]
migrations=[r for r in expected['sourceFiles'] if r['path'].startswith('supabase/migrations/')]
check('Product and migrations unchanged',len(product)==110 and len(migrations)==68 and not any(p.startswith(('src/','supabase/migrations/')) for p in wrong),{'product':len(product),'migrations':len(migrations)})

selected=['tests/support/h6-016-t08-t09.ts','tests/integration/postgres-h6-016-t08-t09-work.test.ts','tests/integration/postgres-h6-016-t08-t09-events.test.ts']
actual=set()
for folder in ['src','supabase/migrations','tests/support','tests/integration','scripts']:
    actual.update(str(p.relative_to(R)) for p in (R/folder).rglob('*') if p.is_file())
baseline={r['path'] for r in expected['sourceFiles']}
extra=sorted(actual-baseline)
check('Exactly three new source paths',extra==sorted(selected),extra)

results=[]
expected_runs={'run-01':(18,18,0,'PASS'),'run-02':(19,18,1,'FAIL'),'run-03':(19,18,1,'FAIL'),'run-04':(19,19,0,'PASS'),'run-05':(4,4,0,'PASS')}
for name,(tests,passed,failed,status) in expected_runs.items():
    p=D/name; result=read(p/'result-v1.json'); summary=result['summary']
    identity=all(sha(p/f)==result[k] for f,k in [('inputs-v1.json','inputManifestSHA256'),('stdout.log','stdoutSHA256'),('stderr.log','stderrSHA256')])
    good=summary['tests']==tests and summary['pass']==passed and summary['fail']==failed and result['status']==status and identity
    results.append({'run':name,'status':status,'tests':tests,'passed':passed,'failed':failed,'resultSHA256':sha(p/'result-v1.json'),'capturedFiles':len(list((p/'observations').glob('*.json')))})
    check('Preserved execution '+name,good,results[-1])

linked=[]
for path,run in [(selected[0],'run-04'),(selected[1],'run-04'),(selected[2],'run-05')]:
    row=next(x for x in read(D/run/'inputs-v1.json') if x['path']==path)
    linked.append({'path':path,'sha256':sha(R/path),'bytes':(R/path).stat().st_size,'mode':format(stat.S_IMODE((R/path).stat().st_mode),'04o'),'type':'regular','provenBy':run,'matches':sha(R/path)==row['sha256']})
check('Final nineteen-case coverage bound to exact sources',all(x['matches']for x in linked),{'uniqueCases':19,'workCases':15,'workRun':'run-04','eventCases':4,'eventRun':'run-05','sources':linked,'singleFinalFullRunClaimed':False})

historical=[]
for version,ep,key in [('v1','successor-expected-v2.json','predecessorSources'),('v2','oracle-correction-expected-v3.json','predecessorSources'),('v3','revocation-oracle-expected-v4.json','predecessorSources'),('v4','event-witness-expected-v5.json','predecessorSources')]:
    for row in read(D/ep)[key]:
        p=D/('source-'+version)/row['path']
        historical.append({'path':str(p.relative_to(D)),'matches':sha(p)==row['sha256'],'sha256':sha(p)})
check('All historical source versions preserved',all(x['matches']for x in historical),{'files':len(historical),'rows':historical})
check('FAIL02 and FAIL03 linked to frozen corrective expectations',sha(D/'run-02/result-v1.json')==read(D/'oracle-correction-expected-v3.json')['predecessorRunSHA256'] and sha(D/'run-03/result-v1.json')==read(D/'revocation-oracle-expected-v4.json')['predecessorRunSHA256'],{'classification':'instrumental overconstraint and incorrect error-layer expectation; original results retained'})

resources=[]
for name in expected_runs:
    for p in sorted((D/name/'observations').glob('runtime-*.json')):
        row=read(p); temporary=Path(row['temporary'])
        resources.append({'run':name,'label':row['label'],'port':row['port'],'temporary':str(temporary),'withinOwnRuntime':temporary.parent==Path('/tmp/crm-h6016-t08-t09-author-runtime'),'removed':not temporary.exists(),'migrations':row['migrations']})
check('Own test databases removed after runs',len(resources)==9 and all(x['withinOwnRuntime'] and x['removed'] and x['migrations']==68 for x in resources),resources)
software=Path('/tmp/crm-h6016-t08-t09-author-runtime/crm-supabase-storage-5def1dfc15ab7f08fe271c7d1e70542424524e4e')
head=subprocess.run(['git','rev-parse','HEAD'],cwd=software,capture_output=True,text=True)
diff=subprocess.run(['git','diff','--quiet'],cwd=software,capture_output=True)
check('Own software-only bootstrap pinned and source unchanged',head.returncode==0 and head.stdout.strip()=='5def1dfc15ab7f08fe271c7d1e70542424524e4e' and diff.returncode==0,{'path':str(software),'head':head.stdout.strip(),'sourceDiffExitCode':diff.returncode,'scope':'Published runner private software cache; no CRM Git writes'})

replay=read(D/'run-04/observations/start-replay-expired-evidence.json')
event=read(D/'run-05/observations/event-rollback-witness.json')
natural=list((D/'run-04/observations').glob('natural-lease-*.json'))
check('Strengthened evidence witnesses present',replay['evidenceCalls']==1 and replay['revokedSessionDenied']=='F2_DENIED' and replay['revokedSessionSQLState']=='42501' and replay['authorizedHumanActivityMonotonic'] and replay['noNewReservationOrEffectOrHistoryOrResult'] and event['triggerReached'] and len(natural)==2 and all(read(p)['leaseValueUnmodified'] for p in natural),{'committedStartReplay':str(D/'run-04/observations/start-replay-expired-evidence.json'),'eventRollback':str(D/'run-05/observations/event-rollback-witness.json'),'naturalLeases':len(natural)})
check('Replica has no CRM Git directory',not (R/'.git').exists(),{'replica':str(R),'CRMindexOrObjectWrites':False})
result={'schema':'h6-016-t08-t09-author-final-verification-v1','status':'PASS' if all(x['status']=='PASS'for x in checks) else 'FAIL','passed':sum(x['status']=='PASS'for x in checks),'total':len(checks),'checks':checks,'candidateSources':linked,'runs':results,'scope':'Author self-verification; independent technical audit remains separate. No full H6-016 acceptance claim.'}
(D/'final-verification-v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'passed':result['passed'],'total':result['total'],'sha256':sha(D/'final-verification-v1.json'),'sources':linked}))
raise SystemExit(0 if result['status']=='PASS' else 1)
