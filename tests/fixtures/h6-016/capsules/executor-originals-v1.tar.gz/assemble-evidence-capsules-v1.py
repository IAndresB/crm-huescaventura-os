from pathlib import Path
import json,hashlib,stat,tarfile,gzip,io,datetime
D=Path(__file__).resolve().parent;R=D.parent/'crm-huescaventura-os';OUT=R/'tests/fixtures/h6-016/capsules';OUT.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def capsule(name,root,files):
 rows=[];buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT)as tf:
  for p in files:
   s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();rel=str(p.relative_to(root));assert '..'not in Path(rel).parts;raw=p.read_bytes();rows.append({'path':rel,'bytes':len(raw),'mode':format(stat.S_IMODE(s.st_mode),'04o'),'sha256':sha(raw)})
   t=tarfile.TarInfo(rel);t.size=len(raw);t.mode=stat.S_IMODE(s.st_mode);t.mtime=0;tf.addfile(t,io.BytesIO(raw))
 target=OUT/(name+'.tar.gz')
 with target.open('wb')as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=6)as z:z.write(buf.getvalue())
 archive=target.read_bytes()
 with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz')as tf:
  ms=tf.getmembers();assert len(ms)==len(rows)
  for x,m in zip(rows,ms):assert m.isfile()and m.name==x['path']and m.mode==int(x['mode'],8)and sha(tf.extractfile(m).read())==x['sha256']
 mpath=OUT/(name+'-manifest-v1.json');m={'schema':'h6016-lossless-capsule-v1','sourceRoot':str(root),'archive':target.name,'archiveSHA256':sha(archive),'archiveBytes':len(archive),'payloadCount':len(rows),'payloadBytes':sum(x['bytes']for x in rows),'files':rows,'runtimesSecretsDatabasesExcluded':True};mpath.write_text(json.dumps(m,indent=2)+'\n')
 return {'archive':str(target.relative_to(R)),'sha256':sha(archive),'bytes':len(archive),'manifest':str(mpath.relative_to(R)),'manifestSHA256':sha(mpath.read_bytes()),'payloads':len(rows),'payloadBytes':m['payloadBytes']}
exclude={'coauthor-t08-t09-delivery','coauthor-t07-delivery'};files=[p for p in sorted(D.rglob('*'))if p.is_file()and p.relative_to(D).parts[0]not in exclude];items=[capsule('executor-originals-v1',D,files)]
for src,name in [('coauthor-t08-t09-delivery','coauthor-t08-t09-v1'),('coauthor-t07-delivery','coauthor-t07-v1')]:
 root=D/src;items.append(capsule(name,root,[p for p in sorted(root.rglob('*'))if p.is_file()]))
(OUT/'capture-catalog-v1.json').write_text(json.dumps({'schema':'h6016-lossless-capture-catalog-v1','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'items':items,'status':'PASS','noOriginalReplaced':True,'rawEvidenceOutsideGitAlsoPreserved':True},indent=2)+'\n');print(json.dumps(items))
