from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent.parent/'crm-huescaventura-os';D=Path(__file__).resolve().parent;H7=Path('/Users/andres/.codex/worktrees/h6-007-local/crm-huescaventura-os');derived=[]
for src,dst,replace in [(H7/'tests/support/h6-007-fixtures.ts',R/'tests/support/h6-016-foundation.ts',[('h6007','h6016'),('H6007','H6016'),('E2E-07 synthetic orchestration','H6-016 explicitly derived E2E-07 orchestration')]),(R/'tests/support/h4-refund-fixtures.ts',R/'tests/support/h6-016-refund-fixtures.ts',[("'./h4-cancellation-fixtures.ts'","'./h5-017-g-cancellation-fixtures.ts'")])]:
 b=src.read_bytes();s=b.decode()
 for a,z in replace:s=s.replace(a,z)
 assert not dst.exists();dst.write_text(s);derived.append({'source':str(src),'sourceSHA256':hashlib.sha256(b).hexdigest(),'derived':dst.relative_to(R).as_posix(),'derivedSHA256':hashlib.sha256(dst.read_bytes()).hexdigest(),'replacements':replace,'productChanged':False})
(R/'tests/fixtures/h6-016/derived-sources-v1.json').write_text(json.dumps(derived,indent=2)+'\n')
