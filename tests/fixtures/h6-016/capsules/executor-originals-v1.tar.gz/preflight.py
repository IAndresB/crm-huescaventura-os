from pathlib import Path
import json,hashlib,subprocess,datetime,urllib.request
R=Path(__file__).resolve().parent.parent/'crm-huescaventura-os';D=Path(__file__).resolve().parent;H7=Path('/Users/andres/.codex/worktrees/h6-007-local')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('rev-parse','HEAD')==git('rev-parse','origin/main')=='9c15e6d143822f7fcc84f29744194554630f4ac4';assert git('rev-parse','HEAD^{tree}')=='fe7cabb05e44462121c70ad52405765e2c94fcd2';assert not git('status','--porcelain')
checks=[]
for name,pin,root in [('local-final-candidate-v1.json','4aeb3d83e685bc1282ab1eb536c9665d2ab3e1243459214ace1ed2ed839c7e91',H7/'crm-huescaventura-os'),('receipts-master-manifest-v1.json','56dbe40105e6bc2b4f3d90dc0389ee6b50b1df696dd4a3f56694fd226502b493',H7/'receipts')]:
 p=H7/'receipts'/name;assert h(p)==pin;j=json.loads(p.read_bytes())
 for x in j['files']:
  q=root/x['path'];assert q.is_file() and not q.is_symlink() and h(q)==x['sha256'] and q.stat().st_size==x['bytes'];assert 'mode' not in x or format(q.stat().st_mode&0o777,'04o')==x['mode'];assert 'gitMode' not in x or ('100755' if q.stat().st_mode&0o111 else '100644')==x['gitMode']
 checks.append({'manifest':str(p),'sha256':pin,'files':len(j['files']),'bytes':sum(x['bytes'] for x in j['files']),'status':'PASS'})
paths=['README.md','docs/constitution.md','docs/DECISIONS.md','specs/001-core-crm/tasks.md','specs/001-core-crm/spec.md','docs/architecture.md','specs/001-core-crm/plan.md','docs/domain-model.md','docs/state-machines.md','docs/business-rules.md','docs/PROJECT-STATUS.md','docs/NEXT-STEPS.md','specs/001-core-crm/acceptance-TSK-H5-019.md','specs/001-core-crm/closure-TSK-H5-019.md','specs/001-core-crm/acceptance-TSK-H6-013.md','specs/001-core-crm/acceptance-TSK-H6-001-local.md','specs/001-core-crm/acceptance-TSK-H6-004.md','specs/001-core-crm/acceptance-TSK-H6-006-local.md']
rows=[]
for rel in paths+[p.relative_to(R).as_posix() for folder in ['src','supabase/migrations'] for p in sorted((R/folder).rglob('*')) if p.is_file()]:
 p=R/rel;rows.append({'path':rel,'bytes':p.stat().st_size,'sha256':h(p),'gitMode':'100755' if p.stat().st_mode&0o111 else '100644'})
assert sum(x['path'].startswith('supabase/migrations/') for x in rows)==68
out={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS','base':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'remote':git('remote','get-url','origin'),'trackedAndIndexClean':True,'initialUntrackedEmpty':True,'H7FullVerification':checks,'protectedFiles':rows,'H6015RuntimeAccess':False,'H6':'IN_PROGRESS'}
p=D/'preflight-v1.json';assert not p.exists();p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','protected':len(rows),'migrations':68,'H7':checks},indent=2))
for name,url in [('supabase-changelog.md','https://supabase.com/changelog.md'),('supabase-connections.md','https://supabase.com/docs/guides/database/connecting-to-postgres.md'),('postgres-locking.html','https://www.postgresql.org/docs/17/explicit-locking.html')]:
 try:
  b=urllib.request.urlopen(url,timeout=25).read();(D/name).write_bytes(b);print(json.dumps({'publicDoc':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}))
 except Exception as e:print(json.dumps({'publicDoc':name,'error':str(e)}))
