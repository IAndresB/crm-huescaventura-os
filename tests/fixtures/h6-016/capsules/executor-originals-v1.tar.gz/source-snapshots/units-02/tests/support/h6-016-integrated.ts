// Test-only orchestration of approved application contracts on the complete 68-migration database.
import assert from 'node:assert/strict';
import {randomUUID as uid,createHash} from 'node:crypto';
import {appendFile,mkdir} from 'node:fs/promises';
import {join} from 'node:path';
import {database,waitFor,fixture,read,write,type H} from './h6-016-foundation.ts';
import {acceptanceFixture} from './h2-acceptance-fixtures.ts';
import {bookingFixture} from './h2-booking-fixtures.ts';
import {modificationFixture} from './h4-modification-fixtures.ts';
import {allocationFixture} from './h3-allocation-fixtures.ts';
import {cancellationFixture} from './h5-017-g-cancellation-fixtures.ts';
import {refundFixture} from './h6-016-refund-fixtures.ts';
import {secondWorkActor} from './h5-work-isolated.ts';
import {H1003ResolutionAdapter} from '../../src/infrastructure/postgres/h1-resolution-adapter.ts';
export {database,read,write,uid};export type {H};
export type Actor={sql:any,auth:()=>Promise<any>,close:()=>Promise<unknown>};
export async function actor(h:H):Promise<Actor>{const session=await secondWorkActor(h),sql=h.connect('crm_h0_runtime');await sql.unsafe("set statement_timeout='20000ms'");return {sql,auth:session.auth,close:()=>sql.end({timeout:1})};}
export async function capture(id:string,value:unknown){const out=process.env.H6016_OUTPUT;if(!out)throw new Error('H6016_CAPTURE_REQUIRED');await mkdir(out,{recursive:true});await appendFile(join(out,'integrated-observed.jsonl'),JSON.stringify({id,at:new Date().toISOString(),value})+'\n');}
export async function snapshot(h:H){const rows=await h.observer`select schemaname,tablename from pg_tables where (schemaname='crm_private'and tablename~'^(b0[2-9]_|b10_|catalog_|commercial_|identity_|unit_|external_effect_)') or (schemaname='crm_ha'and tablename in('reservations','events','command_receipts','evidence_revalidations')) order by schemaname,tablename`;const out:Record<string,string>={};for(const t of rows){assert.match(t.tablename,/^[a-z0-9_]+$/);out[t.schemaname+'.'+t.tablename]=String((await h.observer.unsafe(`select encode(crm_crypto.digest(coalesce(string_agg(to_jsonb(x)::text,E'\n'order by to_jsonb(x)::text),''),'sha256'),'hex') h from ${t.schemaname}.${t.tablename} x`))[0]!.h);}return out;}
export async function run(h:H,kind:string,q:any,a?:Actor,method='apply'){const base=kind==='resolution'?new H1003ResolutionAdapter(h.runtime,h.f1,h.f2):(h as any)[kind];assert.ok(base,'H6016 existing adapter '+kind);const adapter=a?new base.constructor(a.sql,h.f1,h.f2):base;return adapter[method](await(a?a.auth():h.auth()),write,q);}
export type Unit={id:string,a:any,b:any,gate:(tx:any)=>Promise<any>,early:string,late:string,final:string,execute:(q:any,a?:Actor)=>Promise<any>,see:()=>Promise<any>,check:()=>Promise<any>,preserve:()=>Promise<any>};
const empty=async()=>null;
export async function unit(h:H,id:string):Promise<Unit>{
 let a:any,b:any,kind='',method='apply',root='',seed=31,early='',late='',final='',see:any,check:any,preserve:any=empty,gate:any;
 if(id==='T01'){
  const f=await acceptanceFixture(h);const old=await h.proposal.read(await h.auth(),read,f.proposalId,'internal',f.versionId);const rev=await f.revisions();await h.proposal.apply(await h.auth(),write,{action:'prepare',operationId:uid(),proposalId:f.proposalId,opportunityId:f.opp.targetId,...rev,baseVersionId:f.versionId,reviewed:true,content:{...f.content,scope:'SYNTHETIC new reviewed version'},sourceRef:'SYNTHETIC H6016 review',reason:'SYNTHETIC exact revision'});
  a={action:'fix',operationId:uid(),proposalId:f.proposalId,opportunityId:f.opp.targetId,...await f.revisions(),versionId:uid(),sourceRef:'SYNTHETIC H6016 fixed',reason:'SYNTHETIC immutable second version'};b={...a,operationId:uid(),versionId:uid()};root=f.opp.targetId;kind='proposal';early='b03_proposal_versions';late='b03_proposal_history';final='b03_proposal_operations';see=async()=>h.proposal.read(await h.auth(),read,f.proposalId,'internal');
  preserve=async()=>h.proposal.read(await h.auth(),read,f.proposalId,'internal',f.versionId);check=async()=>{assert.deepEqual(await preserve(),old);const rows=await h.observer`select version_number,version_id from crm_private.b03_proposal_versions where proposal_id=${f.proposalId}::uuid order by version_number`;assert.equal(rows.length,2);assert.equal(String(rows[1]!.version_number),'2');return rows;};
 }else if(id==='T02'){
  const f=await acceptanceFixture(h),r=await f.register();a=await f.verification(r);b={...a,operationId:uid()};kind='acceptance';root=f.opp.targetId;early='b03_acceptance_verifications';late='b03_acceptance_history';final='b03_acceptance_operations';see=async()=>h.acceptance.read(await h.auth(),read,f.proposalId,r.acceptanceId);
  preserve=async()=>h.proposal.read(await h.auth(),read,f.proposalId,'internal',f.versionId);check=async()=>{const rows=await h.observer`select * from crm_private.b03_acceptance_verifications where acceptance_id=${r.acceptanceId}::uuid`;assert.equal(rows.length,1);assert.equal((await h.observer`select state from crm_private.b03_opportunities where opportunity_id=${root}::uuid`)[0]!.state,'Aceptada / Ganada');assert.equal((await h.observer`select count(*)::int n from crm_private.b04_bookings where opportunity_id=${root}::uuid`)[0]!.n,0);return rows;};
 }else if(id==='T03'){
  const f=await bookingFixture(h);a=f.q;b={...a,operationId:uid(),bookingId:uid()};root=f.q.opportunityId;kind='booking';early='b04_bookings';late='b04_services';final='b04_operations';see=async()=>h.booking.read(await h.auth(),read,a.bookingId);preserve=async()=>h.proposal.read(await h.auth(),read,f.f.proposalId,'internal',f.f.versionId);check=async()=>{const rows=await h.observer`select booking_id,detail,chain_snapshot from crm_private.b04_bookings where opportunity_id=${root}::uuid`;assert.equal(rows.length,1);assert.deepEqual(rows[0]!.detail,f.detail);assert.equal((await h.observer`select count(*)::int n from crm_private.b04_services where booking_id=${rows[0]!.booking_id}::uuid`)[0]!.n,f.detail.services.length);return rows;};
 }else if(id==='T04'){
  const f=await modificationFixture(h);await f.run(await f.request());await f.run(await f.evaluate());await f.run(await f.approve());a=await f.apply();b={...a,operationId:uid()};root=String((await h.observer`select opportunity_id from crm_private.b04_bookings where booking_id=${f.bookingId}::uuid`)[0]!.opportunity_id);kind='modifications';early='b04_operational_versions';late='b06_modification_revisions';final='b06_modification_operations';see=f.see;preserve=async()=>h.booking.read(await h.auth(),read,f.bookingId);check=async()=>{const v=await f.see();assert.ok(v!.parts.find(p=>p.id===f.partId)!.applied);assert.equal((await h.observer`select count(*)::int n from crm_private.b04_operational_versions where booking_id=${f.bookingId}::uuid`)[0]!.n,1);return v;};
 }else if(id==='T05'){
  const f=await allocationFixture(h,'100.00','100.00','verified','1000.00');a=await f.assign('80.00');b=await f.assign('80.00');root='payment-root:'+f.paymentId;seed=0;kind='allocations';early='b05_allocations';late='b05_fund_history';final='b05_fund_operations';see=f.see;check=async()=>{const v=await f.see();assert.equal(v.summary.assigned,'80.00');assert.equal((await h.observer`select count(*)::int n from crm_private.b05_allocations where payment_id=${f.paymentId}::uuid`)[0]!.n,1);return v;};
 }else if(id==='T06'){
  const f=await cancellationFixture(h);a=await f.command();b={...a,operationId:uid()};root=f.b.opportunityId;kind='cancellations';early='b06_cancellation_determinations';late='b06_cancellation_revisions';final='b06_cancellation_operations';see=f.see;preserve=async()=>h.booking.read(await h.auth(),read,f.b.bookingId);check=async()=>{const v=await f.see();assert.ok(v);assert.equal(v!.revision,1);return v;};
 }else if(id==='T07'){
  const f=await refundFixture(h,'100.00');await f.run(await f.determine());await(await f.approval(await f.authorization('100.00'))).execute();a=await f.movement('80.00');b=await f.movement('80.00');root=f.c.b.opportunityId;kind='refunds';early='b05_refund_movements';late='b05_refund_revisions';final='b05_refund_operations';see=f.view;preserve=async()=>h.booking.read(await h.auth(),read,f.bid);check=async()=>{const v=await f.view();assert.equal(v!.executed,'80.00');assert.equal(v!.movements.length,1);return v;};
 }else if(id==='T10'){
  const f=await fixture(h,false);a=await f.j.command();b=await f.j.command({reason:'SYNTHETIC another explicit close'});root='booking-preparation:'+f.bookingId;seed=0;kind='closures';method='close';early='b06_joint_closures';late='b06_joint_closures';final='b06_closure_operations';see=f.j.c.view;const v=await h.booking.read(await h.auth(),read,f.bookingId);preserve=async()=>h.booking.read(await h.auth(),read,f.bookingId);check=async()=>{const c=await f.j.c.view();assert.equal(c.jointClosure.history.length,1);assert.equal(c.jointClosure.current,true);assert.deepEqual(await preserve(),v);return c;};
 }else if(id==='T11'){
  const x=uid(),y=uid();for(const targetId of [x,y])await h.identities.apply(await h.auth(),write,{action:'create_entity',operationId:uid(),targetId,kind:'contact',expectedVersion:0,sourceRef:'SYNTHETIC identity source',evidenceRef:'SYNTHETIC verified source',reason:'SYNTHETIC human creates identity',verified:true,displayName:'SYNTHETIC H6016 Contact'});
  a={action:'merge',operationId:uid(),targetId:x,relatedId:y,kind:'contact',expectedVersion:0,sourceRef:'SYNTHETIC explicit human resolution',evidenceRef:'SYNTHETIC resolution record',reason:'SYNTHETIC same person verified by human'};b={...a,operationId:uid(),action:'archive',relatedId:undefined};kind='resolution';early='identity_entities';late='identity_history';final='identity_operations';gate=async(tx:any)=>tx`select identity_id from crm_private.identity_entities where identity_id=${x}::uuid for update`;see=async()=>h.observer`select to_jsonb(e) row from crm_private.identity_entities e where identity_id in(${x}::uuid,${y}::uuid) order by identity_id`;check=async()=>{const rows=await see();assert.equal(rows.length,2);assert.equal(Number(rows.find((r:any)=>r.row.identity_id===x).row.version),1);return rows;};
 }else throw new Error('H6016_UNIT_NOT_IMPLEMENTED:'+id);
 if(!gate)gate=async(tx:any)=>tx`select pg_advisory_xact_lock(hashtextextended(${root},${seed}))`;
 for(const table of [early,late,final])assert.equal((await h.observer`select to_regclass(${'crm_private.'+table}) t`)[0]!.t!==null,true,'H6016 real table '+table);
 return {id,a,b,gate,early,late,final,execute:(q,who)=>run(h,kind,q,who,method),see,check,preserve};
}
export async function injected(h:H,u:Unit,point:'F0'|'F1'|'F2'){
 const table=point==='F0'?u.early:point==='F1'?u.late:u.final;assert.match(table,/^[a-z0-9_]+$/);const schema='crm_private';
 await h.admin.unsafe(`create sequence ${schema}.h6016_fault_witness;create function ${schema}.h6016_fault()returns trigger language plpgsql security definer set search_path=pg_catalog,pg_temp as $$begin perform nextval('${schema}.h6016_fault_witness');raise exception 'H6016_INJECTED_${point}';return new;end$$`);
 await h.admin.unsafe(point==='F2'?`create constraint trigger h6016_fault after insert or update on ${schema}.${table} deferrable initially deferred for each row execute function ${schema}.h6016_fault()`:`create trigger h6016_fault ${point==='F1'?'after':'before'} insert or update on ${schema}.${table} for each row execute function ${schema}.h6016_fault()`);
 return {reached:async()=>Boolean((await h.admin`select is_called from crm_private.h6016_fault_witness`)[0]!.is_called),clear:()=>h.admin.unsafe(`drop trigger h6016_fault on ${schema}.${table};drop function ${schema}.h6016_fault();drop sequence ${schema}.h6016_fault_witness`)};
}
export async function interleave(h:H,u:Unit,order:0|1,independent?:Unit){
 const first=await actor(h),second=await actor(h),third=independent?await actor(h):undefined,guard=h.connect('crm_h0_migration'),monitor=h.connect('h2_bootstrap');let release!:()=>void,entered!:()=>void;const ready=new Promise<void>(r=>entered=r),unlock=new Promise<void>(r=>release=r);
 const held=guard.begin(async(tx:any)=>{await u.gate(tx);entered();await unlock;});await ready;let fault:any,locks:any,other:any;const jobs:Promise<any>[]=[];const commands=order?[u.b,u.a]:[u.a,u.b];
 const waiting=async()=>Number((await monitor`select count(*)::int n from pg_stat_activity where datname=current_database()and usename='crm_h0_runtime'and wait_event_type='Lock'`)[0]!.n);
 try{
  jobs.push(u.execute(commands[0],first));jobs[0]!.catch(()=>{});await waitFor(async()=>await waiting()>=1);
  jobs.push(u.execute(commands[1],second));jobs[1]!.catch(()=>{});await waitFor(async()=>await waiting()>=2);
  locks=await monitor`select pid,usename,wait_event_type,wait_event,pg_blocking_pids(pid) blockers from pg_stat_activity where datname=current_database() and (wait_event_type='Lock' or cardinality(pg_blocking_pids(pid))>0) order by pid`;
  if(independent&&third){await independent.execute(independent.a,third);other=await independent.check();assert.ok(await waiting()>=2);}
 }catch(e){fault=e;}finally{release();await held;}
 const rs=await Promise.allSettled(jobs);await Promise.all([first.close(),second.close(),...(third?[third.close()]:[]),guard.end({timeout:1}),monitor.end({timeout:1})]);if(fault)throw fault;
 assert.equal(rs[0]!.status,'fulfilled','first queued valid unit completes');assert.ok(rs.every(r=>r.status==='fulfilled'||/CONFLICT|REVISION|ALREADY|INSUFFICIENT|REVIEW|VERSION|SCOPE|DENIED/.test(String(r.reason))));const observed=await u.check();await capture(u.id+'-R'+order,{locks,results:rs.map(r=>r.status==='fulfilled'?{status:r.status,result:r.value}:{status:r.status,error:String(r.reason)}),observed,independent:other});return rs;
}
