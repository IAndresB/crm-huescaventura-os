# TSK-H6-016 — Expected independiente previo al candidato

Base `9c15e6d143822f7fcc84f29744194554630f4ac4`, árbol `fe7cabb05e44462121c70ad52405765e2c94fcd2`. Preflight `c492f6fc07dc7c264fec6e953c4472ae10d9fcc1a37bfda2e143906903ff2559`. No se ha leído código nuevo H6-016 ni ejecutado SQL/pruebas. Autorización actual local/aislada con cierre condicionado; no modifica los textos históricos.

Se acreditan documentalmente las seis dependencias. H6-007 se incorpora expresamente desde su candidato local138 y master455, verificados íntegramente; no se presume incluido enGit ni se publica. La norma prevalece sobre helpers, preparación previa y resultados de código.

## 25 asignaciones exactas de Tasks §6

| Asignación | Línea Tasks | Expected independiente |
|---|---:|---|
| SPEC-FR-CONC-001 | 2783 | Versiones obsoletas y reevaluación: T01/T02/T04/T06/T10; O1–O3 yF5, sin overwrite. |
| SPEC-FR-CONC-002 | 2784 | Incompatibles sobre misma versión/Opportunity/fondos/Approval: T01–T03/T05/T07/T08 con raíz compartida. |
| SPEC-FR-CONC-003 | 2785 | Todo-o-nada de hecho/historia/resultado/intención aplicables enT01–T11; F1–F4. |
| AC-067 | 2875 | Dos lecturas de v1 y sustitución/cambio material: competidor obsoleto conflictúa o revisión, historia intacta. |
| AC-068 | 2876 | Booking, conciliación e intención asociada frente a fallo: ninguna unidad parcial; preparación previa separada. |
| SPEC-NFR-007 | 2907 | Coherencia concurrente de versiones, Booking, porciones y aprobación; jobs/eventos no eximen serialización. |
| ARCH-DEC-014 | 3182 | Atomicidad interna y consistencia eventual externa separadas; sin transacción distribuida ni éxito por intención. |
| PLAN-DEC-004 | 3215 | Versión/uniquidad/serialización corta de raíz común incluso sin hijos; ordenestable, sin locks distribuidos. |
| PLAN-DEC-008 | 3219 | Dominio determinista, contratos y persistencia/permiso/concurrencia reales; dobles solo externos. |
| PLAN-B10 | 3230 | Trazabilidad, integridad y límites del ensayo; no acreditar despliegue/Production ni recuperación H6-015. |
| PLAN-C03 | 3233 | Contexto confiable y unidad atómica; TTE paraHA, M02/M04 juntos cuando aplican. |
| PLAN-T01 | 3237 | Versión nueva, composición/términos/snapshots, preparación y sustitución forman unidad; antigua intacta, numeración única y conflicto de preparación obsoleta; fijar no envía. |
| PLAN-T02 | 3238 | Identidad y términos conservados; verificación y Ganada solo cuando se solicitan y satisfacen SM; candidata ambigua en revisión. No Acceptance del contenido sustituido silenciosamente ni conversión implícita. |
| PLAN-T03 | 3239 | Una Booking V1 completa con cadena comercial, modalidades/servicios/noches/cantidades/referencias; identidad estable recupera resultado; preparación válida previa puede existir sin fingir conversión. |
| PLAN-T04 | 3240 | Solo efecto autorizado con antes/después/evidencia/revisión; reevaluación material correspondiente; otra noche/servicio y aspectos no cubiertos permanecen intactos. |
| PLAN-T05 | 3241 | Porciones/destinos/cobertura coherentes; nunca 80+80 sobre100 ni doble consumo por canales distintos. Se protege raíz agregada, no solo hijos; nada acredita transferencia real. |
| PLAN-T06 | 3242 | D019/D020 conservados con fuente/momento: reevaluar fundamento obsoleto, no cero ni prorrateo inventado. Efecto operativo independiente puede coexistir con economía pendiente explícita; unidad material acotada, no transacción gigante. |
| PLAN-T07 | 3243 | Hecho verificado, porciones, ajustes y reevaluación juntos; devolución representada en Refund/Deposit no se duplica. Movimiento real sintético precede registro, anomalía revisada sin aprobación retroactiva. |
| PLAN-T08 | 3244 | Una parte no se reserva dos veces; historia aprobada preservada, reserva incierta no se libera. TTE exclusivo controla unidad M02/M04 y final check tras esperas antes de iniciar COMMIT, sin devolución de control; no deadline físico de durabilidad. |
| PLAN-T09 | 3245 | Evento/evidencia y deduplicación o claim exclusivo persisten atómicamente. Recepción no es aplicación, claim no es ejecución. Lease vencido y efecto posible requieren contraste del intento exacto antes de reenviar; sin tocar trabajos H6-015. |
| PLAN-T10 | 3246 | No cierre vigente sobre fundamento concurrentemente obsoleto. Evidencia posterior invalida solo dimensión afectada, retira vigencia conjunta y preserva cierre/causa/Acceptance/ejecución. Reparar insumo no resucita cierre; nueva evaluación/cierre explícitos. |
| PLAN-T11 | 3247 | Ambos historiales y referencias/códigos se preservan; no reatribución de hechos, liberación/reutilización de código ni fusión Opportunities/Bookings. Vista vigente separada de original; archivo no acredita cierre. |
| PT-12 | 3264 | Subalcance integrado eventos/versiones/atomicidad/jobs/incertidumbre; no extensión arestauración/Hosted/Avaibook real. |
| G6 | 3307 | Repetición de evidencia/resultado no duplica; incertidumbre pendiente de verificar, no retry peligroso. |
| E2 | 3309 | Misma clave distinto material o versión cambiada: conflicto trazable con preservación y reevaluación. |

## Unidades y controles

| Unidad | Raíz material | Competencia | Expected |
|---|---|---|---|
| T01 | Preparación/versionado comercial | Fijación frente a cambio o fijación competidora desde la misma base | Versión nueva, composición/términos/snapshots, preparación y sustitución forman unidad; antigua intacta, numeración única y conflicto de preparación obsoleta; fijar no envía. |
| T02 | Acceptance, versión exacta y contexto comercial | Registro/verificación frente a sustitución/repetición/concurrencia material | Identidad y términos conservados; verificación y Ganada solo cuando se solicitan y satisfacen SM; candidata ambigua en revisión. No Acceptance del contenido sustituido silenciosamente ni conversión implícita. |
| T03 | Opportunity compartida, inicialmente sin Booking hija | Conversión normal/directa y reintento sobre la misma Opportunity | Una Booking V1 completa con cadena comercial, modalidades/servicios/noches/cantidades/referencias; identidad estable recupera resultado; preparación válida previa puede existir sin fingir conversión. |
| T04 | Alcance de servicio/noche y raíz Booking pertinente | Cambio operativo frente a confirmación/revalidación/cambio del mismo alcance | Solo efecto autorizado con antes/después/evidencia/revisión; reevaluación material correspondiente; otra noche/servicio y aspectos no cubiertos permanecen intactos. |
| T05 | Movimiento y fondo compartido, incluidas asignaciones inicialmente ausentes | Conciliación/asignación/ajuste frente a otro consumo y Refund | Porciones/destinos/cobertura coherentes; nunca 80+80 sobre100 ni doble consumo por canales distintos. Se protege raíz agregada, no solo hijos; nada acredita transferencia real. |
| T06 | Modificación, base atribuible y alcance material | Determinación/aplicación frente a cambio de base o aprobación | D019/D020 conservados con fuente/momento: reevaluar fundamento obsoleto, no cero ni prorrateo inventado. Efecto operativo independiente puede coexistir con economía pendiente explícita; unidad material acotada, no transacción gigante. |
| T07 | Movimiento económico acreditado y referencias/porciones comunes | Registro Provider Payment/Refund/fianza frente a duplicado o consumo competidor | Hecho verificado, porciones, ajustes y reevaluación juntos; devolución representada en Refund/Deposit no se duplica. Movimiento real sintético precede registro, anomalía revisada sin aprobación retroactiva. |
| T08 | Human Approval exacta, parte/efecto e intención | Reserva/consumo frente a competidor, cambio material o revocación durante espera | Una parte no se reserva dos veces; historia aprobada preservada, reserva incierta no se libera. TTE exclusivo controla unidad M02/M04 y final check tras esperas antes de iniciar COMMIT, sin devolución de control; no deadline físico de durabilidad. |
| T09 | Identidad de recepción/contexto o trabajo/generación de intento | Recepciones duplicadas/antiguas/conflictivas y dos ejecutores reclamando | Evento/evidencia y deduplicación o claim exclusivo persisten atómicamente. Recepción no es aplicación, claim no es ejecución. Lease vencido y efecto posible requieren contraste del intento exacto antes de reenviar; sin tocar trabajos H6-015. |
| T10 | Booking compartida por cierre y escritores de insumos | Cierre frente a factura, Refund e Incident, en ambas ordenaciones | No cierre vigente sobre fundamento concurrentemente obsoleto. Evidencia posterior invalida solo dimensión afectada, retira vigencia conjunta y preserva cierre/causa/Acceptance/ejecución. Reparar insumo no resucita cierre; nueva evaluación/cierre explícitos. |
| T11 | Identidades/orígenes, vínculos y códigos | Fusión/archivo/corrección humana frente a resolución o escritura competidora | Ambos historiales y referencias/códigos se preservan; no reatribución de hechos, liberación/reutilización de código ni fusión Opportunities/Bookings. Vista vigente separada de original; archivo no acredita cierre. |

Cada unidad debe tener correspondencia paraO1–O3/F1–F5; son88 posiciones de cobertura, no88 tests exigidos nominalmente. No aplica debe justificarse contra contrato y quedar visible; un agregado sinaserción específica no pasa. Hijos ausentes y guardas aplican donde protegen elinvariante.

| Eje | Expected |
|---|---|
| O1 — A→B | Ejecutar primero A y después B sobre la misma base material pertinente; reconocer resultado/conflicto conforme al contrato y preservar ganador/historia. |
| O2 — B→A | Orden inverso con mismo conflicto material; no inferir simetría del código ni de O1. |
| O3 — Solapamiento real | Conexiones/actores efectivos distintos, barrera observable PostgreSQL y orden demostrado; Promise.all o sleep solos no acreditan carrera. |
| F1 — Antes de escritura | Fallo alcanzado antes de la primera mutación sensible; no unidad parcial, conserva preparación previa legítima y estado ajeno. |
| F2 — Entre escrituras / antes de COMMIT | Fallo tras entrar en unidad material, incluyendo historia/resultado/intención aplicables; todo rollback. Identificar frontera física antes de inyectar. |
| F3 — Durante COMMIT | Error diferido real o frontera equivalente justificada, con testigo de haberla alcanzado; rechazo de permiso/admisión no prueba COMMIT. |
| F4 — Respuesta perdida tras COMMIT | Comprobar resultado durable e historia por identidad antes de replay equivalente; una sola mutación/intención/efecto, sin asumir rollback ni contactar otra vez proveedor. |
| F5 — Conflicto de identidad/material | Clave repetida con material/alcance distinto produce E2; misma identidad equivalente devuelve resultado reautorizado sin otra transición. |

## 15 controles transversales

| ID | Control | Expected |
|---|---|---|
| X01 | Base, seis dependencias y composición | Base9c15e6d/treefe7cabb exactos; H5-019/H6-013/001/004/006 aceptados en base y H6-007 candidato local expresamente incorporado por hashes. Aceptación previa no es prueba integrada H6-016. |
| X02 | Oráculo previo y cobertura | 25 asignaciones y11 unidades trazadas a casos exactos; las88 posiciones O1–O3/F1–F5 son matriz de cobertura, no promesa de88 tests físicos. Una prueba puede cubrir varias posiciones solo con aserciones observables; no rellenar PASS por nombre de suite. |
| X03 | Hijos ausentes y raíz agregada | Ejercitar situación inicial sin hijos en las invariantes aplicables: Booking, asignaciones/porciones, reservas/consumos, recepción/claim y códigos; justificar No aplica por contrato, no por comodidad. |
| X04 | Persistencia y construcción legítimas | Aplicación real y PostgreSQL real, cadena68 fijada. No sembrar arbitrariamente estados de negocio para pasar guardas. DDL/observers solo instrumentación local efímera identificada; sin ampliación de permisos de producto. |
| X05 | Contexto, pool y roles | Sin contexto, contexto falsificado, actor inhabilitado, rol ordinario y SQL directo denegados sin efectos/divulgación. Reutilizar conexión/pool real para probar que no hereda identidad/finalidad; no simularlo con objetos de repositorio. |
| X06 | Reautorización del resultado | Replay committed también requiere permisos actuales; revocación no entrega resultado protegido. Nuevo actor/sesión no hereda contexto anterior y polling no crea actividad humana. |
| X07 | Unidad atómica | Por frontera, comprobar hecho/vínculos, historia, resultado e intención aplicables; no basta observar excepción. Se preservan otros expedientes, dimensiones, porciones y preparación legítima. |
| X08 | D039 / M1-M2 | Runtime no posee facultad directa/indirecta de cerrar HA; login/pool TTE distinto, binding real de transacción, F1/F2 separados, final check obligatorio después de espera/trabajo y antes de COMMIT. No reabrir criptografía, ventanas ni autoridad aprobada. |
| X09 | Incertidumbre y externos | Proveedor sintético con estado propio si se acredita contacto/resultado; intención, intento y ejecución separados. Sin efecto real, integración real, transacción distribuida ni exactly-once externo; E4 no se convierte en E5 por una excepción. |
| X10 | Dependencia y progreso independiente | Mientras una raíz espera o fuente falta, otra raíz autorizada progresa con sesión pertinente distinta. No confundir bloqueo F2 de la misma sesión con conflicto de Booking. Ausencia de dato bloquea solo lo dependiente. |
| X11 | Historia y semántica | Originales, versiones, Acceptance, confirmaciones, causas, actor/momentos, cantidades/noches, código y componentes económicos reconstruibles. Éxito técnico no crea transición o nueva aceptación de negocio. |
| X12 | Negativos normativos | Aplicar SM-FORB/G1–G6 pertinentes a cada composición; el enlace Tasks§6.5 es real prohibiciones, no tabla T01–T11 (Tasks§6.7/Plan§7.2). Registrar discrepancia documental sin corregir norma. |
| X13 | Regresión proporcional | Producto corregido implica regresión dirigida al delta y contratos dependientes; si cambia persistencia, V-MIG fresh/upgrade y permisos. Sin cambios de producto, integrar selectivamente antecedentes por identidad y ejecutar lo necesario para cobertura actual; nunca transferir PASS histórico automáticamente. |
| X14 | Evidencia y cierre | Fuentes exactas antes de ejecución, versiones/comandos/datos sintéticos, logs crudos, expected/observed, fallos y sucesores; separar casos únicos y repeticiones. Cierre local condicionado a todosPASS+auditoría+custodia; H6 global IN PROGRESS, paquete final recibido aparte. |
| X15 | Fronteras reservadas | Nada de H6-015 runtime/S11 ni sus cuatro trabajos suspendidos, datos/credenciales reales, efectos de negocio externos, nuevas normas/seguridad, stage/commit/push/Drive/despliegue. Bloquear solo operación que cruce frontera, continuar partes independientes. |

## Contrapruebas propias previstas

- Q01 (T01/T02): Same stale preparation/version used by competing fix/Acceptance; old version unchanged; conflict plus replay and no implicit conversion.
- Q02 (T03): Initially absent Booking child and competing normal/direct or equivalent conversions; one complete chain, rollback fault and lost-response recovery.
- Q03 (T05/T07): 100.00 shared funds with80.00 contenders including Refund, both orders and true overlap; common Refund/Deposit movement identity cannot duplicate.
- Q04 (T04/T06): Change one night/scope while determined economics or approved material becomes stale; independent scope retained, insufficient amount stays pending.
- Q05 (T08): TTE waits while authority/evidence loses validity; last mandatory check rejects and unit rolls back; committed replay does not refresh provider/evidence.
- Q06 (T09): Two actual claimants/new attempt generation and durable synthetic provider outcome after lost reply; expired lease does not authorize duplicate effect.
- Q07 (T10): Close against invoice/Refund/Incident with missing/new child input and both orders; affected dimension only, old close retained, other Booking progress.
- Q08 (T11/X05): Identity resolution/code/history under contention and physical pool reuse by authorized/disabled/forged contexts; no inherited privilege or historical deletion.

No hay autorización de carreras aún: se coordinarán bases propias, puertos/TMPDIR exclusivos, roles y sesiones distintas; ninguna escritura del auditor en el candidato ni paquetes previos. Solo fuentes publicadas exactas y pruebas nuevas propias tras el aviso. La selección crítica podrá agrupar subcasos con trazabilidad, nunca sustituir un expected por el comportamiento observado.

same-model separate agent, normative expected frozen before new candidate code; own instrument/assertions and future isolated PostgreSQL; published fixtures may be reused by exact identity

Estado: **EXPECTED CONGELADO / PRUEBAS NO EJECUTADAS**. El PASS documental de dependencias no es un dictamen funcional H6-016. H6 global permanece IN PROGRESS.
