from pathlib import Path
import hashlib,json,subprocess,stat,datetime,re
B=Path(__file__).resolve().parent;R=Path('/Users/andres/.codex/worktrees/h6-016-local/crm-huescaventura-os');L=Path('/Users/andres/.codex/worktrees/h6-007-local');BASE='9c15e6d143822f7fcc84f29744194554630f4ac4';TREE='fe7cabb05e44462121c70ad52405765e2c94fcd2'
H=lambda x:hashlib.sha256(x).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==BASE
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip()==TREE
assert subprocess.run(['git','diff','--cached','--quiet'],cwd=R).returncode==0
paths=['README.md','docs/constitution.md','docs/DECISIONS.md','docs/architecture.md','docs/state-machines.md','docs/domain-model.md','docs/business-rules.md','docs/product.md','specs/001-core-crm/spec.md','specs/001-core-crm/plan.md','specs/001-core-crm/tasks.md','specs/001-core-crm/acceptance-TSK-H5-019.md','specs/001-core-crm/closure-TSK-H5-019.md','specs/001-core-crm/matrix-TSK-H5-019-corrective.md','specs/001-core-crm/acceptance-TSK-H6-013.md','specs/001-core-crm/acceptance-TSK-H6-001-local.md','specs/001-core-crm/acceptance-TSK-H6-004.md','specs/001-core-crm/acceptance-TSK-H6-006-local.md','specs/001-core-crm/independent-review-TSK-H6-006.md']
records=[]
for name in paths:
 raw=subprocess.check_output(['git','show',BASE+':'+name],cwd=R);assert (R/name).read_bytes()==raw
 p=B/'normative-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o444)
 records.append({'path':name,'bytes':len(raw),'sha256':H(raw),'blob':subprocess.check_output(['git','rev-parse',BASE+':'+name],cwd=R,text=True).strip()})
seals=[('H5-019','tests/fixtures/h5-019-corrective/candidate-seal.json','31fd4ac89aea684f2155a4365cb5870a0c0163838cbfd543d2ad98d0db1ea619'),('H6-013','tests/fixtures/h6-013/candidate-manifest-corrective-v2.json','34442d96a59c492771d65ff4bf19c6aa8961192dbcf9b7621d6276bdb61a0c06'),('H6-001','tests/fixtures/h6-001/delivery-manifest-v1.json','d97ab86cd4d78c001f5a5e29f3ce501c0c6b44cf592a7b22e78589c26569c435'),('H6-004','tests/fixtures/h6-004/delivery-manifest-v1.json','5098ce5099400c23c5728e302a99f94b9c945faff065dd7ebd2e12747f76495a'),('H6-006','tests/fixtures/h6-local-validation/delivery-manifest.json','cea8c91910000d89a075401cbed60322ff71abccf5f7ba39569d188956bcd627')]
dependencies=[]
for task,path,expected in seals:
 raw=(R/path).read_bytes();assert H(raw)==expected,(task,H(raw));assert subprocess.check_output(['git','show',BASE+':'+path],cwd=R)==raw
 p=B/'dependency-source'/'published'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);p.chmod(0o444);dependencies.append({'task':task,'scope':'COMPLETED local/isolated documentary acceptance in published base','path':path,'sha256':H(raw),'bytes':len(raw),'newFunctionalExecution':False})
for name,expected,root in [('local-final-candidate-v1.json','4aeb3d83e685bc1282ab1eb536c9665d2ab3e1243459214ace1ed2ed839c7e91',L/'crm-huescaventura-os'),('receipts-master-manifest-v1.json','56dbe40105e6bc2b4f3d90dc0389ee6b50b1df696dd4a3f56694fd226502b493',L/'receipts')]:
 p=L/'receipts'/name;raw=p.read_bytes();assert H(raw)==expected;d=json.loads(raw);checked=[]
 for f in d['files']:
  q=root/f['path'];z=q.read_bytes();assert not q.is_symlink();assert len(z)==f['bytes'] and H(z)==f['sha256'],f['path']
  actualMode=stat.S_IMODE(q.stat().st_mode)
  if 'mode' in f:assert actualMode==int(f['mode'],8),(f['path'],oct(actualMode),f['mode'])
  if 'gitMode' in f:assert ('100755' if actualMode&0o111 else '100644')==f['gitMode']
  checked.append({'path':f['path'],'bytes':len(z),'sha256':H(z)})
 dest=B/'dependency-source'/'local-H6-007'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);dest.chmod(0o444)
 dependencies.append({'task':'H6-007','manifest':name,'sha256':H(raw),'payloadCount':len(checked),'payloadBytes':sum(x['bytes'] for x in checked),'allPayloadsVerified':True,'publicationStatus':'explicitly incorporated local candidate, not part of Git base','newFunctionalExecution':False})
for name in ['specs/001-core-crm/acceptance-TSK-H6-007-local.md','specs/001-core-crm/preparation-TSK-H6-016-after-H6-007.md','tests/fixtures/h6-007-local-acceptance/H6016-dependency-binding-v1.json']:
 p=L/'receipts'/'acceptance-source-snapshot-v1'/name;raw=p.read_bytes();dest=B/'dependency-source'/'local-H6-007'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw);dest.chmod(0o444)
 records.append({'source':'local-H6-007 acceptance capsule','path':name,'bytes':len(raw),'sha256':H(raw)})
text=(B/'normative-source/specs/001-core-crm/tasks.md').read_text();assignments=[]
for n,line in enumerate(text.splitlines(),1):
 if line.startswith('| **') and '[TSK-H6-016]' in line:
  key=re.search(r'^\| \*\*([^*]+)\*\*',line)[1];assignments.append({'id':key,'tasksLine':n,'literal':line})
assert len(assignments)==25,len(assignments)
inputs=[]
for folder in ['src','supabase/migrations']:
 for p in sorted((R/folder).rglob('*')):
  if not p.is_file():continue
  name=str(p.relative_to(R));raw=p.read_bytes();assert subprocess.check_output(['git','show',BASE+':'+name],cwd=R)==raw
  inputs.append({'path':name,'bytes':len(raw),'sha256':H(raw)})
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_DOCUMENTARY_PREFLIGHT','base':BASE,'tree':TREE,'sources':records,'dependencies':dependencies,'assignments':assignments,'productAndMigrations':inputs,'newCandidateCodeRead':False,'functionalTestsStarted':False,'writes':'only own /tmp/h6-016-independent','limits':'dependency acceptance is local/isolated; no H6-wide, Hosted or Production transfer; historic NOT STARTED/publication pending retained in dated source'}
p=B/'preflight-frozen-v1.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');p.chmod(0o444)
print(json.dumps({'status':result['status'],'sources':len(records),'assignments':len(assignments),'productAndMigrations':len(inputs),'H6007':[{k:v for k,v in x.items() if k in ['manifest','payloadCount','payloadBytes','allPayloadsVerified']} for x in dependencies if x['task']=='H6-007'],'sha256':H(p.read_bytes())},indent=2))
