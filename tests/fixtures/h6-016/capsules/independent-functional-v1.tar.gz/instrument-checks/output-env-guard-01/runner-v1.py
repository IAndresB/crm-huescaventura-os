#!/usr/bin/env python3
"""Independent bounded runner. A prepared local software cache is mandatory.
Never fetches dependencies and never inherits ambient auth/provider variables.
Each run has immutable input snapshots and unmodified stdout/stderr.
"""
import argparse,hashlib,json,os,pathlib,re,subprocess,sys,time
from datetime import datetime,timezone
A=pathlib.Path(__file__).resolve().parents[1];R=A/'replica'
parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);parser.add_argument('--test-file',action='append',required=True);parser.add_argument('--output-env',action='append',default=[]);args=parser.parse_args()
assert re.fullmatch('[a-z0-9-]+',args.label)
for p in args.test_file:
 assert re.fullmatch('[a-z0-9-]+[.]test[.]ts',p) and (R/'tests/integration'/p).is_file(),p
for k in args.output_env:assert re.fullmatch('H6016_[A-Z_]+',k),k
BIN=pathlib.Path('/Users/andres/Applications/Postgres.app/Contents/Versions/17/bin');NODE=pathlib.Path('/Users/andres/.openclaw/bin/node')
rt=A/'runtime';rt.mkdir(exist_ok=True,mode=0o700)
cache=rt/'crm-supabase-storage-5def1dfc15ab7f08fe271c7d1e70542424524e4e'
assert (cache/'dist/start/server.js').is_file(),'PREPARED_SOFTWARE_CACHE_REQUIRED_NO_NETWORK_FALLBACK'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=cache,text=True).strip()=='5def1dfc15ab7f08fe271c7d1e70542424524e4e'
assert subprocess.run(['git','diff','--quiet'],cwd=cache).returncode==0
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ');out=A/'runs'/(args.label+'-'+stamp);out.mkdir(parents=True);observed=out/'observed';observed.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest();members=[]
for root in ['src','supabase/migrations','tests/support','tests/integration','scripts']:
 d=R/root
 if not d.exists():continue
 for p in sorted(d.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(R);data=p.read_bytes();dest=out/'source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  members.append({'path':str(rel),'sha256':sha(data),'bytes':len(data)})
inputs={'at':datetime.now(timezone.utc).isoformat(),'base':'9c15e6d143822f7fcc84f29744194554630f4ac4','files':members,'frozenExpectedSHA256':sha((A/'expected-independent-v1.json').read_bytes()),'runnerSHA256':sha(pathlib.Path(__file__).read_bytes()),'selectedFiles':args.test_file}
(out/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
env={'PATH':str(NODE.parent)+':/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':str(rt),'LANG':'C','LC_ALL':'C','POSTGRES_H0_BIN':str(BIN),'NODE_NO_WARNINGS':'1','CI':'1','H6016_AUDIT_OBSERVATIONS':str(observed),'H4012_CORRECTIVE44':'1','H4016_CORRECTIVE47':'1','H4018_CURRENT48':'1'}
for k in args.output_env:env[k]=str(out)
cmd=[str(NODE),'scripts/test-postgres.mjs',*args.test_file]
started=datetime.now(timezone.utc).isoformat();print(json.dumps({'startedAt':started,'run':str(out),'selectedFiles':args.test_file}),flush=True)
with (out/'stdout.log').open('wb') as stdout,(out/'stderr.log').open('wb') as stderr:
 r=subprocess.run(cmd,cwd=R,env=env,stdout=stdout,stderr=stderr)
text=(out/'stdout.log').read_text(errors='replace');counts={}
for key in ['tests','suites','pass','fail','cancelled','skipped','todo']:
 found=re.findall(r'^(?:#|ℹ) '+key+r' ([0-9]+)\s*$',text,re.M)
 if found:counts[key]=int(found[-1])
status='PASS' if r.returncode==0 and counts.get('fail')==0 and counts.get('cancelled')==0 and counts.get('skipped')==0 and counts.get('pass',0)>0 else 'FAIL'
result={'startedAt':started,'finishedAt':datetime.now(timezone.utc).isoformat(),'command':cmd,'exitCode':r.returncode,'status':status,'counts':counts,'stdoutSHA256':sha((out/'stdout.log').read_bytes()),'stderrSHA256':sha((out/'stderr.log').read_bytes()),'inputsSHA256':sha((out/'inputs.json').read_bytes()),'sourceUnchangedAfter':all(sha((R/m['path']).read_bytes())==m['sha256'] for m in members),'node':subprocess.check_output([str(NODE),'--version'],text=True).strip(),'postgres':subprocess.check_output([str(BIN/'postgres'),'--version'],text=True).strip(),'scope':'REAL_LOCAL_SYNTHETIC_DATABASE_ONLY','externalBusinessEffects':False,'ambientCredentialsInherited':False}
(out/'run.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'run':str(out),**result}),flush=True);sys.exit(0 if status=='PASS' else 1)
