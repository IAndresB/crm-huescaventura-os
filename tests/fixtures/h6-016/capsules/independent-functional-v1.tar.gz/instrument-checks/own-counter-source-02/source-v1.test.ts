// Eight counterexample families authored from the independently frozen normative matrix.
// Published setup helpers are reused; these assertions, barriers and wire faults are independent.
import {before,after,afterEach,test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import {readFile,mkdtemp} from 'node:fs/promises';
import {join} from 'node:path';
import postgres from 'postgres';
import {database,person,atomic,immutableBooking,overlap,elapsed,rejected,read,write,uid} from '../support/h6-016-independent-fixtures.ts';
import {saveObservation,ownDatabaseIdentity,faultOn,loseCommitReply} from '../support/h6-016-independent-control.ts';
import {acceptanceFixture} from '../support/h2-acceptance-fixtures.ts';
import {bookingFixture} from '../support/h2-booking-fixtures.ts';
import {referenceFixture} from '../support/h5-012-reference-fixture.ts';
import {invoiceFixture} from '../support/h3-invoice-fixtures.ts';
import {confirmationFixture} from '../support/h4-confirmation-fixtures.ts';
import {modificationFixture} from '../support/h4-modification-fixtures.ts';
import {refundFixture} from '../support/h6-refund-current-fixture.ts';
import {depositFixture} from '../support/h4-deposit-fixtures.ts';
import {jointFixture} from '../support/h5-joint-closure-fixtures.ts';
import {incidentFixture} from '../support/h4-incident-fixtures.ts';
import {workFixture} from '../support/h6-016-t08-t09.ts';
import {H2009BookingAdapter} from '../../src/infrastructure/postgres/h2-booking-adapter.ts';
import {H3005AllocationAdapter} from '../../src/infrastructure/postgres/h3-allocation-adapter.ts';
import {H4015RefundAdapter} from '../../src/infrastructure/postgres/h4-refund-adapter.ts';
import {H5013ClosureAdapter} from '../../src/infrastructure/postgres/h5-closure-adapter.ts';
import {H4003IncidentAdapter} from '../../src/infrastructure/postgres/h4-incident-adapter.ts';
import {H1003ResolutionAdapter} from '../../src/infrastructure/postgres/h1-resolution-adapter.ts';
import {H0005PostgresAdapter} from '../../src/infrastructure/postgres/h0-005-adapter.ts';
import {verifyAuth} from '../../src/application/verified-auth.ts';
import {WorkCommitUncertainError} from '../../src/infrastructure/postgres/persisted-work-executor.ts';
let h:any;before(async()=>{h=await database();saveObservation('Q00-runtime',await ownDatabaseIdentity(h));});after(async()=>{await h?.close();});afterEach(async()=>{await h?.closeExecutors();});
const digest=(v:unknown)=>createHash('sha256').update(JSON.stringify(v)).digest('hex');
const materialHashes=(v:Record<string,unknown>)=>Object.fromEntries(Object.entries(v).map(([k,x])=>[k,digest(x)]));
const resultRows=(rs:PromiseSettledResult<any>[])=>rs.map(r=>r.status==='fulfilled'?{status:r.status,value:r.value}:{status:r.status,error:String(r.reason)});

test('H6016 independent Q01 stale acceptance after fixed replacement preserves original and cannot create Booking',async()=>{
 const f=await acceptanceFixture(h),stale=await f.registration(),old=await h.proposal.read(await h.auth(),read,f.proposalId,'internal',f.versionId),a=await person(h);
 try{
  const content={...f.content,terms:{...f.content.terms,version:'SYNTHETIC-Q01-v2',text:'SYNTHETIC explicitly changed conditions'}};
  await h.proposal.apply(await h.auth(),write,{action:'prepare',operationId:uid(),proposalId:f.proposalId,opportunityId:f.opp.targetId,...await f.revisions(),baseVersionId:f.versionId,reviewed:true,content,sourceRef:'SYNTHETIC independent review',reason:'SYNTHETIC explicit changed terms'});
  const fixed=await h.proposal.apply(await h.auth(),write,{action:'fix',operationId:uid(),proposalId:f.proposalId,opportunityId:f.opp.targetId,...await f.revisions(),versionId:uid(),sourceRef:'SYNTHETIC independent fix',reason:'SYNTHETIC version two'});
  const before=await atomic(h),adapter=new h.acceptance.constructor(a.sql,h.f1,h.f2);
  await assert.rejects(adapter.apply(await a.auth(),write,stale),/ACCEPTANCE_(REVISION_CONFLICT|OPPORTUNITY_CONFLICT)/);
  assert.deepEqual(await atomic(h),before);assert.deepEqual(await h.proposal.read(await a.auth(),read,f.proposalId,'internal',f.versionId),old);
  const state=await h.observer`select (select count(*)::int from crm_private.b03_acceptances where proposal_id=${f.proposalId}::uuid) acceptances,(select count(*)::int from crm_private.b04_bookings where opportunity_id=${f.opp.targetId}::uuid) bookings,(select count(*)::int from crm_private.b03_proposal_versions where proposal_id=${f.proposalId}::uuid) versions`;
  assert.deepEqual({...state[0]},{acceptances:0,bookings:0,versions:2});saveObservation('Q01',{fixed,state:Array.from(state),originalVersionPreserved:true,negativeAtomicHashes:materialHashes(before),authorizedSecondSessionPositiveRead:true});
 }finally{await a.close();}
});

test('H6016 independent Q02 normal/direct absent Booking race and three physical rollback stages plus actual COMMIT loss',async()=>{
 const records:any[]=[];
 for(const directFirst of [false,true]){
  const f=await bookingFixture(h),a=await person(h),b=await person(h);assert.equal((await h.observer`select count(*)::int n from crm_private.b04_bookings where opportunity_id=${f.q.opportunityId}::uuid`)[0].n,0);
  const normal=new H2009BookingAdapter(a.sql,h.f1,h.f2),direct=new H2009BookingAdapter(b.sql,h.f1,h.f2),q={...f.q,operationId:uid(),bookingId:uid(),route:'direct' as const};
  try{
   const actions=[()=>a.auth().then((auth:any)=>normal.apply(auth,write,f.q)),()=>b.auth().then((auth:any)=>direct.direct(auth,write,[],q))];if(directFirst)actions.reverse();
   const r=await overlap(h,f.q.opportunityId,31,actions,['crm_api.booking_apply','crm_api.booking_apply']);assert.ok(r.results.every(x=>x.status==='fulfilled'));const values=r.results.map(x=>(x as PromiseFulfilledResult<any>).value);assert.equal(values[0].id,values[1].id);assert.equal(values[1].result.existing,true);
   const rows=await h.observer`select booking_id,detail,chain_snapshot from crm_private.b04_bookings where opportunity_id=${f.q.opportunityId}::uuid`;assert.equal(rows.length,1);assert.deepEqual(rows[0].detail,f.detail);assert.equal((await h.observer`select count(*)::int n from crm_private.b04_services where booking_id=${rows[0].booking_id}::uuid`)[0].n,f.detail.services.length);
   records.push({directFirst,witness:r.witness,results:values,rows:Array.from(rows),directStages:'existing verified chain; zero new preparation stages'});
  }finally{await a.close();await b.close();}
 }
 for(const [table,kind]of [['identity_contexts','before-row'],['b04_services','after-row'],['b04_operations','deferred-commit']] as const){
  const f=await bookingFixture(h),before=await atomic(h),fault=await faultOn(h,table,kind);let witness:any;
  try{await assert.rejects(h.booking.apply(await h.auth(),write,f.q),/BOOKING_DENIED/);witness=await fault.witness();assert.deepEqual(await atomic(h),before);}finally{await fault.close();}
  const recovered=await h.booking.apply(await h.auth(),write,f.q);assert.equal(recovered.id,f.q.bookingId);records.push({table,kind,witness,rollbackHashes:materialHashes(before),recovered});
 }
 const f=await bookingFixture(h),auth=await h.auth(),relay=await loseCommitReply(h.port),sql=postgres({host:'127.0.0.1',port:relay.port,database:h.label,user:'crm_h0_runtime',max:1,prepare:false,onnotice:()=>{}}),adapter=new H2009BookingAdapter(sql as any,h.f1,h.f2);
 try{relay.arm('crm_api.booking_apply');await assert.rejects(adapter.apply(auth,write,f.q),/BOOKING_DENIED/);assert.equal(relay.witness().lostReplies,1);const durable=await immutableBooking(h,f.q.bookingId);assert.ok(durable);const before=await atomic(h),replay=await h.booking.apply(auth,write,f.q);assert.equal(replay.replayed,true);assert.deepEqual(await atomic(h),before);records.push({wire:relay.witness(),durableReadBeforeRetry:durable,replay,afterHashes:materialHashes(before)});}finally{await sql.end({timeout:1});await relay.close();}
 saveObservation('Q02',{records});
});

test('H6016 independent Q03 Refund output and Allocation share 100 and guarantee return has one canonical Refund movement',async()=>{
 const records:any[]=[];
 for(const allocationFirst of [false,true]){
  const f=await refundFixture(h,'200.00','100.00');await f.run(await f.determine());await(await f.approval(await f.authorization('80.00'))).execute();
  const move=await f.movement('80.00'),assign=await f.a.assign('80.00'),a=await person(h),b=await person(h),ra=new H4015RefundAdapter(a.sql,h.f1,h.f2),aa=new H3005AllocationAdapter(b.sql,h.f1,h.f2);
  try{const actions=[()=>a.auth().then((auth:any)=>ra.apply(auth,write,move)),()=>b.auth().then((auth:any)=>aa.apply(auth,write,assign))];const markers=['crm_api.refund_apply','crm_api.allocation_apply'];if(allocationFirst){actions.reverse();markers.reverse();}
   const r=await overlap(h,'payment-root:'+f.a.paymentId,0,actions,markers);assert.equal(r.results[0]!.status,'fulfilled');const loser=rejected(r.results[1]!,allocationFirst?/REFUND_(PORTIONS_REQUIRED|FUNDS_CONFLICT)/:/ALLOCATION_(REVISION_CONFLICT|FUNDS_CONFLICT)/);
   const rf=await f.view(),fund=await f.a.see();assert.equal(Number(rf.executed)+Number(fund.summary.assigned),80);assert.equal(rf.executed,allocationFirst?'0.00':'80.00');assert.equal(fund.summary.assigned,allocationFirst?'80.00':'0.00');records.push({allocationFirst,validInitialObligation:'100.00',availableFund:'100.00',witness:r.witness,loser,refund:rf,funds:fund});
  }finally{await a.close();await b.close();}
 }
 const d=await depositFixture(h);await d.initialize();await d.run(await d.delivery());await d.run(await d.evaluate());await(await d.approval(await d.determination('0.00'))).execute();const q=await d.fact('return','30.00','0.00');await d.run(q);const v=await d.view(),rf=await h.refunds.read(await h.auth(),read,d.bid,v.refundId);assert.equal(v.amounts.returned,'30.00');assert.equal(rf.executed,'30.00');const rows=await h.observer`select movement_id,refund_id,material from crm_private.b05_refund_movements where refund_id=${v.refundId}::uuid`;assert.equal(rows.length,1);assert.equal(v.returns[0].movementId,rows[0].movement_id);
 const replay=await h.refunds.applyGuarantee(await h.auth(),write,{...q,operationId:uid()});assert.equal(replay.replayed,true);assert.equal((await d.view()).amounts.returned,'30.00');const changed=await d.attest({...q,operationId:uid(),fact:{...q.fact!,amount:'31.00'}});const before=await atomic(h);await assert.rejects(d.run(changed),/DEPOSIT_FACT_CONFLICT/);assert.deepEqual(await atomic(h),before);
 saveObservation('Q03',{records,guarantee:{deposit:v,refund:rf,canonicalRows:Array.from(rows),oppositeFacadeReplay:replay,conflictAtomicHashes:materialHashes(before)}});
});

test('H6016 independent Q04 an actual night change invalidates previously usable confirmation and preserves unrelated nights',async()=>{
 const b=await referenceFixture(h);await h.booking.apply(await h.auth(),write,b.q);const auxiliary=await invoiceFixture(h),s=b.detail.services[2]!,night=s.nights[0]!;
 const f=await confirmationFixture(h,{...auxiliary,bookingId:b.q.bookingId,b:{...auxiliary.b,q:b.q,detail:b.detail}} as any,2);
 const coverage={...f.coverage,nightId:night.id,date:night.date,quantity:'10',commercialBasis:{...f.coverage.commercialBasis,contributions:f.coverage.commercialBasis.contributions.filter((c:any)=>night.contributionIds.includes(c.id))}};
 assert.equal(coverage.commercialBasis.contributions.length,1);await f.apply(await f.register({coverage}));await f.apply(await f.evaluate({coverage}));const confirmed=await f.assess();assert.equal(confirmed.usable,true,'baseline confirmation must actually be usable');
 const historicalFact=(await f.state())!.fact,staleEvaluation=await f.evaluate({coverage}),m=await modificationFixture(h,f),origin=await immutableBooking(h,b.q.bookingId);
 const others=async()=>({nights:Array.from(await h.observer`select to_jsonb(n) row from crm_private.b04_nights n where booking_id=${b.q.bookingId}::uuid and night_id<>${night.id}::uuid order by night_id`),services:Array.from(await h.observer`select to_jsonb(s) row from crm_private.b04_services s where booking_id=${b.q.bookingId}::uuid and service_id<>${s.id}::uuid order by service_id`)});const otherBefore=await others();assert.equal(otherBefore.nights.length,2);assert.equal(otherBefore.services.length,2);
 await m.run(await m.request([{id:m.partId,scope:{kind:'night',id:night.id,serviceId:s.id},expectedScopeRevision:1,desired:{date:'2026-11-21'},aspects:['date','capacity','conditions'],dependencies:[]}]));await m.run(await m.evaluate());await m.run(await m.approve());const application=await m.apply();await m.run(application);
 const before=await atomic(h);await assert.rejects(f.apply(staleEvaluation),/CONFIRMATION_(SCOPE_REQUIRED|EVALUATION_CONFLICT|REVISION_CONFLICT)/);assert.deepEqual(await atomic(h),before);const assessment=await f.assess();assert.equal(assessment.usable,false);assert.deepEqual((await f.state())!.fact,historicalFact);assert.deepEqual(await others(),otherBefore);assert.deepEqual(await immutableBooking(h,b.q.bookingId),origin);
 const v:any=await m.see();assert.equal(v.progress,'Aplicada');assert.equal(v.economic.status,'pending');assert.equal(v.parts.find((p:any)=>p.id===m.partId).scope.id,night.id);assert.ok(v.parts.find((p:any)=>p.id===m.partId).applied);
 const staleApply=await m.attest({...application,operationId:uid()});const afterAttest=await atomic(h);await assert.rejects(m.run(staleApply),/MODIFICATION_(REVISION_CONFLICT|APPROVAL_REQUIRED|PARTS_REQUIRED)/);assert.deepEqual(await atomic(h),afterAttest);
 saveObservation('Q04',{bookingId:b.q.bookingId,nightId:night.id,beforeUsable:confirmed,after:assessment,modification:v,originalFact:historicalFact,unrelated:otherBefore,origin,staleEvaluationAtomicHashes:materialHashes(before)});
});

test('H6016 independent Q05 a lost committed start reply replays after expiry without refresh and denies revoked authority',async()=>{
 const f=await workFixture(h),p=await person(h),auth=await p.auth(),origin=await immutableBooking(h,f.context.contextId),until=new Date(Date.now()+3500).toISOString();
 const material={...f.material,evidence:{reference:'SYNTHETIC own start evidence',fingerprint:'d'.repeat(64),expiresAt:until}},approval=await f.approve(material);await f.run({...f.definition,material,...approval});const claim=f.claim(),claimed=await f.run(claim),start={...f.start(claim,claimed.generation!),material};let evidenceCalls=0;
 const relay=await loseCommitReply(h.port),worker=h.executor('synthetic-executor-a',{databaseUrl:`postgresql://crm_h0_ha_tx@127.0.0.1:${relay.port}/${h.label}`,evidenceProvider:{revalidate:async()=>{evidenceCalls++;return {reference:material.evidence.reference,fingerprint:material.evidence.fingerprint,checkedAt:new Date().toISOString(),validUntil:until,verifierIdentity:'synthetic-independent-verifier',verifierKind:'simulated',outcome:'verified'};}}});
 try{relay.arm('crm_api.b08_work_finalize');await assert.rejects(worker.apply(auth,write,start),(e:any)=>e instanceof WorkCommitUncertainError&&e.operationId===start.operationId);assert.equal(relay.witness().lostReplies,1);assert.equal(evidenceCalls,1);
  const durable=await f.see();assert.equal(durable!.parts[0].state,'contacted');assert.equal(durable!.attempts.length,1);const reservations=await h.admin`select to_jsonb(r) row from crm_ha.reservations r where reservation_id=${durable!.parts[0].reservation_id}`;assert.equal(reservations.length,1);const expired=await elapsed(h,until),beforeReplay=await atomic(h),replay=await worker.apply(auth,write,start);assert.equal(replay.replayed,true);assert.equal(evidenceCalls,1);assert.deepEqual(await atomic(h),beforeReplay);
  await new H0005PostgresAdapter(p.sql,h.f1,h.f2).revokeOne(auth);const afterRevocation=await atomic(h);await assert.rejects(worker.apply(auth,write,start),{message:'F2_DENIED',code:'42501'});assert.deepEqual(await atomic(h),afterRevocation);assert.equal(evidenceCalls,1);assert.deepEqual(await immutableBooking(h,f.context.contextId),origin);
  saveObservation('Q05',{wire:relay.witness(),durableReadBeforeRetry:durable,expired,evidenceCalls,reservations:Array.from(reservations),replay,revokedDenied:'F2_DENIED/42501',replayHashes:materialHashes(beforeReplay),revokedHashes:materialHashes(afterRevocation)});
 }finally{await worker.close();await relay.close();await p.close();}
});

test('H6016 independent Q06 process death after durable simulated effect retains uncertainty and cannot resend',async()=>{
 const f=await workFixture(h);await f.run(f.definition);const claim=f.claim(3),claimed=await f.run(claim),command=f.start(claim,claimed.generation!),dir=await mkdtemp(join(process.env.TMPDIR!,'h6016-own-provider-')),providerFile=join(dir,'effects.jsonl'),origin=await immutableBooking(h,f.context.contextId);
 const input={mode:'effect_then_crash',providerFile,executionId:f.executionId,context:f.context,command,auth:{subject:h.subject,sessionId:h.sessionId,passwordVerified:true,mfaVerified:true},config:{databaseUrl:`postgresql://crm_h0_ha_tx@127.0.0.1:${h.port}/${h.label}`,ssl:false,executorId:'synthetic-executor-a',capability:{...h.f1,key:Array.from(h.f1.key)},humanAuthorization:{...h.f2,key:Array.from(h.f2.key)}}};
 const child=spawn(process.execPath,['--experimental-strip-types','tests/support/h6-durable-provider-child.ts'],{stdio:['pipe','pipe','pipe']});let stdout='',stderr='';child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);const ended=new Promise<{code:number|null;signal:NodeJS.Signals|null}>((resolve,reject)=>{child.on('error',reject);child.on('close',(code,signal)=>resolve({code,signal}));});child.stdin.end(JSON.stringify(input));const exit=await ended;assert.equal(exit.signal,'SIGKILL');assert.equal(stdout,'');assert.equal(stderr,'');
 const facts=async()=>String(await readFile(providerFile,'utf8')).trim().split('\n').filter(Boolean).map(x=>JSON.parse(x));const actual=await facts();assert.equal(actual.length,1);assert.equal(actual[0].attemptId,claim.attemptId);assert.equal((await f.see())!.parts[0].state,'contacted');const deadline=String((await h.admin`select lease_until::text deadline from crm_private.b08_attempts where attempt_id=${claim.attemptId}::uuid`)[0].deadline),expired=await elapsed(h,deadline);
 assert.equal((await f.run({...f.base(),action:'recover'})).state,'uncertain');const uncertain=await f.see(),before=await atomic(h);await assert.rejects(f.run(f.claim()),{message:'WORK_NO_SAFE_PENDING_PART'});assert.deepEqual(await atomic(h),before);assert.equal((await facts()).length,1);
 let inspections=0;const worker=h.executor('synthetic-executor-a',{resultVerifier:{checkEffect:async(r:any)=>({...r,availability:'available',priorEffect:(await facts()).some(x=>x.executionId===r.executionId&&x.partId===r.partId)?'succeeded':'none',sourceKind:'simulated',verifierIdentity:'h6-durable-provider',observationRef:'SYNTHETIC process-durable ledger'}),inspect:async(r:any)=>{inspections++;return(await facts()).find(x=>x.executionId===r.executionId&&x.attemptId===r.attemptId);}}});
 const proof={...f.base(),action:'result' as const,attemptId:claim.attemptId,outcome:'succeeded' as const,resultRef:actual[0].resultRef};await f.run(proof,worker);const result=await f.see(worker),beforeReplay=await atomic(h);assert.equal((await f.run(proof,worker)).replayed,true);assert.equal(inspections,1);assert.deepEqual(await atomic(h),beforeReplay);assert.equal(result!.parts[0].state,'succeeded');assert.equal((await facts()).length,1);assert.deepEqual(await immutableBooking(h,f.context.contextId),origin);
 saveObservation('Q06',{child:{pid:child.pid,...exit,stdoutEmpty:true,stderrEmpty:true,privateConfigOnlyThroughStdin:true},expired,uncertain,result,providerFacts:await facts(),inspections,noBlindResend:true,atomicHashes:materialHashes(before)});
});

test('H6016 independent Q07 real economic Incident versus valid joint close both orders leaves unrelated Booking free',async()=>{
 const records:any[]=[];
 for(const sourceFirst of [false,true]){
  const f=await jointFixture(h),other=await jointFixture(h),inc=await incidentFixture(h,undefined,{bookingId:f.bookingId,serviceId:f.b.detail.services[0]!.id}),q=await inc.command('detect',{...inc.data,severity:'Importante',impact:{...inc.impact,effect:'economic-review'}}),close=await f.j.command(),otherClose=await other.j.command(),prior=await f.j.c.view(),origin=await immutableBooking(h,f.bookingId),a=await person(h),b=await person(h);
  const closures=new H5013ClosureAdapter(a.sql,h.f1,h.f2),incidents=new H4003IncidentAdapter(b.sql,h.f1,h.f2);
  try{const actions=[()=>a.auth().then((auth:any)=>closures.close(auth,write,close)),()=>b.auth().then((auth:any)=>incidents.apply(auth,write,q))],markers=['crm_api.closure_joint_apply','crm_api.incident_apply'];if(sourceFirst){actions.reverse();markers.reverse();}
   const r=await overlap(h,'booking-preparation:'+f.bookingId,0,actions,markers,()=>other.j.run(otherClose));assert.equal(r.results[0]!.status,'fulfilled');if(sourceFirst)rejected(r.results[1]!,/CLOSURE_MATERIAL_CONFLICT/);else assert.equal(r.results[1]!.status,'fulfilled');
   const v=await f.j.c.view();assert.equal(v.jointClosure.current,false);assert.equal(v.jointClosure.history.length,sourceFirst?0:1);assert.ok(v.invalidations.length);assert.deepEqual(v.assessments.commercial,prior.assessments.commercial);assert.deepEqual(v.assessments.operational,prior.assessments.operational);assert.deepEqual(await immutableBooking(h,f.bookingId),origin);assert.equal((await other.j.c.view()).jointClosure.current,true);
   records.push({sourceFirst,witness:r.witness,results:resultRows(r.results),otherCommittedWhileBlocked:r.independent,before:prior,after:v,origin});
  }finally{await a.close();await b.close();}
 }
 saveObservation('Q07',{records,fixtureLimit:'Published jointFixture establishes verified exceptional performance; this test does not claim ordinary service execution or a valid external-provider joint closure.'});
});

test('H6016 independent Q08 actual linked identities and nonempty codes survive merge/archive/restore; same physical pool PID reauthorizes',async()=>{
 const b=await bookingFixture(h),c=await bookingFixture(h);await h.booking.apply(await h.auth(),write,b.q);await h.booking.apply(await h.auth(),write,c.q);const ids=[b.q.bookingId,c.q.bookingId],originals=await Promise.all(ids.map(id=>immutableBooking(h,id))),codes=Array.from(await h.observer`select to_jsonb(x) row from crm_private.identity_codes x where target_id in (${b.q.opportunityId}::uuid,${b.q.proposalId}::uuid,${b.q.bookingId}::uuid,${c.q.opportunityId}::uuid,${c.q.proposalId}::uuid,${c.q.bookingId}::uuid) order by human_code`);
 assert.equal(codes.length,6);assert.equal(new Set(codes.map((x:any)=>x.row.human_code)).size,6);const acceptances=Array.from(await h.observer`select to_jsonb(x) row from crm_private.b03_acceptances x where acceptance_id in (${b.q.acceptanceId}::uuid,${c.q.acceptanceId}::uuid) order by acceptance_id`),resolution=new H1003ResolutionAdapter(h.runtime,h.f1,h.f2),x=b.f.accepterId,y=c.f.accepterId;
 const base={targetId:x,kind:'contact' as const,expectedVersion:0,sourceRef:'SYNTHETIC independent identity resolution',evidenceRef:'SYNTHETIC human reviewed actual linked parties',reason:'SYNTHETIC explicit resolution'};
 await resolution.apply(await h.auth(),write,{...base,operationId:uid(),action:'merge',relatedId:y});await resolution.apply(await h.auth(),write,{...base,targetId:y,operationId:uid(),action:'archive'});const archived=await atomic(h);await assert.rejects(resolution.apply(await h.auth(),write,{...base,operationId:uid(),action:'restore',expectedVersion:1}),/IDENTITY_RESOLUTION_TARGET_INVALID/);assert.deepEqual(await atomic(h),archived);await resolution.apply(await h.auth(),write,{...base,targetId:y,operationId:uid(),action:'restore',expectedVersion:1});
 assert.deepEqual(await Promise.all(ids.map(id=>immutableBooking(h,id))),originals);assert.deepEqual(Array.from(await h.observer`select to_jsonb(x) row from crm_private.b03_acceptances x where acceptance_id in (${b.q.acceptanceId}::uuid,${c.q.acceptanceId}::uuid) order by acceptance_id`),acceptances);
 const preservedCodes=Array.from(await h.observer`select to_jsonb(x) row from crm_private.identity_codes x where target_id in (${b.q.opportunityId}::uuid,${b.q.proposalId}::uuid,${b.q.bookingId}::uuid,${c.q.opportunityId}::uuid,${c.q.proposalId}::uuid,${c.q.bookingId}::uuid) order by human_code`);assert.deepEqual(preservedCodes,codes);
 const third=await bookingFixture(h);await h.booking.apply(await h.auth(),write,third.q);const newCodes=Array.from(await h.observer`select human_code,code_kind,serial_number from crm_private.identity_codes where target_id in (${third.q.opportunityId}::uuid,${third.q.proposalId}::uuid,${third.q.bookingId}::uuid) order by human_code`);assert.equal(newCodes.length,3);for(const n of newCodes as any[]){assert.ok(!codes.some((o:any)=>o.row.human_code===n.human_code));assert.ok(Number(n.serial_number)>Math.max(...codes.filter((o:any)=>o.row.code_kind===n.code_kind).map((o:any)=>Number(o.row.serial_number))));}
 const f=await workFixture(h);await f.run(f.definition);const actor=await person(h),auth=await actor.auth(),app='h6016_own_pool_'+uid().replaceAll('-',''),worker=h.executor('synthetic-executor-a',{databaseUrl:`postgresql://crm_h0_ha_tx@127.0.0.1:${h.port}/${h.label}?application_name=${app}`}),monitor=h.connect('h2_bootstrap');
 const pid=async()=>{const rows=await monitor`select pid,backend_start::text backend_start,usename,application_name from pg_stat_activity where datname=current_database() and application_name=${app}`;assert.equal(rows.length,1);return {...rows[0]};};
 try{assert.deepEqual(Object.keys(worker).sort(),['apply','close','read']);const initial=await worker.read(auth,read,f.executionId,f.context),physical=await pid();assert.equal(physical.usename,'crm_h0_ha_tx');const foreign=await verifyAuth({verify:async()=>({subject:uid(),sessionId:actor.sessionId,passwordVerified:true,mfaVerified:true})},'SYNTHETIC foreign subject');let before=await atomic(h);await assert.rejects(worker.read(foreign,read,f.executionId,f.context),/WORK_DENIED/);assert.deepEqual(await atomic(h),before);assert.deepEqual(await pid(),physical);assert.deepEqual(await worker.read(auth,read,f.executionId,f.context),initial);
  before=await atomic(h);await assert.rejects(worker.read(auth,read,f.executionId,{...f.context,contextId:uid()}),/WORK_DENIED/);assert.deepEqual(await atomic(h),before);assert.deepEqual(await pid(),physical);await assert.rejects(worker.read(auth,read,f.executionId,{...f.context,purpose:'SYNTHETIC wrong purpose'}),/WORK_DENIED/);assert.deepEqual(await worker.read(auth,read,f.executionId,f.context),initial);
  await new H0005PostgresAdapter(actor.sql,h.f1,h.f2).revokeOne(auth);before=await atomic(h);await assert.rejects(worker.read(auth,read,f.executionId,f.context),{message:'F2_DENIED',code:'42501'});assert.deepEqual(await atomic(h),before);assert.deepEqual(await pid(),physical);assert.deepEqual(await worker.read(await h.auth(),read,f.executionId,f.context),initial);assert.deepEqual(await pid(),physical);
  saveObservation('Q08',{linkedIdentityIds:[x,y],originals,originalAcceptances:acceptances,preservedCodes:codes,newCodes,physicalBackend:physical,foreignSubjectDenied:true,foreignContextDenied:true,foreignPurposeDenied:true,revokedSessionDenied:true,authorizedDistinctSessionRecovered:true,privateFacadeOnly:true});
 }finally{await worker.close();await monitor.end({timeout:1});await actor.close();}
});
