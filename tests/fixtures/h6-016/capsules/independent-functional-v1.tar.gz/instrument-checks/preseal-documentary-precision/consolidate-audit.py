#!/usr/bin/env python3
"""Consolidate independently read original cases without rewriting a failed run."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,collections
A=Path(__file__).resolve().parents[1];E=json.loads((A/'expected-independent-v1.json').read_text());O=A/'consolidated';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,value):(O/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def parse(p):
 out=[]
 for line,s in enumerate(p.read_text().splitlines(),1):
  if s.startswith('ℹ tests '):break
  m=re.match(r'^([✔✖]) (.+) \([0-9.]+ms\)$',s)
  if m:out.append({'name':m[2],'status':'PASS' if m[1]=='✔' else 'FAIL','stdoutLine':line})
 return out
runs={};snapshotchecked=0;sourceerrors=[];pre=json.loads((A/'preflight-frozen-v1.json').read_text())
for d in sorted((A/'runs').iterdir()):
 r=json.loads((d/'run.json').read_text());ins=json.loads((d/'inputs.json').read_text());cs=parse(d/'stdout.log');assert sha(d/'stdout.log')==r['stdoutSHA256'] and sha(d/'stderr.log')==r['stderrSHA256'] and sha(d/'inputs.json')==r['inputsSHA256'];assert len(cs)==r['counts']['tests'];assert sum(x['status']=='FAIL' for x in cs)==r['counts']['fail']
 for f in ins['files']:
  p=d/'source'/f['path'];snapshotchecked+=1
  if sha(p)!=f['sha256'] or p.stat().st_size!=f['bytes']:sourceerrors.append(str(p))
 by={x['path']:x['sha256'] for x in ins['files']};assert all(by[x['path']]==x['sha256'] for x in pre['productAndMigrations'])
 runs[d.name]={'result':r,'cases':cs,'path':str(d.relative_to(A)),'inputFiles':len(ins['files'])}
assert not sourceerrors
U=next(n for n in runs if n.startswith('units-01-'));W=next(n for n in runs if n.startswith('work-events-02-'));C=next(n for n in runs if n.startswith('cross-counter-provider-01-'));Q=next(n for n in runs if n.startswith('counter-03-'));Qprev=next(n for n in runs if n.startswith('counter-02-'))
catalog={}
def add(id,n,c,file,token):
 d=A/'runs'/n;p=d/'source'/file;lines=p.read_text().splitlines();line=next((i for i,s in enumerate(lines,1) if token in s),None);assert line,(id,token)
 catalog[id]={'id':id,**c,'run':str(d.relative_to(A)),'runOverallStatus':runs[n]['result']['status'],'stdoutSHA256':sha(d/'stdout.log'),'inputsSHA256':sha(d/'inputs.json'),'source':{'path':str(p.relative_to(A)),'sha256':sha(p),'line':line},'execution':'independent-real-PG'}
for c in runs[U]['cases']:
 m=re.match(r'H6-016 (T\d\d)-(R[01]|F[012]|Lwire|L|N2|N|Fpre) ',c['name']);assert m
 suffix=m[2];token={'R0':'${id}-R${order}','R1':'${id}-R${order}','F0':'${id}-${point}','F1':'${id}-${point}','F2':'${id}-${point}','L':'${id}-L replay','N':'${id}-N untrusted','Fpre':'${id}-Fpre','N2':'${id}-N2','Lwire':'${id}-Lwire'}[suffix];add(m[1]+'-'+suffix,U,c,'tests/integration/postgres-h6-016-units.test.ts',token)
for i,c in enumerate(runs[W]['cases'],1):
 f='tests/integration/postgres-h6-016-t08-t09-'+('events' if i<=4 else 'work')+'.test.ts';s=c['name'];token=s if '${' in s else s
 if i in [3,4]:token='H6016 T09 real event root competition absent child both material cases order ${order}'
 if i in [5,6]:token='W03 real A/B competition order ${order}'
 if i in [10,11]:token='W45 real pause versus start order ${order}'
 if i in [12,13,14]:token='W28 W29 W30 rollback ${action} at ${table}'
 add('W%02d'%i,W,c,f,token)
cross=[x for x in runs[C]['cases'] if x['name'].startswith('H6-016 X')];assert len(cross)==20
for i,c in enumerate(cross,1):
 marker=re.search(r'X\d\d',c['name'])[0];add('C%02d'%i,C,c,'tests/integration/postgres-h6-016-cross.test.ts','H6-016 '+marker+'-')
provider=[x for x in runs[C]['cases'] if x['name'].startswith('H6016 T07 ')];assert len(provider)==9
for i,c in enumerate(provider,1):add('P%02d'%i,C,c,'tests/integration/postgres-h6-016-t07-provider.test.ts','H6016 T07 provider common movement' if i<=4 else c['name'])
for c in runs[Q]['cases']:
 id=re.search(r'Q\d\d',c['name'])[0];add(id,Q,c,'tests/integration/postgres-h6-016-independent.test.ts',c['name']);p=A/'runs'/Q/'observed'/(id+'.json');assert p.is_file();catalog[id]['observation']={'path':str(p.relative_to(A)),'sha256':sha(p),'bytes':p.stat().st_size}
assert len(catalog)==146 and all(x['status']=='PASS' for x in catalog.values())
root=json.loads((A/'executor-readback-v3/root-cases.json').read_text());old=[x for x in root['focal-composition-01']['cases'] if x['name'].startswith(('H5-019 ','H6-007 '))];assert len(old)==36
for i,c in enumerate(old,1):catalog['R%02d'%i]={'id':'R%02d'%i,**c,'stdoutLine':c['line'],'execution':'executor-current-run-read-and-source-verified-not-reexecuted-by-auditor','run':'executor-readback-v3/source/focal-composition-01','stdoutSHA256':root['focal-composition-01']['stdoutSHA256']}
assert all(c['name'] in {x['name'] for x in root['focal-composition-01']['cases']+root['t07-composition-01']['cases']} for k,c in catalog.items() if k[0] not in ['Q','R'])
unit_extra={'T01':['C01','C02','C03','Q01'],'T02':['C01','C02','C03','Q01'],'T03':['C03','Q02'],'T04':['C08','Q04'],'T05':['C04','C05','Q03'],'T06':['C08','C09','Q04'],'T07':['C06','C07','Q03']+['P%02d'%i for i in range(1,10)],'T08':['W%02d'%i for i in range(5,20)]+['Q05','Q08'],'T09':['W%02d'%i for i in range(1,19)]+['Q06'],'T10':['C%02d'%i for i in range(10,20)]+['Q07']+['R%02d'%i for i in range(4,37)],'T11':['C20','Q08','R04']}
limits={
'T01':'Preparación anterior legítima queda separada de fijar; fijar no envía y Acceptance no se infiere.',
'T02':'Se prueba verificación explícita y registro obsoleto; Ganada no crea Booking.',
'T03':'El directo ordinario se ejerce además con cadena completa y rollback diferido C03. No se siembra Booking.',
'T04':'Q04 verifica una noche realmente confirmada y dos noches/dos servicios ajenos; no se extrapola toda combinación posible de modalidades.',
'T05':'Raíz común de100 con dos solicitudes80; los movimientos son sintéticos, sin transferencia externa.',
'T06':'La cancelación operativa puede aplicarse dejando economía pendiente; la atribución posterior explícita sustituye cualquier prorrateo inferido.',
'T07':'Refund/Deposit y pago a proveedor son hechos sintéticos persistidos. No se contacta banco/proveedor ni se afirma exactly-once externo.',
'T08':'D039: restricciones diferidas y comprobación final antes de COMMIT en secuencia controlada; no se promete validez hasta la duración física de COMMIT. El proveedor es doble local.',
'T09':'Cobertura compuesta de recepción de eventos y trabajos. F1/F3/F4 se acreditan sobre claim/start/result de trabajos; el evento B09 tiene rollback intermedio propio. No se afirma cada frontera de fallo en cada rama B09. Q06 mata un proceso propio tras efecto simulado durable y evita reenvío ciego.',
'T10':'Las carreras de factura externa parten de cierre pendiente; no demuestran cierre externo válido. Carreras internas válidas emplean prestación excepcional verificada del fixture publicado. Las36 regresiones R se leen en ejecución actual del integrador, no se cuentan como nuevas ejecuciones del auditor.',
'T11':'Se resuelven/archivan/restauran Contact/Group conforme a contrato; no se inventa fusión o API de archivo de Opportunity/Booking. Se conservan sus originales y códigos no vacíos.'}
units=[];positions=[]
for u in E['units']:
 id=u['id'];base=[k for k in catalog if k.startswith(id+'-')];refs=base+unit_extra[id]
 if id not in ['T08','T09']:
  ax={'O1':[id+'-R0'],'O2':[id+'-R1'],'O3':[id+'-R0',id+'-R1'],'F1':[id+'-Fpre',id+'-F0'],'F2':[id+'-F1'],'F3':[id+'-F2'],'F4':[id+'-Lwire'],'F5':[id+'-L',id+'-N2']}
 else:
  ax={'O1':['W05','W10'] if id=='T08' else ['W03','W05'],'O2':['W06','W11'] if id=='T08' else ['W04','W06'],'O3':['W05','W06','W10','W11'] if id=='T08' else ['W03','W04','W05','W06'],'F1':['W12'],'F2':['W13','W14'] if id=='T08' else ['W02','W12','W13','W14'],'F3':['W15','W16'],'F4':['W17','Q05'] if id=='T08' else ['W17','Q06'],'F5':['W09','W18','Q05'] if id=='T08' else ['W01','W09','Q06']}
 for axis,ids in ax.items():positions.append({'unit':id,'axis':axis,'status':'PASS_BOUNDED','cases':ids,'limit':limits[id]})
 units.append({**u,'status':'PASS_LOCAL_BOUNDED','cases':refs,'axes':ax,'limit':limits[id]})
assert len(positions)==88
transverse_refs={
'X01':['R01','R02','R03','R04'], 'X02':list(catalog), 'X03':['T03-R0','T03-R1','T05-R0','T05-R1','W03','W04','W05','W06','Q02','Q03','Q08'],
'X04':['Q01','Q02','Q03','Q04','Q05','Q06','Q07','Q08'], 'X05':['W19','P05','Q08','R20','R21','R22','R23'],
'X06':[u['id']+'-N2' for u in E['units'] if u['id'] not in ['T08','T09']]+['W18','Q05','Q08'],
'X07':[k for k in catalog if re.match(r'T\d\d-F',k)]+['C03','C09','P09','W02','W12','W13','W14','W15'],
'X08':['W13','W15','W16','W18','P05','Q05','Q08'], 'X09':['W07','W08','W17','Q05','Q06'],
'X10':[u['id']+'-R0' for u in E['units'] if u['id'] not in ['T08','T09']]+['Q07','R35'],
'X11':['Q01','Q02','Q03','Q04','Q07','Q08','C20','R08'],
'X12':['C01','C02','C08','P05','P08','Q01','Q04','Q05','Q06','Q08'],
'X13':['R%02d'%i for i in range(1,37)], 'X14':list(catalog), 'X15':['Q06','Q08']}
trans=[]
for x in E['transverseControls']:
 detail='Referencias exactas en case-catalog-v1.json y fuentes antes de cada ejecución.'
 if x['id']=='X01':detail='Seis dependencias documentales satisfechas por preflight; H6-007 local incorporada por hashes, no asumida publicada. R01–R03 acreditan dependencia integrada H5-019 actual leída.'
 if x['id']=='X06':detail='Reautorización actual ejercida en nueve unidades y TTE. La prohibición de atribuir actividad humana a polling se revisa en la ruta publicada crm_private.work_probe (20261008143617_h5_persisted_work_recovery.sql:71); no se ejecuta polling autónomo ni se afirma una nueva batería temporal de toda F2.'
 if x['id']=='X08':detail='Preserva contratos M02/M04, F1/F2 y autoridad existente. P05/Q08 niegan runtime ordinario; W15/W16 observan frontera final; no vuelve a certificar toda la criptografía aprobada.'
 if x['id']=='X13':detail='178 archivos producto/migraciones idénticos; todas las bases propias fresh68. Regresión dirigida actual del ejecutor36+calidad212, leída y hash contrastada. No upgrade nuevo porque no hay migración nueva; sin afirmar batería global limpia.'
 if x['id']=='X14':detail='Parte técnica PASS con fallos conservados; la recepción final del core/acta/manifiesto todavía no existentes queda pendiente del custodio y no se autocertifica aquí.'
 if x['id']=='X15':detail='Auditor solo escribió área propia, sin acceso al runtime H6-015, sin stage/commit/push/Drive. No se infiere que los cuatro trabajos suspendidos hayan sido consultados de nuevo.'
 trans.append({**x,'status':'PASS_TECHNICAL_FINAL_CUSTODY_PENDING' if x['id']=='X14' else 'PASS_LOCAL_BOUNDED','cases':transverse_refs[x['id']],'interpretationAndLimit':detail})
assignment_units={
'SPEC-FR-CONC-001':['T01','T02','T04','T06','T10'],'SPEC-FR-CONC-002':['T01','T02','T03','T05','T07','T08'],'SPEC-FR-CONC-003':[u['id'] for u in units],
'AC-067':['T01','T02','T04'],'AC-068':['T03','T05','T08'],'SPEC-NFR-007':[u['id'] for u in units],'ARCH-DEC-014':['T03','T05','T08','T09','T10'],
'PLAN-DEC-004':[u['id'] for u in units],'PLAN-DEC-008':[u['id'] for u in units],'PLAN-B10':['T08','T09','T10'],'PLAN-C03':[u['id'] for u in units],
'PT-12':['T01','T03','T05','T08','T09','T10'],'G6':['T03','T07','T08','T09'],'E2':['T01','T02','T03','T04','T05','T06','T07','T08','T09','T10','T11']}
assignment_controls={'PLAN-B10':['X01','X02','X13','X14','X15'],'PLAN-DEC-008':['X02','X04','X09','X13'],'PLAN-C03':['X04','X05','X06','X07','X08'],'ARCH-DEC-014':['X07','X09'],'SPEC-FR-CONC-003':['X07'],'PLAN-DEC-004':['X03','X10']}
byunit={u['id']:u for u in units};assignments=[]
for x in E['assignments']:
 us=[x['id'].removeprefix('PLAN-')] if x['id'].startswith('PLAN-T') else assignment_units[x['id']];refs=list(dict.fromkeys(c for u in us for c in byunit[u]['cases']));assignments.append({**x,'status':'PASS_LOCAL_BOUNDED','unitRefs':us,'cases':refs,'transverseRefs':assignment_controls.get(x['id'],['X02','X07','X11','X15'])})
for obj in assignments+positions+trans+units:
 assert all(k in catalog and catalog[k]['status']=='PASS' for k in obj['cases'])
failures=[]
for n in [C,Qprev]:
 for c in runs[n]['cases']:
  if c['status']!='FAIL':continue
  id=re.search(r'Q\d\d',c['name'])[0];causes={('Q03',C):'Expected reject regex omitted REVISION from published REFUND_FUNDS_REVISION_CONFLICT:E2',('Q04',C):'Observer assumed nonexistent b04_nights.booking_id; corrected existing service_id relation',('Q04',Qprev):'Equivalent material under new operationId legitimately replays with a new receipt; previous oracle incorrectly demanded rejection'}
  failures.append({'id':id,'original':{'run':'runs/'+n,'stdoutSHA256':runs[n]['result']['stdoutSHA256'],**c},'cause':causes[(id,n)],'classification':'instrument-oracle-error-no-product-change','successor':catalog[id]})
assert len(failures)==3
static_resolutions=[]
for i,refs,why in [
(1,[k for k in catalog if k.endswith('-Lwire')]+['W17','Q02','Q05'],'Known-success L relabeled and retained; actual server acknowledgement suppressed by independent relay and durable state read before replay'),
(2,[k for k in catalog if re.match(r'T\d\d-R',k)],'Second loser only CONFLICT/REVISION/VERSION or canonical equivalent existing result; second actor positive winner replay'),
(3,['T03-F0','T03-Fpre','Q02'],'First write identity_contexts witnessed, plus real BEGIN-before-callback and three own boundaries'),
(4,['W02','W12','W13','W14'],'Exact error class, rollback snapshots and event sequence witness'),
(5,['W07','W08','W18','Q05','Q06'],'Lease/evidence expiry observed against PG clock; no SQL assignment of lease deadline'),
(6,['W03','W04','W05','W06','W10','W11'],'Exact duplicate/conflict or fenced/claimed losers and distinct physical sessions observed'),
(7,['W18','Q05'],'Committed start replay after expiry no evidence refresh/reservation duplicate; current revoked session denied F2_DENIED42501'),
(8,['T01-R0','T11-Lwire'],'Lowercase isolated names; fresh all68 actual databases completed'),
(9,['T03-R0','T03-R1','Q02'],'Equivalent already-existing Booking branch accepted only with same canonical identity; no arbitrary second success')]:static_resolutions.append({'id':'R16-STA-%02d'%i,'status':'RESOLVED_SOURCE_AND_INDEPENDENT_EXECUTION','cases':refs,'basis':why})
summary={'schema':'h6016-independent-functional-verdict-v1','at':datetime.now(timezone.utc).isoformat(),'status':'PASS_TECHNICAL_LOCAL_ISOLATED','assignmentCount':25,'unitCount':11,'unitAxisCoveragePositions':88,'transverseCount':15,'distinctRepeatedCandidateCases':138,'newIndependentCounterexampleCases':8,'uniqueAuditorExecutedCases':146,'executorDirectedAntecedentCasesReadNotAuditorExecuted':36,'auditorHistoricalCounts':{'testPositions':sum(r['result']['counts']['tests'] for r in runs.values()),'pass':sum(r['result']['counts']['pass'] for r in runs.values()),'fail':sum(r['result']['counts']['fail'] for r in runs.values()),'cancelled':0,'skipped':0},'sourceSnapshotsChecked':snapshotchecked,'sameModelSeparateAgent':True,'humanIndependentAudit':False,'materialFindingsOpen':0,'finalCoreCustodyAndAcceptanceReadback':'PENDING_SEPARATE_STAGE_NOT_A_CONDITION_ALREADY_PROVEN','globalH6':'IN PROGRESS','repositoryChanged':False,'compositeCoverageNotSingle146CaseRun':True}
dump('run-catalog-v1.json',runs);dump('case-catalog-v1.json',catalog);dump('matrix-25-11-v1.json',{'summary':summary,'expectedSHA256':sha(A/'expected-independent-v1.json'),'assignments':assignments,'units':units,'unitAxisPositions':positions,'transverseControls':trans});dump('own-functional-fail-successors-v1.json',failures);dump('static-findings-resolution-v1.json',static_resolutions);dump('functional-verdict-v1.json',summary)
lines=['# Dictamen técnico independiente H6-016','', '**PASS técnico local/aislado**, con 25 asignaciones directas y 11 unidades cubiertas en los límites especificados. No quedan hallazgos materiales técnicos abiertos. La custodia del core y el acto posterior de aceptación se reciben aparte; este dictamen no sustituye esa recepción ni declara H6 global completado.','', 'Expectativas propias congeladas antes de leer el candidato: `expected-independent-v1.json`, SHA `'+sha(A/'expected-independent-v1.json')+'`. Base `'+E['base']+'`, árbol `'+E['tree']+'`. Se contrastaron directamente Tasks, SPEC, Architecture, Plan, Constitución, decisiones y contratos H5.','', '| Ejecución propia | Resultado bruto | Alcance seleccionado |','|---|---|---|',f'| {U} |90/90 PASS| 90 casos candidato |',f'| {W} |19/19 PASS| 19 casos T08/T09 en su combinación final |',f'| {C} |35 PASS / 2 FAIL|20 cruces +9 proveedor PASS;6/8 contrapruebas PASS |',f'| {Qprev} |7 PASS /1 FAIL| Sucesor propio, oráculo Q04 pendiente en ese intento |',f'| {Q} |8/8 PASS| Ocho contrapruebas finales,0 skip/cancel |','', '**146 casos únicos ejecutados por el auditor**: 138 repeticiones exactas del candidato y ocho contrapruebas propias. Las repeticiones suman159 PASS y3 FAIL en162 posiciones históricas; no existe una única ejecución146 ni un historial completo limpio. Los3 FAIL originales, fuentes y sucesores están preservados en `own-functional-fail-successors-v1.json`. Los errores de parseo/typecheck/selector y del conciliador documental figuran aparte en `instrument-checks`; ninguno se convierte en prueba funcional pasada.','', 'Se leyeron los logs crudos, entradas y resultados actuales del integrador:165+9 casos,174 únicos;36 son regresiones dirigidas H6-007/H5-019, no ejecuciones propias adicionales del auditor. Calidad final212unitarias, typecheck, lint y build PASS. La comprobación propia `executor-readback-v3/result.json` da18/18PASS. Los128 FAIL del integrador conservan sucesor exacto por posición; cuatro contenedores cancelados se separan. Un título T10-L fue aclarado a repetición tras éxito conocido; su prueba real de ACK perdido es Lwire. El conciliador v2 fallido queda conservado.','', '| Unidad | Evidencia ejecutada propia principal y complementos | Límite |','|---|---|---|']
for u in units:lines.append('| '+u['id']+' | '+', '.join(u['cases'])+' | '+u['limit']+' |')
lines+=['','Las88 posiciones de la matriz son ejes de cobertura, no88 casos adicionales. Cada referencia conduce a título exacto, fuente con línea/SHA, log con línea/SHA y ejecución en `case-catalog-v1.json`. El JSON conserva las25 filas normativas literales y su relación con casos; no atribuye toda una familia por un simple nombre de suite.','', 'Las contrapruebas aportan una Booking ausente disputada por rutas normal/directa, pérdida real del ACK de COMMIT, fondos comunes, cambio de una noche previamente confirmada, replay tras vencimiento sin refresco, caída real de proceso tras efecto simulado durable, cierre frente a Incidencia en ambos órdenes y otra Booking libre, y códigos reales no vacíos conservados al resolver/archivar/restaurar. Q08 verifica el mismo PID/backend_start del pool frente a identidad ajena, finalidad/contexto incorrectos, sesión revocada, actor inhabilitado y SQL ordinario directo, con restauración de acceso solo mediante otra sesión legítima.','', 'No hay cambios de producto:178 archivos src/migraciones coinciden con la base publicada (110src y68migraciones), al igual que las22 fuentes normativas/dependencias congeladas. Las catorce fuentes del candidato recibidas y las fuentes ejecutadas se verificaron por identidad. Las seis dependencias documentales se acreditaron, incorporando H6-007 local de forma explícita; H5-019 se volvió a ejercitar en la regresión actual del integrador. No se heredó automáticamente PASS funcional de paquetes históricos.','', 'La persistencia y las transacciones usan PostgreSQL17.11 real sobre bases nuevas con68 migraciones y puertos/TMPDIR propios. Se reutilizan fixtures y adaptadores publicados por identidad; las expectativas, ocho contrapruebas, barreras y relay propio son del auditor. Los fallos se inyectan mediante DDL efímero identificado; no se siembran estados de negocio para eludir guardas. Los proveedores son dobles locales y el efecto durable de Q06 es un fichero sintético de un proceso propio.','', 'Independencia efectiva: agente distinto del implementador, con el mismo modelo, expectativa previa, proceso, bases y recursos propios. No es auditoría humana ni institucional ni una garantía de ausencia absoluta de defectos. D039 se acredita tras esperas y restricciones diferidas antes de iniciar COMMIT; no extiende una ventana hasta la durabilidad física. No se afirma exactly-once externo ni cobertura exhaustiva de cada frontera en cada rama de eventos. La prohibición de polling como actividad humana se revisa sobre el contrato publicado sin una nueva batería temporal completa de F2.','', 'Los nueve hallazgos estáticos preliminares quedaron resueltos mediante fuentes y ejecuciones actuales; la tabla de resolución conserva su identidad y alcance. Los3 FAIL propios son oráculos/instrumentación: clase de conflicto incompleta, relación de lectura de noches incorrecta y equivalencia contractual confundida con conflicto. La corrección final conserva todos los estados de negocio y exige conflicto exacto al cambiar material bajo la misma clave.','', 'Recomendación: aceptar técnicamente H6-016 solo en local/aislado, condicionado a la custodia final y al cierre documental autorizado. H6 permanece IN PROGRESS. No se ejecutaron stage, commit, push, Drive, despliegue, efectos externos de negocio, datos reales, nuevas normas ni runtime/S11 de H6-015; sus cuatro trabajos permanecen fuera de esta auditoría.','']
(O/'DICTAMEN-H6-016-INDEPENDIENTE.md').write_text('\n'.join(lines))
print(json.dumps(summary,ensure_ascii=False))
