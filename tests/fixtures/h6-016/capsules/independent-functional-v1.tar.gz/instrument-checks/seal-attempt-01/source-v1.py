#!/usr/bin/env python3
"""Package new audit artifacts only; runtime, replica and dependency installations are excluded."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,stat,os
A=Path(__file__).resolve().parents[1];D=A/'delivery';assert not D.exists();D.mkdir();h=lambda b:hashlib.sha256(b).hexdigest()
include_dirs=['normative-source','dependency-source','candidate-reception-01','candidate-reception-02','candidate-reception-03','candidate-reception-04','static-review-01','static-review-02','static-review-03','instrument-checks','instruments','runs','executor-readback-v1','executor-readback-v2','executor-readback-v3','consolidated']
files=[p for name in include_dirs for p in (A/name).rglob('*') if p.is_file()]
files += [p for p in A.iterdir() if p.is_file() and p.suffix in ['.json','.md','.py']]
assert len(files)==len(set(files));files.sort(key=lambda p:str(p.relative_to(A)))
for p in files:
 rel=p.relative_to(A);assert not p.is_symlink();assert not set(rel.parts)&{'runtime','replica','node_modules','.git','pgdata','__pycache__'};assert p.name not in ['runtime.env','.env','.env.local','postmaster.pid','postmaster.opts'];assert p.suffix not in ['.pyc','.dump','.sqlite']
 target=D/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
rows=[]
for p in files:
 rel=p.relative_to(A);q=D/rel;b=q.read_bytes();mode=oct(stat.S_IMODE(q.stat().st_mode));assert b==p.read_bytes() and stat.S_IMODE(q.stat().st_mode)==stat.S_IMODE(p.stat().st_mode)
 rows.append({'path':str(rel),'bytes':len(b),'mode':mode,'sha256':h(b)})
manifest={'schema':'h6016-independent-technical-delivery-v1','createdAt':datetime.now(timezone.utc).isoformat(),'task':'TSK-H6-016','scope':'Independent technical expectations, source snapshots, executions, raw FAILs and successors, readbacks and verdict. No final root core/acceptance receipt.','payloadCount':len(rows),'payloadBytes':sum(x['bytes'] for x in rows),'files':rows,'excluded':['replica','runtime and private configuration','node_modules or software cache','PostgreSQL files or dumps','previous sealed audit packages'],'verdictPath':'consolidated/functional-verdict-v1.json','verdictSHA256':h((D/'consolidated/functional-verdict-v1.json').read_bytes()),'humanAudit':False}
mp=D/'delivery-manifest-v1.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n');seal={'schema':'h6016-independent-technical-seal-v1','createdAt':datetime.now(timezone.utc).isoformat(),'manifestPath':mp.name,'manifestSHA256':h(mp.read_bytes()),'manifestBytes':mp.stat().st_size,'payloadCount':len(rows),'payloadBytes':manifest['payloadBytes'],'payloadsReadBack':len(rows),'status':'PASS','appendOnlyHistory':True,'verdictSHA256':manifest['verdictSHA256']};sp=D/'delivery-seal-v1.json';sp.write_text(json.dumps(seal,indent=2)+'\n')
expected={x['path'] for x in rows}|{mp.name,sp.name};assert {str(p.relative_to(D)) for p in D.rglob('*') if p.is_file()}==expected
for m in rows:
 p=D/m['path'];assert h(p.read_bytes())==m['sha256'] and p.stat().st_size==m['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==m['mode']
r={'at':datetime.now(timezone.utc).isoformat(),'status':'PASS','delivery':str(D),'payloadCount':len(rows),'payloadBytes':manifest['payloadBytes'],'totalMembers':len(rows)+2,'manifestSHA256':h(mp.read_bytes()),'sealSHA256':h(sp.read_bytes()),'verdictSHA256':manifest['verdictSHA256'],'verdictSchema':'h6016-independent-functional-verdict-v1','mdSHA256':h((D/'consolidated/DICTAMEN-H6-016-INDEPENDIENTE.md').read_bytes()),'matrixSHA256':h((D/'consolidated/matrix-25-11-v1.json').read_bytes()),'scriptSHA256':h(Path(__file__).read_bytes()),'exactCopyAndFullReadback':True,'noFurtherWritesToDelivery':True};(A/'delivery-receipt-v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
