import assert from 'node:assert/strict';
import {createServer,connect,type Socket} from 'node:net';
import {randomUUID} from 'node:crypto';
import {mkdirSync,writeFileSync} from 'node:fs';
import {join,resolve} from 'node:path';

// Own audit mechanics only. No domain rows are seeded or edited here.
export const latch=()=>{let release!:()=>void;const reached=new Promise<void>(r=>release=r);return {reached,release};};
export function saveObservation(name:string,value:unknown){
 assert.match(name,/^[a-zA-Z0-9_-]+$/);const root=process.env.H6016_AUDIT_OBSERVATIONS;
 assert.ok(root&&resolve(root).startsWith('/private/tmp/h6-016-independent/'),'OWN_OBSERVATIONS_ROOT_REQUIRED');
 mkdirSync(root,{recursive:true});writeFileSync(join(root,name+'.json'),JSON.stringify(value,(_,v)=>typeof v==='bigint'?String(v):v,2)+'\n',{flag:'wx'});
}
const identifier=(s:string)=>{assert.match(s,/^[a-z][a-z0-9_]*$/);return '"'+s+'"';};
export async function snapshot(h:any,tables:readonly string[]){
 const rows:Record<string,unknown[]>={};
 for(const table of tables)rows[table]=Array.from(await h.observer.unsafe('select to_jsonb(t) as row from crm_private.'+identifier(table)+' t order by to_jsonb(t)::text'));
 return rows;
}
export async function ownDatabaseIdentity(h:any){return (await h.observer`select current_database() db, version() version, pg_postmaster_start_time()::text postmaster, inet_server_port() port`)[0];}
export async function observedLock(h:any,fragment:string,timeoutMs=15000,excludePids:readonly number[]=[]){
 assert.ok(fragment.length>=5);const deadline=Date.now()+timeoutMs,monitor=h.connect('h2_bootstrap');
 try{while(Date.now()<deadline){
  const rows=await monitor`select pid,backend_xid::text xid,wait_event_type,wait_event,pg_blocking_pids(pid) blockers from pg_stat_activity where datname=current_database() and pid<>pg_backend_pid() and wait_event_type='Lock' and query like ${'%'+fragment+'%'} order by pid`;
  const matching=Array.from(rows).filter((r:any)=>!excludePids.includes(r.pid));if(matching.length)return matching.map((r:any)=>({...r}));
  await new Promise(r=>setTimeout(r,20));
 }
 throw new Error('AUDIT_REAL_LOCK_NOT_OBSERVED:'+fragment);
 }finally{await monitor.end({timeout:1});}
}
export async function holdTable(h:any,table:string){
 const session=h.connect('h2_bootstrap'),entered=latch(),released=latch();
 const operation=session.begin(async(tx:any)=>{await tx.unsafe('lock table crm_private.'+identifier(table)+' in access exclusive mode');entered.release();await released.reached;});
 await Promise.race([entered.reached,operation.then(()=>{throw new Error('AUDIT_LOCK_ENDED_EARLY');})]);
 return {release:async()=>{released.release();await operation;await session.end({timeout:1});}};
}
export async function overlapping(h:any,table:string,first:()=>Promise<unknown>,firstMarker:string,second:()=>Promise<unknown>,secondMarker:string){
 const lock=await holdTable(h,table);let p:Promise<unknown>|undefined,q:Promise<unknown>|undefined,one:any,two:any;
 try{p=first();p.catch(()=>{});one=await observedLock(h,firstMarker);q=second();q.catch(()=>{});two=await observedLock(h,secondMarker,15000,one.map((r:any)=>r.pid));
  const pids=new Set([...one,...two].map((r:any)=>r.pid));assert.ok(pids.size>=2,'TWO_ACTUAL_BACKENDS_REQUIRED');
 }finally{await lock.release();}
 return {first:await Promise.allSettled([p!]),second:await Promise.allSettled([q!]),lockWitness:{one,two}};
}
// A non-transactional sequence proves this deliberately injected physical stage
// was reached. The SECURITY DEFINER function is ephemeral test instrumentation,
// owned by the isolated bootstrap role; it is never a product/security change.
export async function faultOn(h:any,table:string,kind:'before-row'|'after-row'|'deferred-commit'){
 const suffix=randomUUID().replaceAll('-',''),schema='audit_h6016_'+suffix;
 const qSchema=identifier(schema),qTable=identifier(table),trigger=identifier('fault_'+suffix);
 await h.admin.unsafe(`create schema ${qSchema}; create sequence ${qSchema}.reached; create function ${qSchema}.fail() returns trigger language plpgsql security definer set search_path=pg_catalog as $$ begin perform nextval('${schema}.reached'::regclass); raise exception 'H6016_INDEPENDENT_CONTROLLED_FAULT' using errcode='P0001'; end $$`);
 const timing=kind==='before-row'?'before':'after',constraint=kind==='deferred-commit'?'constraint ':'';
 await h.admin.unsafe(`create ${constraint}trigger ${trigger} ${timing} insert or update or delete on crm_private.${qTable} ${kind==='deferred-commit'?'deferrable initially deferred ':''}for each row execute function ${qSchema}.fail()`);
 return {witness:async()=>{const r=(await h.admin.unsafe(`select last_value::text,is_called from ${qSchema}.reached`))[0];assert.equal(r.is_called,true,'INJECTED_STAGE_NOT_REACHED');return {kind,table,...r};},close:async()=>{await h.admin.unsafe(`drop trigger ${trigger} on crm_private.${qTable}; drop schema ${qSchema} cascade`);}};
}
// Own loopback wire instrument. It observes the actual PostgreSQL COMMIT tag,
// then substitutes one transport-class error. It does not simulate persistence,
// call a provider, log query bodies, or retry the business command.
export async function loseCommitReply(targetPort:number){
 assert.ok(Number.isInteger(targetPort)&&targetPort>1024&&targetPort<65536);
 const sockets=new Set<Socket>();let marker:string|undefined,dropped=0,commitTags=0;
 const server=createServer(client=>{
  const upstream=connect(targetPort,'127.0.0.1');sockets.add(client);sockets.add(upstream);
  let front=Buffer.alloc(0),back=Buffer.alloc(0),startup=true,eligible=false;
  const close=()=>{client.destroy();upstream.destroy();sockets.delete(client);sockets.delete(upstream);};
  client.on('error',close);upstream.on('error',close);client.on('close',close);upstream.on('close',close);
  client.on('data',chunk=>{
   front=Buffer.concat([front,chunk]);
   if(startup&&front.length>=4){const n=front.readInt32BE(0);if(front.length<n)return;upstream.write(front.subarray(0,n));front=front.subarray(n);startup=false;}
   while(!startup&&front.length>=5){const n=1+front.readInt32BE(1);if(front.length<n)break;const packet=front.subarray(0,n);front=front.subarray(n);
    if(marker){let sql='';if(packet[0]===81)sql=packet.subarray(5).toString();else if(packet[0]===80){const end=packet.indexOf(0,5);if(end!==-1)sql=packet.subarray(end+1).toString();}if(sql.includes(marker))eligible=true;}
    upstream.write(packet);
   }
  });
  upstream.on('data',chunk=>{back=Buffer.concat([back,chunk]);while(back.length>=5){const n=1+back.readInt32BE(1);if(back.length<n)break;const packet=back.subarray(0,n);back=back.subarray(n);
   if(packet[0]===67&&packet.subarray(5).toString()==='COMMIT\0'){commitTags++;if(eligible&&marker){marker=undefined;eligible=false;dropped++;const body=Buffer.from('SERROR\0C08006\0MH6016 independent actual COMMIT reply loss\0\0'),header=Buffer.alloc(5);header[0]=69;header.writeInt32BE(body.length+4,1);client.write(Buffer.concat([header,body]));continue;}}
   client.write(packet);
  }});
 });
 await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const a=server.address();assert.ok(a&&typeof a!=='string');
 return {port:a.port,arm:(sqlMarker:string)=>{assert.ok(!marker&&dropped===0);assert.match(sqlMarker,/^[a-zA-Z0-9_.]+$/);marker=sqlMarker;},witness:()=>({actualCommitTags:commitTags,lostReplies:dropped}),close:async()=>{for(const s of sockets)s.destroy();await new Promise<void>(r=>server.close(()=>r()));}};
}
