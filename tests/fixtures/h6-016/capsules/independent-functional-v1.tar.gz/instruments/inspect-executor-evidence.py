#!/usr/bin/env python3
"""Read-only inspection of executor evidence; never uses its verification result as oracle."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,collections
A=Path(__file__).resolve().parents[1]; R=Path('/Users/andres/.codex/worktrees/h6-016-local/crm-huescaventura-os'); P=R.parent/'receipts'; O=A/'executor-readback-v3'; O.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p):
 d=O/'source'/p.relative_to(P);d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(p.read_bytes());return {'path':str(p.relative_to(P)),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def readj(p):save(p);return json.loads(p.read_text())
def cases(p):
 out=[]
 for i,line in enumerate(p.read_text().splitlines(),1):
  if line.startswith('ℹ tests '):break
  m=re.match(r'^([✔✖]) (.+) \([0-9.]+ms\)$',line)
  if m:out.append({'name':m[2],'status':'PASS' if m[1]=='✔' else 'FAIL','line':i})
 return out
checks=[]
def check(id,okay,detail):
 checks.append({'id':id,'status':'PASS' if okay else 'FAIL','detail':detail})
 # Preserve all results even on an unexpected mismatch.
pre=json.loads((A/'preflight-frozen-v1.json').read_text())
for key,entries in [('product178',pre['productAndMigrations']),('normative22',pre['sources'])]:
 errors=[]
 for m in entries:
  sourceRoot=Path('/Users/andres/.codex/worktrees/h6-007-local/receipts/acceptance-source-snapshot-v1') if m.get('source')=='local-H6-007 acceptance capsule' else R
  if sha((sourceRoot/m['path']).read_bytes())!=m['sha256']:errors.append(m['path'])
 check(key,not errors,{'count':len(entries),'mismatches':errors})
git={k:subprocess.check_output(['git',*v],cwd=R,text=True).strip() for k,v in {'head':['rev-parse','HEAD'],'tree':['rev-parse','HEAD^{tree}'],'index':['diff','--cached','--name-only'],'tracked':['diff','--name-only']}.items()}
check('git-base-index-tracked',git=={'head':pre['base'],'tree':pre['tree'],'index':'','tracked':''},git)
frozen=readj(P/'composition-source-frozen-v1.json'); source_rows=[]
for m in frozen['files']:
 b=(R/m['path']).read_bytes();source_rows.append({**m,'currentEqualsFrozen':sha(b)==m['sha256']});d=O/'candidate-source'/m['path'];d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
check('candidate-13-frozen',len(source_rows)==13 and all(x['currentEqualsFrozen'] for x in source_rows),source_rows)
provider=R/'tests/integration/postgres-h6-016-t07-provider.test.ts'; ph='325b2e974a412442997603219cbf6836cc9fb5c0d7d8be4fbd5ec3cfc53efc81';check('candidate-provider-14',sha(provider.read_bytes())==ph,{'path':str(provider.relative_to(R)),'sha256':sha(provider.read_bytes())});d=O/'candidate-source'/provider.relative_to(R);d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(provider.read_bytes())
allruns={}; final_cases=[]
for name,expected in [('units-01',(15,6,1)),('units-02',(51,12,0)),('units-03',(0,90,1)),('cross-02',(19,1,0)),('cross-03',(20,19,2)),('units-04',(90,0,0)),('focal-composition-01',(165,0,0)),('t07-composition-01',(9,0,0))]:
 d=P/name;r=readj(d/'result.json');save(d/'stdout.log');save(d/'stderr.log');inputs=readj(d/'inputs.json');raw=(d/'stdout.log').read_text();summary={k:int(re.findall(r'^ℹ '+k+r' (\d+)$',raw,re.M)[-1]) for k in ['tests','pass','fail','cancelled','skipped']};cs=cases(d/'stdout.log');observed=(summary['pass'],summary['fail'],summary['cancelled']);check('raw-'+name,observed==expected and sha((d/'stdout.log').read_bytes())==r['stdoutSHA256'] and sha((d/'stderr.log').read_bytes())==r['stderrSHA256'] and summary['skipped']==0,{'summary':summary,'hashes':{'stdout':r['stdoutSHA256'],'stderr':r['stderrSHA256']},'originalExitCode':r['exitCode']});allruns[name]={'summary':summary,'cases':cs,'stdoutSHA256':r['stdoutSHA256'],'inputsSHA256':sha((d/'inputs.json').read_bytes())}
 if name in ['focal-composition-01','t07-composition-01']:
  rows=inputs if isinstance(inputs,list) else inputs['files']; by={x['path']:x['sha256'] for x in rows}; mismatches=[]
  for x in pre['productAndMigrations']:
   if by.get(x['path'])!=x['sha256']:mismatches.append(x['path'])
  for m in frozen['files']:
   if by.get(m['path'])!=m['sha256']:mismatches.append(m['path'])
  if name=='t07-composition-01' and by.get(str(provider.relative_to(R)))!=ph:mismatches.append('provider supplement')
  check('executed-inputs-'+name,not mismatches,{'listed':len(rows),'product':178,'frozen13':13,'mismatches':mismatches});final_cases.extend({'run':name,**x} for x in cs)
ledger=readj(P/'fail-successors-v1.json');mappings=[];fail_seen=[]
for row in ledger['individualMappings']:
 old=allruns[row['run']]; matches=[x for x in old['cases'] if x['status']=='FAIL' and x['name']==row['originalNodeName']];new=allruns[row['successorRun']];success=[x for x in new['cases'] if x['status']=='PASS' and x['name']==row['successorNodeName']]
 okay=len(matches)==1 and len(success)==1 and old['stdoutSHA256']==row['originalStdoutSHA256'] and (row['originalNodeName']==row['successorNodeName'] or (row['originalNodeName']=='H6-016 T10-L committed acknowledgement lost then same identity and material conflict' and row['successorNodeName']=='H6-016 T10-L replay after known committed success and same-key material conflict'))
 mappings.append({**row,'readback':'PASS' if okay else 'FAIL','originalLine':matches[0]['line'] if matches else None,'successorLine':success[0]['line'] if success else None});fail_seen.append((row['run'],row['originalNodeName']))
expected_fail=[(n,x['name']) for n in ['units-01','units-02','units-03','cross-02','cross-03'] for x in allruns[n]['cases'] if x['status']=='FAIL' and not x['name'].startswith(str(R)+'/tests/integration/')];check('128-failed-positions-one-exact-successor',len(mappings)==128 and all(x['readback']=='PASS' for x in mappings) and collections.Counter(fail_seen)==collections.Counter(expected_fail),{'mapped':len(mappings),'rawFailedPositions':len(expected_fail),'duplicates':len(fail_seen)-len(set(fail_seen)),'globalCleanHistoricalClaim':False,'literalTitleAliasCount':sum(x['originalNodeName']!=x['successorNodeName'] for x in mappings),'aliasMeaning':'Old L means replay after known success; actual wire ACK loss is separate Lwire'})
cancelled=sum(allruns[x['run']]['summary']['cancelled'] for x in ledger['cancelledPositions']);check('four-cancelled-preserved',cancelled==4 and len([x for n in ['units-01','units-03','cross-03'] for x in allruns[n]['cases'] if x['status']=='FAIL' and x['name'].startswith(str(R)+'/tests/integration/')])==4 and all(allruns[x['run']]['summary']['cancelled']==x['count'] for x in ledger['cancelledPositions']),ledger['cancelledPositions'])
for f in ['fail-successors-addendum-v1.json','cross-01/result.json','cross-01/stdout.log','cross-01/stderr.log','static-01/result.json','static-cross-01.json','units-01-controlled-stop.json','units-03-controlled-stop.json','cross-03-controlled-stop.json']:
 if (P/f).is_file():save(P/f)
q=readj(P/'final-02-quality/result.json');qrows=[]
for row in q['results']:
 name=row['command'][1];out=P/'final-02-quality'/(name+'.stdout.log');err=P/'final-02-quality'/(name+'.stderr.log');save(out);save(err);okay=sha(out.read_bytes())==row['stdoutSHA256'] and sha(err.read_bytes())==row['stderrSHA256'] and row['exitCode']==0
 if name=='test':okay=okay and re.search(r'^ℹ pass 212$',out.read_text(),re.M) is not None and re.search(r'^ℹ fail 0$',out.read_text(),re.M) is not None
 qrows.append({'command':row['command'],'hashesMatch':okay,'stdoutSHA256':row['stdoutSHA256'],'stderrSHA256':row['stderrSHA256']})
check('quality212-typecheck-lint-build',len(qrows)==4 and all(x['hashesMatch'] for x in qrows),qrows)
for name in ['evidence-TSK-H6-016.md','matrix-TSK-H6-016.md']:
 p=R/'specs/001-core-crm'/name;d=O/'documentation'/name;d.parent.mkdir(exist_ok=True);d.write_bytes(p.read_bytes())
result={'at':datetime.now(timezone.utc).isoformat(),'status':'PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL','checks':checks,'rootFinalUnique':len(final_cases),'rootFinalCaseNamesUnique':len(set(x['name'] for x in final_cases)),'ownExecutionOfRootRegressions':False,'independentlyRepeatedCandidateCases':138,'checksOnlyNoRootWrites':True,'runtimeAccess':False,'checksCount':len(checks),'scriptSHA256':sha(Path(__file__).read_bytes())}
(O/'root-cases.json').write_text(json.dumps(allruns,indent=2)+'\n');(O/'128-fail-successor-readback.json').write_text(json.dumps(mappings,indent=2)+'\n');(O/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':result['status'],'checks':len(checks),'failed':[c['id'] for c in checks if c['status']!='PASS'],'rootFinalUnique':len(final_cases)}))
