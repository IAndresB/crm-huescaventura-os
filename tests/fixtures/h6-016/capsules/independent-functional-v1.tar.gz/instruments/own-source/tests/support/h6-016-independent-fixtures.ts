// Independent audit orchestration; domain facts use published application contracts.
import assert from 'node:assert/strict';
import {randomUUID as uid} from 'node:crypto';
import {createServer} from 'node:net';
import {fifthDatabase,read,write} from './h5-018-fifth-isolated.ts';
import {secondWorkActor} from './h5-work-isolated.ts';
import {latch,observedLock} from './h6-016-independent-control.ts';
export {read,write,uid};
export async function database(){const s=createServer();await new Promise<void>(r=>s.listen(0,'127.0.0.1',r));const a=s.address();assert.ok(a&&typeof a!=='string');const port=a.port;await new Promise<void>(r=>s.close(()=>r()));const label='h6016_independent_'+process.pid;const h=await fifthDatabase(label,port);return {...h,port,label};}
export async function person(h:any){const s=await secondWorkActor(h),sql=h.connect('crm_h0_runtime');await sql.unsafe(`set statement_timeout='12000ms'`);return {...s,sql,close:()=>sql.end({timeout:1})};}
export async function atomic(h:any){
 const names=await h.observer`select schemaname,tablename from pg_tables where (schemaname='crm_private' and tablename ~ '^(b0[2-9]_|b10_|identity_|unit_|external_effect_)') or (schemaname='crm_ha' and tablename in ('reservations','events','command_receipts','evidence_revalidations')) order by schemaname,tablename`;
 const state:Record<string,unknown>={};for(const n of names){assert.match(n.schemaname,/^[a-z_]+$/);assert.match(n.tablename,/^[a-z0-9_]+$/);state[n.schemaname+'.'+n.tablename]=Array.from(await h.observer.unsafe(`select to_jsonb(x) row from ${n.schemaname}.${n.tablename} x order by to_jsonb(x)::text`));}return state;
}
export async function immutableBooking(h:any,id:string){return (await h.observer`select booking_id,opportunity_id,acceptance_id,verification_id,version_id,detail,terms,chain_snapshot from crm_private.b04_bookings where booking_id=${id}::uuid`)[0];}
export async function overlap(h:any,root:string,seed:number,actions:(()=>Promise<any>)[],markers:string[],other?:()=>Promise<any>){
 const guard=h.connect('h2_bootstrap'),ready=latch(),unlock=latch();const holder=guard.begin(async(tx:any)=>{await tx`select pg_advisory_xact_lock(hashtextextended(${root},${seed}))`;ready.release();await unlock.reached;});await ready.reached;
 const jobs:Promise<any>[]=[];let first:any,second:any,independent:any,failure:any;
 try{jobs.push(actions[0]!());jobs[0]!.catch(()=>{});first=await observedLock(h,markers[0]!);jobs.push(actions[1]!());jobs[1]!.catch(()=>{});second=await observedLock(h,markers[1]!,15000,first.map((r:any)=>r.pid));if(other)independent=await other();}
 catch(e){failure=e;}finally{unlock.release();await holder;await guard.end({timeout:1});}
 const results=await Promise.allSettled(jobs);if(failure)throw failure;assert.ok(new Set([...first,...second].map((x:any)=>x.pid)).size>=2);return {results,witness:{first,second},independent};
}
export async function elapsed(h:any,deadline:string){for(let i=0;i<600;i++){const row=(await h.admin`select clock_timestamp()::text observed_at,clock_timestamp()>=${deadline}::timestamptz expired`)[0];if(row.expired)return row;await new Promise(r=>setTimeout(r,20));}throw new Error('AUDIT_POSTGRES_DEADLINE_NOT_OBSERVED');}
export function rejected(r:PromiseSettledResult<any>,pattern:RegExp){assert.equal(r.status,'rejected');assert.match(String((r as PromiseRejectedResult).reason),pattern);return String((r as PromiseRejectedResult).reason);}
