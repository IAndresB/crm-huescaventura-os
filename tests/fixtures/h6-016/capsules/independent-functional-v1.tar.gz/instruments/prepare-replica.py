#!/usr/bin/env python3
"""Export only published code/helper objects into an isolated non-Git replica.
No DB/runtime, package download, source mutation or candidate evidence import.
"""
import hashlib, json, os, pathlib, subprocess
from datetime import datetime, timezone
A=pathlib.Path(__file__).resolve().parents[1]
R=pathlib.Path('/Users/andres/.codex/worktrees/h6-016-local/crm-huescaventura-os')
BASE='9c15e6d143822f7fcc84f29744194554630f4ac4'
EXPECTED_TREE='fe7cabb05e44462121c70ad52405765e2c94fcd2'
OUT=A/'replica'
assert not OUT.exists(), 'REFUSE_OVERWRITE_REPLICA'
assert subprocess.check_output(['git','rev-parse',BASE+'^{tree}'],cwd=R,text=True).strip()==EXPECTED_TREE
raw=subprocess.check_output(['git','ls-tree','-rz',BASE],cwd=R)
root_names={'package.json','pnpm-lock.yaml','tsconfig.json','next-env.d.ts','next.config.ts','eslint.config.mjs','postcss.config.mjs'}
rows=[]
for entry in raw.split(b'\0'):
 if not entry: continue
 meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();name=name.decode()
 selected=(name in root_names or name.startswith('src/') or name.startswith('supabase/migrations/') or name.startswith('tests/support/'))
 # No historical recovery runtime is imported; all other helpers keep published bytes.
 if not selected or name.startswith('tests/support/h6-015-') or name=='tests/support/h6-bootstrap-integration.ts' or name=='tests/support/h6-bootstrap-variant.ts': continue
 assert kind=='blob' and mode in ('100644','100755'), (name,kind,mode)
 assert not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
 data=subprocess.check_output(['git','cat-file','blob',oid],cwd=R)
 out=OUT/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data);out.chmod(int(mode[-3:],8))
 rows.append({'path':name,'gitBlob':oid,'mode':mode,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'at':datetime.now(timezone.utc).isoformat(),'status':'EXPORTED_PUBLISHED_HELPERS_ONLY','base':BASE,'tree':EXPECTED_TREE,'count':len(rows),'members':rows,'runtimeStarted':False,'candidateNewSourcesRead':False,'excluded':['Git metadata','sealed historical evidence','H6-015 recovery runtime/helpers','node_modules','private runtime/configuration']}
p=A/'published-replica-inputs-v1.json';p.write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'manifest':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'files':len(rows),'replica':str(OUT),'runtimeStarted':False}))
