import {randomUUID as uid} from 'node:crypto';
import {read,write,type isolatedCancellation} from './h4-cancellation-isolated.ts';
import {confirmationFixture} from './h4-confirmation-fixtures.ts';
import {invoiceFixture} from './h3-invoice-fixtures.ts';
import {modificationFixture} from './h4-modification-fixtures.ts';
import type {CancellationCommand} from '../../src/infrastructure/postgres/h4-cancellation-adapter.ts';
import {civilReference,localDate,zoneEvidence} from '../../src/domain/civil-time.ts';
import type {AcceptanceCommand} from '../../src/infrastructure/postgres/h2-acceptance-adapter.ts';
import type {BookingCommand} from '../../src/infrastructure/postgres/h2-booking-adapter.ts';
import type {BookingDetail} from '../../src/domain/booking-conversion.ts';
type H=Awaited<ReturnType<typeof isolatedCancellation>>;const now=()=>new Date().toISOString();
export async function cancellationAcceptance(h:H,amount="100.01",count=1,dates=["2026-10-20","2026-10-22"],termsText="D011 voluntary cancellation 7/3 days; synthetic accepted policy",otherAmount=amount){
 const service=await h.cat('service',{name:'H2 SYNTHETIC service',nature:'external'}),unit=await h.cat('unit',{name:'SYNTHETIC group',definition:'fixed group'}),form=await h.cat('pricing_form',{name:'SYNTHETIC fixed',definition:'fixed'});
 const tariff=await h.com('tariff',{label:'synthetic',price_state:'confirmed',amount:'900.00',cost_state:'confirmed',cost_amount:'700.00',vat_treatment:'included',unit_revision_id:unit.revision,pricing_form_revision_id:form.revision},service);
 const opp=h.input();await h.adapter.apply(await h.auth(),write,opp);
 const mid=uid(),line=uid(),other=uid(),content={scope:'H2 exact synthetic scope',terms:{version:'H2-T1',text:termsText,sourceRef:'synthetic retained terms'},pending:[],modalities:[mid,other].map((id,i)=>({id,name:i?'B':'A',participants:count,independent:true,selectable:true,conditions:'synthetic exact',finalPersonPrice:i?otherAmount:amount,manualReason:'human synthetic',definitive:true,lines:[{id:i?uid():line,serviceRevisionId:service.revision,unitRevisionId:unit.revision,tariffRevisionId:tariff.revision,quantity:'1',included:true,independent:true,selectable:true,date:dates[i]!,datePending:false,priceBasis:'fixed' as const,costMaterial:true,sourceRef:'synthetic quantity'}]}))};
 const proposalId=uid(),versionId=uid(),c={action:'prepare' as const,operationId:uid(),proposalId,opportunityId:opp.targetId,expectedRevision:0,expectedOpportunityRevision:1,sourceRef:'synthetic',reason:'synthetic',content};
 await h.proposal.apply(await h.auth(),write,c);await h.proposal.apply(await h.auth(),write,{...c,action:'fix',operationId:uid(),versionId,content:undefined,expectedRevision:1});
 const accepterId=uid(),designationId=uid();await h.identities.apply(await h.auth(),write,{action:'create_entity',operationId:uid(),targetId:accepterId,kind:'contact',expectedVersion:0,sourceRef:'synthetic identity',evidenceRef:'synthetic identity evidence',reason:'synthetic',verified:true,displayName:'SYNTHETIC CLIENT'});
 await h.identities.apply(await h.auth(),write,{action:'designate',operationId:uid(),targetId:designationId,relatedId:accepterId,contextId:opp.targetId,kind:'primary_contact',expectedVersion:0,sourceRef:'synthetic designation',evidenceRef:'synthetic faculty',reason:'synthetic',verified:true,happenedAt:new Date(Date.now()-1000).toISOString()});
 const proof=async(claim:string,coverage:string,at:string,certainty='reviewed')=>{const r=h.req('evidence',{claim,coverage,certainty,source_kind:'manual'},opp.targetId);await h.evidence.apply(await h.auth(),write,{...r,coverage,occurredAt:at});return r.targetId;};
 const revisions=async()=>({expectedRevision:Number((await h.observer`select revision from crm_private.b03_proposals where proposal_id=${proposalId}::uuid`)[0]!.revision),expectedOpportunityRevision:Number((await h.observer`select revision from crm_private.b03_opportunities where opportunity_id=${opp.targetId}::uuid`)[0]!.revision)});
 const issued=now(),until=new Date(Date.now()+60).toISOString(),limitEvidence=false?await proof(`offer:limit:${versionId}:availability:${until}`,content.scope,issued):undefined,evidenceId=await proof(`offer:issue:${versionId}:${issued}:7`,content.scope,issued);
 await h.offer.apply(await h.auth(),write,{action:'issue',operationId:uid(),proposalId,opportunityId:opp.targetId,versionId,...await revisions(),sourceRef:'synthetic',reason:'synthetic',coverage:content.scope,at:issued,issuance:{issuedAt:issued,limits:false?[{aspect:'availability',until,evidenceId:limitEvidence!}]:[]},evidenceId});
 const q=async(change:Partial<AcceptanceCommand>={}):Promise<AcceptanceCommand>=>({action:'candidate',operationId:uid(),acceptanceId:uid(),proposalId,opportunityId:opp.targetId,versionId,...await revisions(),sourceRef:'synthetic exact act',reason:'synthetic decision',coverage:content.scope,at:now(),...change});
 const registration=async(coverage=content.scope,channel='phone',certainty='reviewed')=>{const at=now(),acceptanceId=uid(),authorityEvidenceId=await proof(`acceptance:authority:${versionId}:${accepterId}:${designationId}`,coverage,at),evidenceId=await proof(`acceptance:agree:${versionId}:${acceptanceId}:${accepterId}:${channel}`,coverage,at,certainty);
  return q({action:'register',acceptanceId,at,coverage,accepterId,designationId,channel,terms:content.terms,authorityEvidenceId,evidenceId});};
 const register=async(coverage=content.scope,channel='phone')=>{const r=await registration(coverage,channel);await h.acceptance.apply(await h.auth(),write,r);return r;};
 const verification=async(r:AcceptanceCommand,won=true)=>{const reviewEvidence:Record<string,string>={};for(const aspect of ['prices','availability','conditions','capacity']) reviewEvidence[aspect]=await proof(`offer:review:${versionId}:${r.acceptanceId}:accept:${aspect}`,r.coverage,r.at);
  return q({action:'verify',acceptanceId:r.acceptanceId,at:r.at,coverage:r.coverage,reviewEvidence,won});};
 return {opp,content,mid,line,other,proposalId,versionId,accepterId,designationId,proof,q,revisions,registration,register,verification};
}

export async function cancellationFixture(h:H,{amount='100.01',otherAmount,count=1,index=0,night=false,dates=['2026-10-20','2026-10-22'],terms='D011 voluntary cancellation 7/3 days; synthetic accepted policy',existing,scopeKind='modality'}:{amount?:string;otherAmount?:string;count?:number;index?:number;night?:boolean;dates?:string[];terms?:string;existing?:any;scopeKind?:'modality'|'service'|'booking'|'night'}={}){
 const fallback=await invoiceFixture(h),f=existing?.f??await cancellationAcceptance(h,amount,count,dates,terms,otherAmount??amount);
 let b:BookingCommand,detail:BookingDetail;
 if(existing){b=existing.b;detail=existing.detail;}else{const r=await f.register(f.content.scope);await h.acceptance.apply(await h.auth(),write,await f.verification(r));detail={services:f.content.modalities.map((m:any)=>({id:uid(),serviceRevisionId:m.lines[0].serviceRevisionId,nature:'external' as const,variant:null,provider:null,place:null,schedule:null,contributions:[{id:uid(),lineId:m.lines[0].id,modalityId:m.id,quantity:m.lines[0].quantity,attendees:m.participants,certainty:'estimated' as const}],nights:[]})),participants:[],assignments:[]};if(night){const svc=detail.services[index]!;(svc.nights as any).push({id:uid(),date:dates[index],contributionIds:svc.contributions.map(c=>c.id)});} const hash=(await h.observer`select encode(crm_crypto.digest(convert_to(${JSON.stringify(detail)}::text::jsonb::text,'UTF8'),'sha256'),'hex') hash`)[0]!.hash;b={operationId:uid(),bookingId:uid(),opportunityId:f.opp.targetId,acceptanceId:r.acceptanceId,proposalId:f.proposalId,versionId:f.versionId,coverage:r.coverage,terms:f.content.terms,...await f.revisions(),sourceRef:'SYNTHETIC cancellation booking',reason:'SYNTHETIC real H2 conversion',evidenceId:await f.proof(`booking:detail:${r.acceptanceId}:${hash}`,r.coverage,now()),detail,route:'normal'};await h.booking.apply(await h.auth(),write,b);}
 const conf=await confirmationFixture(h,{...fallback,bookingId:b.bookingId,b:{...fallback.b,q:b,detail}},index),m=await modificationFixture(h,conf),did=uid();
 // G: cancellation auxiliary evidence belongs to the fixed synthetic act. Other
 // proof families keep their original fixture clock; recorded_at remains real.
 const originalProof=conf.proof;
 conf.proof=async(claim:string,target=conf.confirmationId,certainty='reviewed')=>{
  if(!claim.startsWith('cancellation:'))return originalProof(claim,target,certainty);
  const proof=h.req('evidence',{claim,coverage:target,certainty,source_kind:'manual'},target,'other');
  await h.evidence.apply(await h.auth(),write,{...proof,occurredAt:'2026-10-17T10:00:00Z',coverage:target});
  return proof.targetId;
 };
 const actualRequestScope=scopeKind==='booking'?{kind:'booking',id:b.bookingId}:scopeKind==='night'?{kind:'night',id:detail.services[index]!.nights[0]!.id,serviceId:detail.services[index]!.id}:m.scope;
 const request=await m.request([{id:m.partId,scope:actualRequestScope,expectedScopeRevision:1,desired:{cancelled:true},aspects:['cancellation'],dependencies:[]}]);await m.run(await m.attest({...request,data:{...request.data,type:'cancellation'}}));
 const scope:any=scopeKind==='night'?{kind:'night',id:detail.services[index]!.nights[0]!.id,serviceId:detail.services[index]!.id}:{kind:scopeKind,id:scopeKind==='modality'?(index?f.other:f.mid):scopeKind==='booking'?b.bookingId:detail.services[index]!.id};
 const token=async()=>String((await h.cancellations.basis(await h.auth(),read,b.bookingId,scope)).scopeToken);
 // G: default evidence follows this command's act; an explicit invalid time is preserved.
 const attest=async(q:CancellationCommand,certainty='reviewed',evidenceAt:string=q.at)=>{
  const claim=`cancellation:${q.action}:${await conf.hash(Object.fromEntries(Object.entries(q).filter(([k,v])=>!['operationId','evidenceId','computed'].includes(k)&&v!==undefined)))}`;
  const proof=h.req('evidence',{claim,coverage:q.determinationId,certainty,source_kind:'manual'},q.determinationId,'other');
  await h.evidence.apply(await h.auth(),write,{...proof,occurredAt:evidenceAt,coverage:q.determinationId});
  return {...q,evidenceId:proof.targetId};
 };
 const command=async(change:Partial<CancellationCommand>={},evidenceAt:string|undefined=change.at):Promise<CancellationCommand>=>attest({action:'determine',operationId:uid(),determinationId:did,bookingId:b.bookingId,modificationId:m.modificationId,partId:m.partId,expectedRevision:0,expectedModificationRevision:(await m.see())!.revision,scope,expectedScopeToken:await token(),sourceRef:'SYNTHETIC accredited cause and accepted D011',reason:'SYNTHETIC Administrator exact economic determination',at:'2026-10-17T10:00:00Z',evidenceId:uid(),facts:{cause:'voluntary',policy:{id:'D011',version:'D011/D019/D020/D023',rule:'D011',terms:b.terms},base:{kind:'participation',amount,count,start:0,modalityId:index?f.other:f.mid,components:[{modalityId:index?f.other:f.mid,acceptedVersion:b.versionId,unit:'participation'}]},reference:civilReference({scope:scopeKind==='booking'?'global':scopeKind,scopeId:scope.id},localDate(dates[index]!),zoneEvidence('Europe/Madrid','SYNTHETIC accepted zone','1'),b.versionId,'1'),nonRefundable:null,at:'2026-10-17T10:00:00Z'},...change},'reviewed',evidenceAt);
 const base=async(amount:string|null,kind:'component'|'fixed'='component')=>{const value={kind,amount,count:1,start:0,components:[{id:m.partId,source:b.versionId,reason:'SYNTHETIC explicit attributable commercial component'}]};if(amount===null)return value;return {...value,administratorDecision:{recordId:await conf.record(),reason:'SYNTHETIC explicit Admin decision on this booking',evidenceId:await conf.proof('cancellation:base:'+await conf.hash({scope,base:value,terms:b.terms}),b.bookingId)}};};
 const run=async(q:CancellationCommand)=>h.cancellations.apply(await h.auth(),write,q),see=async()=>h.cancellations.read(await h.auth(),read,b.bookingId,did);
 const applyOperational=async()=>{await m.run(await m.evaluate());await m.run(await m.approve());await m.run(await m.apply());};
 return {f,b,detail,conf,m,did,scope,token,attest,command,base,run,see,applyOperational};
}
import {moneyDifference} from '../../src/domain/exact-money.ts';
export async function cancellationSchedule(h:H,f:Awaited<ReturnType<typeof cancellationFixture>>,amount='200.02'){
 const pid=uid(),sid=uid();
 const attest=async(q:any)=>{const material=Object.fromEntries(Object.entries(q).filter(([k,v])=>!['operationId','evidenceId','computed'].includes(k)&&v!==undefined));return {...q,evidenceId:await f.f.proof('obligation:'+q.action+':'+await f.conf.hash(material),f.b.coverage,q.at)};};
 const common={operationId:uid(),bookingId:f.b.bookingId,policyId:pid,expectedRevision:0,sourceRef:'SYNTHETIC accepted payment policy',reason:'SYNTHETIC exact ordinary schedule',at:'2026-10-12T10:00:00Z',evidenceId:uid()};
 await h.obligations.apply(await h.auth(),write,await attest({...common,action:'publish_policy',policyVersion:1,selectors:{}}));
 const reference=civilReference({scope:'global',scopeId:f.b.bookingId},localDate('2026-10-20'),zoneEvidence('Europe/Madrid','SYNTHETIC accepted zone','1'),f.b.versionId,'1');
 await h.obligations.apply(await h.auth(),write,await attest({...common,operationId:uid(),action:'determine',scheduleId:sid,scope:'global',scopeId:f.b.bookingId,policy:{id:pid,version:1,rule:'ordinary_50_50'},definition:{base:{amount,sourceRef:f.b.versionId,version:'1'},reference,at:common.at}}));
 return {pid,sid};
}
export async function cancellationApplication(h:H,f:Awaited<ReturnType<typeof cancellationFixture>>,scheduleId:string,parts:readonly unknown[],expectedScheduleRevision=1){
 const state=(await f.see());const {history,...det}=state;
 const adjustment={scheduleId,expectedRevision:expectedScheduleRevision,parts};
 const approvalEvidenceId=await f.conf.proof('cancellation:approve:'+await f.conf.hash({determination:det,adjustment}),f.did);
 return f.command({action:'apply_obligation',facts:undefined,expectedRevision:state.revision,adjustment:{...adjustment,parts:parts as any,approvalEvidenceId}});
}
