from pathlib import Path
import json,hashlib,datetime,stat,subprocess,difflib,tempfile,shutil,sys,gzip
D=Path(__file__).resolve().parent;R=D.parent/'crm-huescaventura-os';F=R/'tests/fixtures/h6-016';B=F/'local-closure';S=R/'specs/001-core-crm';PUB=Path('/Users/andres/.codex/worktrees/h6-007-prepublication')
def sha(b):return hashlib.sha256(b).hexdigest()
# Inputs are independently verified hash identities, not cryptographic signatures.
if len(sys.argv)!=3:raise SystemExit('Require exact independent core custody result path and SHA256')
cp=Path(sys.argv[1]);assert sha(cp.read_bytes())==sys.argv[2];C=json.loads(cp.read_text());assert C['status']=='PASS';assert not B.exists()
A=json.loads((F/'independent/independent-verdict-v1.json').read_text());assert A['status']=='PASS_TECHNICAL_LOCAL_ISOLATED'and A['materialFindingsOpen']==0 and A['assignmentCount']==25 and A['unitCount']==11 and A['uniqueAuditorExecutedCases']==146
core=F/'technical-core-manifest-v1.json';corehash=sha(core.read_bytes());assert C['manifestSHA256']==corehash
T=json.loads((PUB/'receipts/publication-target-v1.json').read_text());assert sha((PUB/'receipts/publication-target-v1.json').read_bytes())=='19facd96d3f0abfe77c7b825d89d6dc0269afb4af5248b93eb8ee1a1baccdb6f'
now=datetime.datetime.now(datetime.timezone.utc).isoformat();block='''<!-- H6-016-LOCAL-CLOSURE-BEGIN -->
## Estado vigente H6-016 — cierre exclusivamente local/aislado, 2026-10-25

**TSK-H6-016: COMPLETED — exclusivamente local/aislado. H6 global: IN PROGRESS.** Cierre formalizado conforme a la autorización condicionada de dirección tras cobertura de las 25 asignaciones y T01–T11, auditoría técnica independiente PASS y custodia local PASS. Evidencia del integrador: 165/165 de composición y regresión dirigida, más9/9 proveedor en ejecución separada;138 focales propios y36 repeticiones dirigidas. Unitarias212/212, typecheck/lint/build PASS. Auditor:138 repeticiones y8 contrapruebas propias PASS; independencia técnica de agentes del mismo modelo, no humana externa.

Acta `specs/001-core-crm/acceptance-TSK-H6-016-local.md`; evidencia y matriz del mismo expediente; dictamen `tests/fixtures/h6-016/independent/independent-verdict.md`; manifiesto técnico y candidato final separados. Ningún cambio de producto, seguridad, autenticación, normativa ni de las68 migraciones. Los128 FAIL Node y4 cancelados previos del integrador, los2 FAIL del coautor y los3 FAIL de contrapruebas del auditor se conservan con sus sucesores; errores de instrumentos se documentan aparte. No es una ejecución global limpia histórica. H6-001 conserva2.899PASS/46FAIL de2.945 y H6-0041.006PASS/117FAIL de1.123, con sus reconciliaciones originales.

Seis dependencias satisfechas localmente: H5-019,H6-013,H6-001,H6-004,H6-006,H6-007. H6-007 permanece COMPLETED local/aislado y su candidato sellado4aeb3d83… no se presupone publicado. Su target de prepublicación19facd96… y corte histórico permanecen separados. H6-015 conserva COMPLETED formal local/aislado, cuarentena y cuatro trabajos suspendidos: sin acceso al runtime, S11 ni reentrada. Hosted/Production NO ACREDITADOS. Sin datos/efectos reales, conectores, Drive, deploy, staging, commit, push o merge.

Esta es una variante documental aislada; no se ha aplicado a documentos canónicos ni publicado. Los bloques y estados inferiores conservan su fecha e historia; las referencias antiguas H6-016 NOT STARTED/NO ACREDITADA quedan supersedidas exclusivamente para este alcance local. Las restantes tareas e hitos conservan su estado. Publicar H6-007 o H6-016 requiere autorización posterior sobre su candidato exacto, sin mezclar lotes ni levantar cuarentenas.
<!-- H6-016-LOCAL-CLOSURE-END -->

'''
paths=['specs/001-core-crm/tasks.md','docs/PROJECT-STATUS.md','docs/NEXT-STEPS.md'];allrows=[];checks=[]
for variant,root in [('post-G-b',PUB/'crm-huescaventura-os'),('direct-9c15',R)]:
 patches=[]
 for rel in paths:
  old=(root/rel).read_bytes();assert b'H6-016-LOCAL-CLOSURE-BEGIN'not in old
  expected=next((x['sha256']for x in T['files']if x['path']==rel),None)if variant=='post-G-b'else sha(subprocess.check_output(['git','show','9c15e6d143822f7fcc84f29744194554630f4ac4:'+rel],cwd=R));assert sha(old)==expected
  pos=old.index(b'\n')+1;new=old[:pos]+b'\n'+block.encode()+old[pos:]
  if rel.endswith('tasks.md'):
   start=new.index(b'<a id="tsk-h6-016"></a>');end=new.index(b'<a id="tsk-h6-017"></a>',start);card=new[start:end]
   changes=[(b'- [ ] **Ejecuci\xc3\xb3n: NOT STARTED. Evidencia: NO EJECUTADA.** Hito: H6. Tipo: comprobaci\xc3\xb3n.', '- [x] **Ejecución: COMPLETED — exclusivamente local/aislado. Evidencia: SATISFACTORIA; auditoría y custodia independientes PASS; cierre condicionado formalizado 2026-10-25.** Hito: H6. Tipo: comprobación.'.encode()),('no cambia el estado NOT STARTED.'.encode(),'el estado local vigente se acredita en acceptance-TSK-H6-016-local.md; Hosted/Production y publicación siguen excluidos.'.encode()),('**Acción futura:**'.encode(),'**Acción ejecutada local/aislada:**'.encode()),('**NO EJECUTADA**: observado y resultado aún sin producir.'.encode(),'**SATISFACTORIA local/aislada**: matriz25/T01–T11, observado, dictamen, FAIL y sucesores, manifiestos y custodia enlazados en la cabecera. No acredita una regresión global limpia histórica.'.encode())]
   for a,b in changes:assert card.count(a)==1,(variant,a);card=card.replace(a,b)
   new=new[:start]+card+new[end:]
  before=B/variant/'preimages'/rel;after=B/variant/'postimages'/rel;before.parent.mkdir(parents=True,exist_ok=True);after.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(old);after.write_bytes(new)
  patch=b''.join(difflib.diff_bytes(difflib.unified_diff,old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile=('a/'+rel).encode(),tofile=('b/'+rel).encode(),lineterm=b'\n'));patches.append(patch)
  allrows.append({'variant':variant,'targetPath':rel,'type':'regular','gitMode':'100644','preimage':str(before.relative_to(R)),'preSHA256':sha(old),'preBytes':len(old),'postimage':str(after.relative_to(R)),'postSHA256':sha(new),'postBytes':len(new),'canonicalApplied':False})
 pp=D/'acceptance-raw-patches-v1'/(variant+'.patch');pp.parent.mkdir(exist_ok=True);pp.write_bytes(b''.join(patches))
 gp=B/variant/'patches/exact-shared.patch.gz';gp.parent.mkdir(parents=True);gp.write_bytes(gzip.compress(pp.read_bytes(),mtime=0));assert gzip.decompress(gp.read_bytes())==pp.read_bytes()
 (gp.parent/'patch-identity-v1.json').write_text(json.dumps({'rawPatchBytes':pp.stat().st_size,'rawPatchSHA256':sha(pp.read_bytes()),'gzipSHA256':sha(gp.read_bytes()),'rawOriginalCustody':str(pp),'format':'lossless gzip, extract raw patch before hash-guarded apply; no whitespace normalization/waiver'},indent=2)+'\n')
 with tempfile.TemporaryDirectory(prefix='h6016_documentary_')as temp:
  wd=Path(temp)
  for x in [x for x in allrows if x['variant']==variant]:p=wd/x['targetPath'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/x['preimage']).read_bytes())
  def apply(*args,expect=0):
   q=subprocess.run(['git','apply',*args,str(pp.resolve())],cwd=wd,capture_output=True,text=True);checks.append({'variant':variant,'args':list(args),'exit':q.returncode,'stdout':q.stdout,'stderr':q.stderr,'expectedExit':expect});assert q.returncode==expect,(variant,q.stdout,q.stderr)
  apply('--check','--whitespace=error-all');apply('--whitespace=error-all')
  for x in [x for x in allrows if x['variant']==variant]:assert sha((wd/x['targetPath']).read_bytes())==x['postSHA256']
  # Idempotence belongs to the hash-guarded procedure, not to reapplying unified diff blindly.
  state='NOOP_ALREADY_APPLIED'if all(sha((wd/x['targetPath']).read_bytes())==x['postSHA256']for x in allrows if x['variant']==variant)else'FAIL';assert state=='NOOP_ALREADY_APPLIED'
  apply('--reverse','--check');apply('--reverse')
  for x in [x for x in allrows if x['variant']==variant]:assert sha((wd/x['targetPath']).read_bytes())==x['preSHA256']
  checks.append({'variant':variant,'state':state,'reverseRestoresExactPreimages':True,'noIndexOrObjectsWritten':True})
manifest={'schema':'h6016-isolated-shared-closure-variants-v1','at':now,'status':'PREPARED_NOT_APPLIED_NOT_PUBLISHED','order':'Preferred post-G-b only after separately authorized H7 G-a/G-b; direct-9c15 alternative mutually exclusive, not interchangeable','base':'9c15e6d143822f7fcc84f29744194554630f4ac4','postG_bTree':'fe08a679c6bc247fb3127f32a7abef0250fdaabb','technicalCoreSHA256':corehash,'independentCoreCustodySHA256':sys.argv[2],'files':allrows,'patchChecks':checks,'H7targetUnchanged':True};(B/'documentary-variants-v1.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
(S/'acceptance-TSK-H6-016-local.md').write_text(f'''# Acta de aceptación TSK-H6-016 — exclusivamente local/aislado

Formalizada {now} bajo la autorización expresa condicionada del director para ejecutar y cerrar localmente H6-016. No se atribuye firma humana adicional ni auditoría humana externa.

**TSK-H6-016: COMPLETED — exclusivamente local/aislado. H6 global: IN PROGRESS.** Se han satisfecho las25 asignaciones normativas y los límites aplicables T01–T11; dictamen técnico independiente PASS, sin defectos materiales abiertos y con custodia de antecedentes PASS antes de esta acta.

Candidato técnico SHA-256 `{corehash}`; recibo de custodia independiente SHA-256 `{sys.argv[2]}`. Dictamen y evidencias: `tests/fixtures/h6-016/independent/independent-verdict.md`, `evidence-TSK-H6-016.md`, `matrix-TSK-H6-016.md`. La envoltura final incorpora esta acta y sus variantes sin reescribir el candidato técnico.

Integrador:165/165 de composición y regresión dirigida, más9/9 proveedor aparte, unitarias212/212, typecheck/lint/build PASS. Auditor:138 repeticiones críticas y8 contrapruebas propias PASS. Se conserva el histórico de FAIL y sus sucesores, incluidos128 Node del integrador y4 cancelados,2 del coautor y3 de contrapruebas del auditor; incidencias de verificadores se conservan separadamente. No se declara regresión global limpia. Los antecedentes H6-001/H6-004 conservan sus recuentos originales.

H5-019,H6-013,H6-001,H6-004,H6-006,H6-007 están satisfechas en su alcance local acreditado. H6-007 permanece sin publicar y separado. Se preservan los110 archivos de producto,68 migraciones, los candidatos H6-001/H6-004/H6-007, cierres H5 y los16 manifiestos/4568 entradas de H6-015. El checkout principal conserva14954 archivos históricos, HEAD e índice originales. H6-015 sigue en cuarentena, con sus cuatro trabajos protegidos; no hubo runtime, SQL ni S11.

Solo se añaden pruebas, derivados identificados y documentación/evidencia propia. Los canónicos Tasks/PROJECT-STATUS/NEXT-STEPS no se sobrescriben: se adjuntan dos alternativas de parches exactos, post-G-b y directa9c15, con aplicación/reversión y NOOP idempotente verificados. No deben aplicarse ambas ni sustituirse preimágenes.

Quedan excluidos publicación, staging/commit/push/merge, Drive, datos/efectos reales, conectores, despliegues/Hosted/Production, cambios normativos o de seguridad y levantamiento de cuarentena. La siguiente publicación necesita autorización expresa sobre los candidatos exactos; este cierre no autoriza otra tarea.
''')
print(json.dumps({'status':'COMPLETED_LOCAL_ISOLATED','sharedVariants':len(allrows),'canonicalWrites':False,'technicalCoreSHA256':corehash}))
