from pathlib import Path,PurePosixPath
import subprocess,json,hashlib,tarfile,io,re,stat,datetime
R=Path(__file__).resolve().parent.parent/'crm-huescaventura-os';D=R.parent/'receipts';paths=[p.decode()for p in subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=R).split(b'\0')if p];findings=[];unsafe=[];resolved=[];logical=0;total=0
PLACEHOLDERS={'c7320372b7422ed624ec21a065355cec2a4962ac1877ba293f3fcef7c5452cd1','ac590ea5a82a878af61f562aee2f9351f32ec8c79abdb5762297f94ccd1a4b2b','aade8d9862f813aead74253833014fa5f69ee78876a76e4463af8533c076ceb3','03d39fbe997b202b18c6f17b77eba9d6f5ffafeb5a287931941d847066899f5b'}
patterns=[('private-key',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),('AWS-key',rb'\bAKIA[0-9A-Z]{16}\b'),('GitHub-key',rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b'),('Stripe-live',rb'\bsk_live_[A-Za-z0-9]{16,}\b'),('OpenAI-key',rb'\bsk-proj-[A-Za-z0-9_-]{30,}\b')]
def scan(name,raw):
 global logical,total
 logical+=1;total+=len(raw)
 for label,p in patterns:
  if re.search(p,raw):findings.append({'path':name,'kind':label})
 for m in re.finditer(rb'postgres(?:ql)?://[^\s\"\x27<>]+',raw):
  uri=m[0]
  if b'@'in uri and not any(b'@'+h in uri for h in[b'127.0.0.1',b'localhost',b'[::1]']):
   digest=hashlib.sha256(uri).hexdigest()
   if name=='tests/fixtures/h6-016/capsules/executor-originals-v1.tar.gz!supabase-connections.md'and digest in PLACEHOLDERS and b'[YOUR-PASSWORD]'in uri and (b'[PROJECT-REF]'in uri or b'[POOLER-HOST]'in uri):resolved.append({'path':name,'uriSHA256':digest,'reason':'literal placeholders in official public Supabase documentation, not an operational credential','sourceURL':'https://supabase.com/docs/guides/database/connecting-to-postgres'})
   else:findings.append({'path':name,'kind':'nonloopback-postgres-uri'})
for rel in paths:
 p=R/rel;s=p.lstat();assert stat.S_ISREG(s.st_mode)and not p.is_symlink();raw=p.read_bytes();scan(rel,raw)
 if rel.endswith('.tar.gz'):
  with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as tf:
   for m in tf.getmembers():
    if not m.isfile()or m.name.startswith('/')or '..'in PurePosixPath(m.name).parts:unsafe.append({'archive':rel,'member':m.name});continue
    scan(rel+'!'+m.name,tf.extractfile(m).read())
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS'if not findings and not unsafe else'FAIL','ownedFiles':len(paths),'logicalUnitsIncludingCapsules':logical,'logicalBytes':total,'highConfidenceSecretFindings':findings,'unsafeArchiveEntries':unsafe,'individuallyResolvedPublicDocumentationPlaceholders':resolved,'predecessor':'security-owned-v1.json (4 lexical alerts retained)','scope':'Static high-confidence signatures, credential URI and archive safety; synthetic provenance from fixtures; excludes runtime config/keys. No exhaustive proof of absence of all sensitive strings.'};(D/'security-owned-v2.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert result['status']=='PASS'
